package net.mcreator.kopermod.procedures;

import net.minecraft.world.level.LevelAccessor;
import net.minecraft.core.BlockPos;

import net.mcreator.kopermod.init.KoperModModBlocks;

public class HaoticsharkPlaybackCondition1Procedure {
	public static boolean execute(LevelAccessor world, double x, double y, double z) {
		if ((world.getFluidState(BlockPos.containing(x, y, z)).createLegacyBlock()).getBlock() == KoperModModBlocks.BLOOD.get()) {
			return true;
		}
		return true;
	}
}