package net.mcreator.kopermod.fluid;

import net.neoforged.neoforge.fluids.BaseFlowingFluid;

import net.minecraft.world.level.material.FluidState;
import net.minecraft.world.level.material.Fluid;
import net.minecraft.world.level.block.state.StateDefinition;
import net.minecraft.world.level.block.LiquidBlock;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.core.particles.ParticleOptions;

import net.mcreator.kopermod.init.KoperModModItems;
import net.mcreator.kopermod.init.KoperModModFluids;
import net.mcreator.kopermod.init.KoperModModFluidTypes;
import net.mcreator.kopermod.init.KoperModModBlocks;

public abstract class BloodFluid extends BaseFlowingFluid {
	public static final BaseFlowingFluid.Properties PROPERTIES = new BaseFlowingFluid.Properties(() -> KoperModModFluidTypes.BLOOD_TYPE.get(), () -> KoperModModFluids.BLOOD.get(), () -> KoperModModFluids.FLOWING_BLOOD.get()).explosionResistance(100f)
			.tickRate(7).levelDecreasePerBlock(4).bucket(() -> KoperModModItems.BLOOD_BUCKET.get()).block(() -> (LiquidBlock) KoperModModBlocks.BLOOD.get());

	private BloodFluid() {
		super(PROPERTIES);
	}

	@Override
	public ParticleOptions getDripParticle() {
		return ParticleTypes.ASH;
	}

	public static class Source extends BloodFluid {
		public int getAmount(FluidState state) {
			return 8;
		}

		public boolean isSource(FluidState state) {
			return true;
		}
	}

	public static class Flowing extends BloodFluid {
		protected void createFluidStateDefinition(StateDefinition.Builder<Fluid, FluidState> builder) {
			super.createFluidStateDefinition(builder);
			builder.add(LEVEL);
		}

		public int getAmount(FluidState state) {
			return state.getValue(LEVEL);
		}

		public boolean isSource(FluidState state) {
			return false;
		}
	}
}