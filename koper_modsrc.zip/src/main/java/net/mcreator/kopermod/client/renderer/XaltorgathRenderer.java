package net.mcreator.kopermod.client.renderer;

import net.minecraft.resources.ResourceLocation;
import net.minecraft.client.renderer.entity.MobRenderer;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.model.HierarchicalModel;

import net.mcreator.kopermod.entity.XaltorgathEntity;
import net.mcreator.kopermod.client.model.animations.CustomModelAnimation;
import net.mcreator.kopermod.client.model.ModelCustomModel;

import com.mojang.blaze3d.vertex.PoseStack;

public class XaltorgathRenderer extends MobRenderer<XaltorgathEntity, ModelCustomModel<XaltorgathEntity>> {
	public XaltorgathRenderer(EntityRendererProvider.Context context) {
		super(context, new AnimatedModel(context.bakeLayer(ModelCustomModel.LAYER_LOCATION)), 0.5f);
	}

	@Override
	protected void scale(XaltorgathEntity entity, PoseStack poseStack, float f) {
		poseStack.scale(1.4f, 1.4f, 1.4f);
	}

	@Override
	public ResourceLocation getTextureLocation(XaltorgathEntity entity) {
		return ResourceLocation.parse("koper_mod:textures/entities/idle.png");
	}

	private static final class AnimatedModel extends ModelCustomModel<XaltorgathEntity> {
		private final ModelPart root;
		private final HierarchicalModel animator = new HierarchicalModel<XaltorgathEntity>() {
			@Override
			public ModelPart root() {
				return root;
			}

			@Override
			public void setupAnim(XaltorgathEntity entity, float limbSwing, float limbSwingAmount, float ageInTicks, float netHeadYaw, float headPitch) {
				this.root().getAllParts().forEach(ModelPart::resetPose);
				this.animate(entity.animationState0, CustomModelAnimation.spin, ageInTicks, 1f);
			}
		};

		public AnimatedModel(ModelPart root) {
			super(root);
			this.root = root;
		}

		@Override
		public void setupAnim(XaltorgathEntity entity, float limbSwing, float limbSwingAmount, float ageInTicks, float netHeadYaw, float headPitch) {
			animator.setupAnim(entity, limbSwing, limbSwingAmount, ageInTicks, netHeadYaw, headPitch);
			super.setupAnim(entity, limbSwing, limbSwingAmount, ageInTicks, netHeadYaw, headPitch);
		}
	}
}