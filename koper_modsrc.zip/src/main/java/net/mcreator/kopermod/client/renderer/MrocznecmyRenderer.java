package net.mcreator.kopermod.client.renderer;

import net.minecraft.resources.ResourceLocation;
import net.minecraft.client.renderer.entity.MobRenderer;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.model.HierarchicalModel;

import net.mcreator.kopermod.entity.MrocznecmyEntity;
import net.mcreator.kopermod.client.model.animations.mrocznecmyAnimation;
import net.mcreator.kopermod.client.model.Modelmrocznecmy;

import com.mojang.blaze3d.vertex.PoseStack;

public class MrocznecmyRenderer extends MobRenderer<MrocznecmyEntity, Modelmrocznecmy<MrocznecmyEntity>> {
	public MrocznecmyRenderer(EntityRendererProvider.Context context) {
		super(context, new AnimatedModel(context.bakeLayer(Modelmrocznecmy.LAYER_LOCATION)), 0.5f);
	}

	@Override
	protected void scale(MrocznecmyEntity entity, PoseStack poseStack, float f) {
		poseStack.scale(0.4f, 0.4f, 0.4f);
	}

	@Override
	public ResourceLocation getTextureLocation(MrocznecmyEntity entity) {
		return ResourceLocation.parse("koper_mod:textures/entities/123123414.png");
	}

	private static final class AnimatedModel extends Modelmrocznecmy<MrocznecmyEntity> {
		private final ModelPart root;
		private final HierarchicalModel animator = new HierarchicalModel<MrocznecmyEntity>() {
			@Override
			public ModelPart root() {
				return root;
			}

			@Override
			public void setupAnim(MrocznecmyEntity entity, float limbSwing, float limbSwingAmount, float ageInTicks, float netHeadYaw, float headPitch) {
				this.root().getAllParts().forEach(ModelPart::resetPose);
				this.animateWalk(mrocznecmyAnimation.fly, limbSwing, limbSwingAmount, 1f, 1f);
				this.animate(entity.animationState1, mrocznecmyAnimation.attack, ageInTicks, 1f);
			}
		};

		public AnimatedModel(ModelPart root) {
			super(root);
			this.root = root;
		}

		@Override
		public void setupAnim(MrocznecmyEntity entity, float limbSwing, float limbSwingAmount, float ageInTicks, float netHeadYaw, float headPitch) {
			animator.setupAnim(entity, limbSwing, limbSwingAmount, ageInTicks, netHeadYaw, headPitch);
			super.setupAnim(entity, limbSwing, limbSwingAmount, ageInTicks, netHeadYaw, headPitch);
		}
	}
}