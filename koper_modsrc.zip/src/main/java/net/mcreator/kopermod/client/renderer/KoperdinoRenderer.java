package net.mcreator.kopermod.client.renderer;

import net.minecraft.resources.ResourceLocation;
import net.minecraft.client.renderer.entity.MobRenderer;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.model.HierarchicalModel;

import net.mcreator.kopermod.entity.KoperdinoEntity;
import net.mcreator.kopermod.client.model.animations.koperAnimation;
import net.mcreator.kopermod.client.model.Modelkoper;

import com.mojang.blaze3d.vertex.PoseStack;

public class KoperdinoRenderer extends MobRenderer<KoperdinoEntity, Modelkoper<KoperdinoEntity>> {
	public KoperdinoRenderer(EntityRendererProvider.Context context) {
		super(context, new AnimatedModel(context.bakeLayer(Modelkoper.LAYER_LOCATION)), 4f);
	}

	@Override
	protected void scale(KoperdinoEntity entity, PoseStack poseStack, float f) {
		poseStack.scale(4.8f, 4.8f, 4.8f);
	}

	@Override
	public ResourceLocation getTextureLocation(KoperdinoEntity entity) {
		return ResourceLocation.parse("koper_mod:textures/entities/texturedinokoper.png");
	}

	private static final class AnimatedModel extends Modelkoper<KoperdinoEntity> {
		private final ModelPart root;
		private final HierarchicalModel animator = new HierarchicalModel<KoperdinoEntity>() {
			@Override
			public ModelPart root() {
				return root;
			}

			@Override
			public void setupAnim(KoperdinoEntity entity, float limbSwing, float limbSwingAmount, float ageInTicks, float netHeadYaw, float headPitch) {
				this.root().getAllParts().forEach(ModelPart::resetPose);
				this.animateWalk(koperAnimation.walk, limbSwing, limbSwingAmount, 1f, 1f);
				this.animate(entity.animationState1, koperAnimation.attackbite, ageInTicks, 1f);
			}
		};

		public AnimatedModel(ModelPart root) {
			super(root);
			this.root = root;
		}

		@Override
		public void setupAnim(KoperdinoEntity entity, float limbSwing, float limbSwingAmount, float ageInTicks, float netHeadYaw, float headPitch) {
			animator.setupAnim(entity, limbSwing, limbSwingAmount, ageInTicks, netHeadYaw, headPitch);
			super.setupAnim(entity, limbSwing, limbSwingAmount, ageInTicks, netHeadYaw, headPitch);
		}
	}
}