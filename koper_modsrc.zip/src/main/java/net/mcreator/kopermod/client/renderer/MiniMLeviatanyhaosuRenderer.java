package net.mcreator.kopermod.client.renderer;

import net.minecraft.resources.ResourceLocation;
import net.minecraft.client.renderer.entity.MobRenderer;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.model.HierarchicalModel;

import net.mcreator.kopermod.procedures.LeviatanhaosuWarunekOdtwarzania2Procedure;
import net.mcreator.kopermod.entity.MiniMLeviatanyhaosuEntity;
import net.mcreator.kopermod.client.model.animations.leviatan_haosuAnimation;
import net.mcreator.kopermod.client.model.Modelleviatan_haosu;

import com.mojang.blaze3d.vertex.PoseStack;

public class MiniMLeviatanyhaosuRenderer extends MobRenderer<MiniMLeviatanyhaosuEntity, Modelleviatan_haosu<MiniMLeviatanyhaosuEntity>> {
	public MiniMLeviatanyhaosuRenderer(EntityRendererProvider.Context context) {
		super(context, new AnimatedModel(context.bakeLayer(Modelleviatan_haosu.LAYER_LOCATION)), 1f);
	}

	@Override
	protected void scale(MiniMLeviatanyhaosuEntity entity, PoseStack poseStack, float f) {
		poseStack.scale(2.99f, 2.99f, 2.99f);
	}

	@Override
	public ResourceLocation getTextureLocation(MiniMLeviatanyhaosuEntity entity) {
		return ResourceLocation.parse("koper_mod:textures/entities/rexture.png");
	}

	private static final class AnimatedModel extends Modelleviatan_haosu<MiniMLeviatanyhaosuEntity> {
		private final ModelPart root;
		private final HierarchicalModel animator = new HierarchicalModel<MiniMLeviatanyhaosuEntity>() {
			@Override
			public ModelPart root() {
				return root;
			}

			@Override
			public void setupAnim(MiniMLeviatanyhaosuEntity entity, float limbSwing, float limbSwingAmount, float ageInTicks, float netHeadYaw, float headPitch) {
				this.root().getAllParts().forEach(ModelPart::resetPose);
				if (LeviatanhaosuWarunekOdtwarzania2Procedure.execute(entity))
					this.animateWalk(leviatan_haosuAnimation.walk, limbSwing, limbSwingAmount, 1f, 1f);
				this.animate(entity.animationState1, leviatan_haosuAnimation.attacklapka, ageInTicks, 1f);
				this.animate(entity.animationState2, leviatan_haosuAnimation.swim, ageInTicks, 1f);
				this.animate(entity.animationState3, leviatan_haosuAnimation.ryk, ageInTicks, 1f);
			}
		};

		public AnimatedModel(ModelPart root) {
			super(root);
			this.root = root;
		}

		@Override
		public void setupAnim(MiniMLeviatanyhaosuEntity entity, float limbSwing, float limbSwingAmount, float ageInTicks, float netHeadYaw, float headPitch) {
			animator.setupAnim(entity, limbSwing, limbSwingAmount, ageInTicks, netHeadYaw, headPitch);
			super.setupAnim(entity, limbSwing, limbSwingAmount, ageInTicks, netHeadYaw, headPitch);
		}
	}
}