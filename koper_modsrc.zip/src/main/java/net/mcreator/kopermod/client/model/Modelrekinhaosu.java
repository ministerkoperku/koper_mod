package net.mcreator.kopermod.client.model;

import net.minecraft.world.entity.Entity;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.client.model.geom.builders.PartDefinition;
import net.minecraft.client.model.geom.builders.MeshDefinition;
import net.minecraft.client.model.geom.builders.LayerDefinition;
import net.minecraft.client.model.geom.builders.CubeListBuilder;
import net.minecraft.client.model.geom.builders.CubeDeformation;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.model.EntityModel;

import com.mojang.blaze3d.vertex.VertexConsumer;
import com.mojang.blaze3d.vertex.PoseStack;

// Made with Blockbench 4.12.5
// Exported for Minecraft version 1.17 or later with Mojang mappings
// Paste this class into your mod and generate all required imports
public class Modelrekinhaosu<T extends Entity> extends EntityModel<T> {
	// This layer location should be baked with EntityRendererProvider.Context in
	// the entity renderer and passed into this model's constructor
	public static final ModelLayerLocation LAYER_LOCATION = new ModelLayerLocation(ResourceLocation.fromNamespaceAndPath("koper_mod", "modelrekinhaosu"), "main");
	public final ModelPart bone4;
	public final ModelPart bone6;
	public final ModelPart bone12;
	public final ModelPart bone7;
	public final ModelPart bone5;
	public final ModelPart bone13;
	public final ModelPart bone14;
	public final ModelPart bone2;
	public final ModelPart bone;
	public final ModelPart bone8;
	public final ModelPart bone9;
	public final ModelPart bone3;
	public final ModelPart bone10;
	public final ModelPart bone11;

	public Modelrekinhaosu(ModelPart root) {
		this.bone4 = root.getChild("bone4");
		this.bone6 = this.bone4.getChild("bone6");
		this.bone12 = this.bone4.getChild("bone12");
		this.bone7 = this.bone4.getChild("bone7");
		this.bone5 = this.bone4.getChild("bone5");
		this.bone13 = root.getChild("bone13");
		this.bone14 = this.bone13.getChild("bone14");
		this.bone2 = this.bone14.getChild("bone2");
		this.bone = this.bone14.getChild("bone");
		this.bone8 = this.bone.getChild("bone8");
		this.bone9 = this.bone.getChild("bone9");
		this.bone3 = this.bone13.getChild("bone3");
		this.bone10 = root.getChild("bone10");
		this.bone11 = root.getChild("bone11");
	}

	public static LayerDefinition createBodyLayer() {
		MeshDefinition meshdefinition = new MeshDefinition();
		PartDefinition partdefinition = meshdefinition.getRoot();
		PartDefinition bone4 = partdefinition.addOrReplaceChild("bone4", CubeListBuilder.create(), PartPose.offset(-3.2F, 17.0F, -3.9F));
		PartDefinition bone6 = bone4.addOrReplaceChild("bone6", CubeListBuilder.create(), PartPose.offset(0.0F, 0.0F, 0.0F));
		PartDefinition cube_r1 = bone6
				.addOrReplaceChild(
						"cube_r1", CubeListBuilder.create().texOffs(58, 0).addBox(-6.8792F, -0.6624F, 0.8458F, 7.0F, 1.0F, 2.0F, new CubeDeformation(0.0F)).texOffs(50, 44)
								.addBox(-8.8791F, -0.6832F, -1.1648F, 9.0F, 1.0F, 2.0F, new CubeDeformation(0.0F)).texOffs(0, 33).addBox(-10.879F, -0.704F, -3.1755F, 11.0F, 1.0F, 2.0F, new CubeDeformation(0.0F)),
						PartPose.offsetAndRotation(0.0F, 0.0F, 0.0F, -0.0236F, 0.223F, -0.1858F));
		PartDefinition bone12 = bone4.addOrReplaceChild("bone12", CubeListBuilder.create().texOffs(0, 0).addBox(-4.0F, -8.0F, -9.0F, 8.0F, 8.0F, 12.0F, new CubeDeformation(0.1F)), PartPose.offset(3.2F, 3.0F, 3.9F));
		PartDefinition bone7 = bone4.addOrReplaceChild("bone7",
				CubeListBuilder.create().texOffs(40, 10).addBox(0.0F, -7.0F, 1.1F, 1.0F, 1.0F, 8.0F, new CubeDeformation(0.0F)).texOffs(34, 53).addBox(0.0F, -6.5F, 2.0F, 1.0F, 1.0F, 6.0F, new CubeDeformation(0.0F)).texOffs(16, 55)
						.addBox(0.0F, -5.5F, 1.5F, 1.0F, 1.0F, 6.0F, new CubeDeformation(0.0F)).texOffs(58, 31).addBox(0.0F, -4.5F, 0.9F, 1.0F, 1.0F, 6.0F, new CubeDeformation(0.0F)).texOffs(0, 59)
						.addBox(0.0F, -3.5F, 0.2F, 1.0F, 1.0F, 6.0F, new CubeDeformation(0.0F)).texOffs(30, 60).addBox(0.0F, -2.5F, -0.5F, 1.0F, 1.0F, 6.0F, new CubeDeformation(0.0F)).texOffs(14, 62)
						.addBox(0.0F, -9.2F, 5.1F, 1.0F, 3.0F, 4.0F, new CubeDeformation(0.0F)).texOffs(48, 59).addBox(0.0F, -1.5F, -1.1F, 1.0F, 1.0F, 6.0F, new CubeDeformation(0.0F)),
				PartPose.offset(2.7F, -4.1F, -1.6F));
		PartDefinition cube_r2 = bone7.addOrReplaceChild("cube_r2", CubeListBuilder.create().texOffs(26, 33).addBox(-0.5F, -0.8938F, 8.45F, 1.0F, 1.0F, 2.0F, new CubeDeformation(0.0F)),
				PartPose.offsetAndRotation(0.5F, -6.3F, 1.0F, 0.5236F, 0.0F, 0.0F));
		PartDefinition cube_r3 = bone7.addOrReplaceChild("cube_r3", CubeListBuilder.create().texOffs(72, 14).addBox(0.0F, -10.0F, 9.1F, 1.0F, 1.0F, 1.0F, new CubeDeformation(0.0F)), PartPose.offsetAndRotation(0.0F, 0.8F, 0.2F, 0.0436F, 0.0F, 0.0F));
		PartDefinition cube_r4 = bone7.addOrReplaceChild("cube_r4", CubeListBuilder.create().texOffs(0, 39).addBox(-0.5F, -1.8938F, 0.45F, 1.0F, 3.0F, 8.0F, new CubeDeformation(0.0F)),
				PartPose.offsetAndRotation(0.5F, -5.4F, 1.5F, 0.5236F, 0.0F, 0.0F));
		PartDefinition cube_r5 = bone7.addOrReplaceChild("cube_r5", CubeListBuilder.create().texOffs(28, 39).addBox(-0.5F, -0.8938F, 8.45F, 1.0F, 2.0F, 1.0F, new CubeDeformation(0.0F)),
				PartPose.offsetAndRotation(0.5F, -5.9F, 1.1F, 0.5236F, 0.0F, 0.0F));
		PartDefinition cube_r6 = bone7.addOrReplaceChild("cube_r6", CubeListBuilder.create().texOffs(50, 50).addBox(-0.5F, -1.5F, -6.9F, 1.0F, 2.0F, 7.0F, new CubeDeformation(0.0F)),
				PartPose.offsetAndRotation(0.5F, -6.2F, 2.4F, 1.0472F, 0.0F, 0.0F));
		PartDefinition bone5 = bone4.addOrReplaceChild("bone5", CubeListBuilder.create(), PartPose.offset(6.4F, 0.0F, -0.1F));
		PartDefinition cube_r7 = bone5
				.addOrReplaceChild(
						"cube_r7", CubeListBuilder.create().texOffs(58, 3).addBox(-0.2802F, -0.5922F, 0.9811F, 7.0F, 1.0F, 2.0F, new CubeDeformation(0.0F)).texOffs(50, 47)
								.addBox(-0.2802F, -0.5922F, -1.0189F, 9.0F, 1.0F, 2.0F, new CubeDeformation(0.0F)).texOffs(0, 36).addBox(-0.2802F, -0.5922F, -3.0189F, 11.0F, 1.0F, 2.0F, new CubeDeformation(0.0F)),
						PartPose.offsetAndRotation(0.0F, 0.0F, 0.0F, -0.0216F, -0.2122F, 0.1648F));
		PartDefinition bone13 = partdefinition.addOrReplaceChild("bone13", CubeListBuilder.create(), PartPose.offset(-0.4F, 16.1F, 1.9F));
		PartDefinition bone14 = bone13.addOrReplaceChild("bone14", CubeListBuilder.create(), PartPose.offset(-0.1F, 0.0F, 6.3F));
		PartDefinition bone2 = bone14.addOrReplaceChild("bone2",
				CubeListBuilder.create().texOffs(40, 0).addBox(-2.0F, -7.0F, -8.0F, 5.0F, 6.0F, 4.0F, new CubeDeformation(0.1F)).texOffs(26, 36).addBox(0.0F, -7.8F, -6.0F, 1.0F, 1.0F, 2.0F, new CubeDeformation(-0.2F)).texOffs(24, 62)
						.addBox(0.0F, -8.4F, -5.7F, 1.0F, 1.0F, 2.0F, new CubeDeformation(-0.2F)).texOffs(66, 55).addBox(0.0F, -9.6F, -5.0F, 1.0F, 1.0F, 2.0F, new CubeDeformation(-0.2F)).texOffs(62, 69)
						.addBox(0.0F, -9.0F, -5.3F, 1.0F, 1.0F, 2.0F, new CubeDeformation(-0.2F)),
				PartPose.offset(0.0F, 3.9F, 8.5F));
		PartDefinition cube_r8 = bone2.addOrReplaceChild("cube_r8", CubeListBuilder.create().texOffs(0, 71).addBox(-0.7F, -1.2F, -0.7F, 1.0F, 1.0F, 2.0F, new CubeDeformation(-0.2F)),
				PartPose.offsetAndRotation(0.3F, -0.5F, -4.8F, 0.0F, 0.0F, -3.1416F));
		PartDefinition cube_r9 = bone2.addOrReplaceChild("cube_r9",
				CubeListBuilder.create().texOffs(54, 70).addBox(-0.7F, -1.2F, -0.7F, 1.0F, 1.0F, 2.0F, new CubeDeformation(-0.2F)).texOffs(68, 69).addBox(-0.7F, -0.6F, -1.2F, 1.0F, 1.0F, 2.0F, new CubeDeformation(-0.2F)),
				PartPose.offsetAndRotation(0.3F, -0.9F, -5.0F, 0.0F, 0.0F, -3.1416F));
		PartDefinition cube_r10 = bone2.addOrReplaceChild("cube_r10", CubeListBuilder.create().texOffs(54, 66).addBox(-0.7F, -1.4002F, -1.9698F, 1.0F, 1.0F, 3.0F, new CubeDeformation(-0.2F)),
				PartPose.offsetAndRotation(0.3F, -0.9F, -4.8F, 0.9163F, 0.0F, -3.1416F));
		PartDefinition cube_r11 = bone2.addOrReplaceChild("cube_r11", CubeListBuilder.create().texOffs(10, 69).addBox(-1.0F, -0.5F, -3.8F, 1.0F, 1.0F, 4.0F, new CubeDeformation(-0.2F)),
				PartPose.offsetAndRotation(1.0F, -9.2F, -4.6F, 0.9163F, 0.0F, 0.0F));
		PartDefinition bone = bone14.addOrReplaceChild("bone", CubeListBuilder.create().texOffs(18, 44).addBox(-0.5F, -3.3F, -1.0F, 2.0F, 5.0F, 6.0F, new CubeDeformation(0.1F)), PartPose.offset(0.0F, 0.6F, 5.7F));
		PartDefinition bone8 = bone.addOrReplaceChild("bone8",
				CubeListBuilder.create().texOffs(58, 6).addBox(0.0F, -7.0F, 1.1F, 1.0F, 1.0F, 6.0F, new CubeDeformation(0.0F)).texOffs(62, 59).addBox(0.0F, -6.5F, 2.0F, 1.0F, 1.0F, 4.0F, new CubeDeformation(0.0F)).texOffs(18, 39)
						.addBox(0.0F, -5.5F, 1.5F, 1.0F, 1.0F, 4.0F, new CubeDeformation(0.0F)).texOffs(64, 20).addBox(0.0F, -4.5F, 0.9F, 1.0F, 1.0F, 4.0F, new CubeDeformation(0.0F)).texOffs(64, 25)
						.addBox(0.0F, -3.5F, 0.2F, 1.0F, 1.0F, 4.0F, new CubeDeformation(0.0F)).texOffs(62, 64).addBox(0.0F, -2.5F, -0.5F, 1.0F, 1.0F, 4.0F, new CubeDeformation(0.0F)).texOffs(0, 66)
						.addBox(0.0F, -1.5F, -1.1F, 1.0F, 1.0F, 4.0F, new CubeDeformation(0.0F)),
				PartPose.offset(0.0F, -2.3F, 1.8F));
		PartDefinition cube_r12 = bone8.addOrReplaceChild("cube_r12", CubeListBuilder.create().texOffs(34, 44).addBox(-0.5F, -1.5F, -6.9F, 1.0F, 2.0F, 7.0F, new CubeDeformation(0.0F)),
				PartPose.offsetAndRotation(0.5F, -6.2F, 2.4F, 1.0472F, 0.0F, 0.0F));
		PartDefinition bone9 = bone.addOrReplaceChild("bone9", CubeListBuilder.create(), PartPose.offset(1.0F, 0.7F, 2.8F));
		PartDefinition cube_r13 = bone9.addOrReplaceChild("cube_r13",
				CubeListBuilder.create().texOffs(58, 13).addBox(0.0F, -7.0F, 0.1F, 1.0F, 1.0F, 6.0F, new CubeDeformation(0.0F)).texOffs(68, 38).addBox(0.0F, -6.5F, 1.0F, 1.0F, 1.0F, 4.0F, new CubeDeformation(0.0F)).texOffs(58, 38)
						.addBox(0.0F, -5.5F, 0.5F, 1.0F, 1.0F, 4.0F, new CubeDeformation(0.0F)).texOffs(34, 67).addBox(0.0F, -4.5F, -0.1F, 1.0F, 1.0F, 4.0F, new CubeDeformation(0.0F)).texOffs(24, 67)
						.addBox(0.0F, -3.5F, -0.8F, 1.0F, 1.0F, 4.0F, new CubeDeformation(0.0F)).texOffs(66, 50).addBox(0.0F, -2.5F, -1.5F, 1.0F, 1.0F, 4.0F, new CubeDeformation(0.0F)).texOffs(44, 66)
						.addBox(0.0F, -1.5F, -2.1F, 1.0F, 1.0F, 4.0F, new CubeDeformation(0.0F)),
				PartPose.offsetAndRotation(0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 3.1416F));
		PartDefinition cube_r14 = bone9.addOrReplaceChild("cube_r14", CubeListBuilder.create().texOffs(0, 50).addBox(0.0F, -3.3876F, -0.8306F, 1.0F, 2.0F, 7.0F, new CubeDeformation(0.0F)),
				PartPose.offsetAndRotation(0.0F, 0.0F, 0.0F, 1.0472F, 0.0F, 3.1416F));
		PartDefinition bone3 = bone13.addOrReplaceChild("bone3", CubeListBuilder.create().texOffs(32, 31).addBox(-4.0F, -8.0F, -8.0F, 7.0F, 7.0F, 6.0F, new CubeDeformation(0.1F)), PartPose.offset(0.9F, 4.4F, 8.6F));
		PartDefinition bone10 = partdefinition.addOrReplaceChild("bone10", CubeListBuilder.create(), PartPose.offset(0.0F, 18.2F, -7.1F));
		PartDefinition cube_r15 = bone10.addOrReplaceChild("cube_r15",
				CubeListBuilder.create().texOffs(20, 71).addBox(-4.0F, -3.0F, -5.0F, 1.0F, 1.0F, 1.0F, new CubeDeformation(0.0F)).texOffs(6, 71).addBox(-11.0F, -3.0F, -5.0F, 1.0F, 1.0F, 1.0F, new CubeDeformation(0.0F)),
				PartPose.offsetAndRotation(7.0F, 0.0F, 0.0F, 0.3927F, 0.0F, 0.0F));
		PartDefinition cube_r16 = bone10.addOrReplaceChild("cube_r16",
				CubeListBuilder.create().texOffs(48, 71).addBox(-4.0F, -3.0F, -5.0F, 1.0F, 1.0F, 1.0F, new CubeDeformation(0.0F)).texOffs(44, 71).addBox(-11.0F, -3.0F, -5.0F, 1.0F, 1.0F, 1.0F, new CubeDeformation(0.0F)),
				PartPose.offsetAndRotation(7.0F, 0.7F, -1.7F, 0.3927F, 0.0F, 0.0F));
		PartDefinition cube_r17 = bone10.addOrReplaceChild("cube_r17",
				CubeListBuilder.create().texOffs(72, 6).addBox(-4.0F, -3.0F, -5.0F, 1.0F, 1.0F, 1.0F, new CubeDeformation(0.0F)).texOffs(44, 60).addBox(-6.0F, -4.0F, -5.0F, 1.0F, 2.0F, 1.0F, new CubeDeformation(0.0F)).texOffs(30, 55)
						.addBox(-9.0F, -4.0F, -5.0F, 1.0F, 2.0F, 1.0F, new CubeDeformation(0.0F)).texOffs(72, 8).addBox(-11.0F, -3.0F, -5.0F, 1.0F, 1.0F, 1.0F, new CubeDeformation(0.0F)),
				PartPose.offsetAndRotation(7.0F, 1.4F, -3.2F, 0.3927F, 0.0F, 0.0F));
		PartDefinition cube_r18 = bone10.addOrReplaceChild("cube_r18", CubeListBuilder.create().texOffs(32, 20).addBox(-4.0F, -2.0F, -8.0F, 8.0F, 3.0F, 8.0F, new CubeDeformation(0.0F)),
				PartPose.offsetAndRotation(0.0F, 0.2F, -0.5F, 0.3927F, 0.0F, 0.0F));
		PartDefinition bone11 = partdefinition.addOrReplaceChild("bone11",
				CubeListBuilder.create().texOffs(20, 69).addBox(3.0F, 3.9F, -4.0F, 1.0F, 1.0F, 1.0F, new CubeDeformation(0.0F)).texOffs(0, 20).addBox(-4.0F, -1.1F, -7.0F, 8.0F, 5.0F, 8.0F, new CubeDeformation(0.0F)).texOffs(10, 66)
						.addBox(3.0F, 3.9F, -6.0F, 1.0F, 1.0F, 1.0F, new CubeDeformation(0.0F)).texOffs(24, 65).addBox(2.0F, 3.9F, -7.0F, 1.0F, 1.0F, 1.0F, new CubeDeformation(0.0F)).texOffs(30, 58)
						.addBox(-1.0F, 3.9F, -7.0F, 1.0F, 1.0F, 1.0F, new CubeDeformation(0.0F)).texOffs(44, 63).addBox(0.0F, 3.9F, -7.0F, 1.0F, 1.0F, 1.0F, new CubeDeformation(0.0F)).texOffs(28, 42)
						.addBox(-3.0F, 3.9F, -7.0F, 1.0F, 1.0F, 1.0F, new CubeDeformation(0.0F)).texOffs(72, 12).addBox(-4.0F, 3.9F, -5.8F, 1.0F, 1.0F, 1.0F, new CubeDeformation(0.0F)).texOffs(72, 10)
						.addBox(-4.0F, 3.9F, -4.0F, 1.0F, 1.0F, 1.0F, new CubeDeformation(0.0F)),
				PartPose.offset(0.0F, 13.1F, -9.6F));
		return LayerDefinition.create(meshdefinition, 128, 128);
	}

	@Override
	public void renderToBuffer(PoseStack poseStack, VertexConsumer vertexConsumer, int packedLight, int packedOverlay, int rgb) {
		bone4.render(poseStack, vertexConsumer, packedLight, packedOverlay, rgb);
		bone13.render(poseStack, vertexConsumer, packedLight, packedOverlay, rgb);
		bone10.render(poseStack, vertexConsumer, packedLight, packedOverlay, rgb);
		bone11.render(poseStack, vertexConsumer, packedLight, packedOverlay, rgb);
	}

	public void setupAnim(T entity, float limbSwing, float limbSwingAmount, float ageInTicks, float netHeadYaw, float headPitch) {
	}
}