/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.kopermod.init;

import net.neoforged.neoforge.client.event.EntityRenderersEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.api.distmarker.Dist;

import net.mcreator.kopermod.client.model.Modelszkinid1i1;
import net.mcreator.kopermod.client.model.Modelszkinid1i;
import net.mcreator.kopermod.client.model.Modelszepyacz;
import net.mcreator.kopermod.client.model.Modelrekinhaosu;
import net.mcreator.kopermod.client.model.Modelmrocznecmy;
import net.mcreator.kopermod.client.model.Modelleviatan_haosu;
import net.mcreator.kopermod.client.model.Modelkoperkorona;
import net.mcreator.kopermod.client.model.Modelkoperkmojmaps2;
import net.mcreator.kopermod.client.model.Modelkoper;
import net.mcreator.kopermod.client.model.ModelCustomModel;

@EventBusSubscriber(bus = EventBusSubscriber.Bus.MOD, value = {Dist.CLIENT})
public class KoperModModModels {
	@SubscribeEvent
	public static void registerLayerDefinitions(EntityRenderersEvent.RegisterLayerDefinitions event) {
		event.registerLayerDefinition(Modelszepyacz.LAYER_LOCATION, Modelszepyacz::createBodyLayer);
		event.registerLayerDefinition(ModelCustomModel.LAYER_LOCATION, ModelCustomModel::createBodyLayer);
		event.registerLayerDefinition(Modelkoperkmojmaps2.LAYER_LOCATION, Modelkoperkmojmaps2::createBodyLayer);
		event.registerLayerDefinition(Modelszkinid1i1.LAYER_LOCATION, Modelszkinid1i1::createBodyLayer);
		event.registerLayerDefinition(Modelkoperkorona.LAYER_LOCATION, Modelkoperkorona::createBodyLayer);
		event.registerLayerDefinition(Modelmrocznecmy.LAYER_LOCATION, Modelmrocznecmy::createBodyLayer);
		event.registerLayerDefinition(Modelkoper.LAYER_LOCATION, Modelkoper::createBodyLayer);
		event.registerLayerDefinition(Modelrekinhaosu.LAYER_LOCATION, Modelrekinhaosu::createBodyLayer);
		event.registerLayerDefinition(Modelszkinid1i.LAYER_LOCATION, Modelszkinid1i::createBodyLayer);
		event.registerLayerDefinition(Modelleviatan_haosu.LAYER_LOCATION, Modelleviatan_haosu::createBodyLayer);
	}
}