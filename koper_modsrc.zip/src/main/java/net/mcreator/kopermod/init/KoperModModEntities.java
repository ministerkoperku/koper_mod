/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.kopermod.init;

import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.DeferredHolder;
import net.neoforged.neoforge.event.entity.RegisterSpawnPlacementsEvent;
import net.neoforged.neoforge.event.entity.EntityAttributeCreationEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.bus.api.SubscribeEvent;

import net.minecraft.world.entity.MobCategory;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.Entity;
import net.minecraft.core.registries.Registries;

import net.mcreator.kopermod.entity.XaltorgathEntity;
import net.mcreator.kopermod.entity.SzeptaczciszyEntity;
import net.mcreator.kopermod.entity.SpringikoperEntity;
import net.mcreator.kopermod.entity.MrocznecmyEntity;
import net.mcreator.kopermod.entity.MiniMLeviatanyhaosuEntity;
import net.mcreator.kopermod.entity.LeviatanhaosuEntity;
import net.mcreator.kopermod.entity.KoperdinoEntity;
import net.mcreator.kopermod.entity.HaoticsharkEntity;
import net.mcreator.kopermod.entity.EternalkoperkingEntity;
import net.mcreator.kopermod.KoperModMod;

@EventBusSubscriber(bus = EventBusSubscriber.Bus.MOD)
public class KoperModModEntities {
	public static final DeferredRegister<EntityType<?>> REGISTRY = DeferredRegister.create(Registries.ENTITY_TYPE, KoperModMod.MODID);
	public static final DeferredHolder<EntityType<?>, EntityType<SpringikoperEntity>> SPRINGIKOPER = register("springikoper",
			EntityType.Builder.<SpringikoperEntity>of(SpringikoperEntity::new, MobCategory.MONSTER).setShouldReceiveVelocityUpdates(true).setTrackingRange(88).setUpdateInterval(3)

					.ridingOffset(-0.6f).sized(0.6f, 1.8f));
	public static final DeferredHolder<EntityType<?>, EntityType<KoperdinoEntity>> KOPERDINO = register("koperdino",
			EntityType.Builder.<KoperdinoEntity>of(KoperdinoEntity::new, MobCategory.MONSTER).setShouldReceiveVelocityUpdates(true).setTrackingRange(130).setUpdateInterval(3)

					.sized(1f, 1.7f));
	public static final DeferredHolder<EntityType<?>, EntityType<EternalkoperkingEntity>> ETERNALKOPERKING = register("eternalkoperking",
			EntityType.Builder.<EternalkoperkingEntity>of(EternalkoperkingEntity::new, MobCategory.MONSTER).setShouldReceiveVelocityUpdates(true).setTrackingRange(150).setUpdateInterval(3)

					.ridingOffset(-0.6f).sized(0.6f, 1.8f));
	public static final DeferredHolder<EntityType<?>, EntityType<LeviatanhaosuEntity>> LEVIATANHAOSU = register("leviatanhaosu",
			EntityType.Builder.<LeviatanhaosuEntity>of(LeviatanhaosuEntity::new, MobCategory.MONSTER).setShouldReceiveVelocityUpdates(true).setTrackingRange(140).setUpdateInterval(3)

					.sized(1f, 2f));
	public static final DeferredHolder<EntityType<?>, EntityType<MiniMLeviatanyhaosuEntity>> MINI_M_LEVIATANYHAOSU = register("mini_m_leviatanyhaosu",
			EntityType.Builder.<MiniMLeviatanyhaosuEntity>of(MiniMLeviatanyhaosuEntity::new, MobCategory.MONSTER).setShouldReceiveVelocityUpdates(true).setTrackingRange(130).setUpdateInterval(3)

					.sized(0.6f, 1.8f));
	public static final DeferredHolder<EntityType<?>, EntityType<HaoticsharkEntity>> HAOTICSHARK = register("haoticshark",
			EntityType.Builder.<HaoticsharkEntity>of(HaoticsharkEntity::new, MobCategory.WATER_CREATURE).setShouldReceiveVelocityUpdates(true).setTrackingRange(140).setUpdateInterval(3).fireImmune()

					.sized(0.6f, 1.8f));
	public static final DeferredHolder<EntityType<?>, EntityType<SzeptaczciszyEntity>> SZEPTACZCISZY = register("szeptaczciszy",
			EntityType.Builder.<SzeptaczciszyEntity>of(SzeptaczciszyEntity::new, MobCategory.MONSTER).setShouldReceiveVelocityUpdates(true).setTrackingRange(120).setUpdateInterval(3).fireImmune()

					.sized(0.6f, 1.8f));
	public static final DeferredHolder<EntityType<?>, EntityType<MrocznecmyEntity>> MROCZNECMY = register("mrocznecmy",
			EntityType.Builder.<MrocznecmyEntity>of(MrocznecmyEntity::new, MobCategory.MONSTER).setShouldReceiveVelocityUpdates(true).setTrackingRange(120).setUpdateInterval(3).fireImmune()

					.sized(0.6f, 1.8f));
	public static final DeferredHolder<EntityType<?>, EntityType<XaltorgathEntity>> XALTORGATH = register("xaltorgath",
			EntityType.Builder.<XaltorgathEntity>of(XaltorgathEntity::new, MobCategory.MONSTER).setShouldReceiveVelocityUpdates(true).setTrackingRange(120).setUpdateInterval(3).fireImmune()

					.sized(0.6f, 1.8f));

	// Start of user code block custom entities
	// End of user code block custom entities
	private static <T extends Entity> DeferredHolder<EntityType<?>, EntityType<T>> register(String registryname, EntityType.Builder<T> entityTypeBuilder) {
		return REGISTRY.register(registryname, () -> (EntityType<T>) entityTypeBuilder.build(registryname));
	}

	@SubscribeEvent
	public static void init(RegisterSpawnPlacementsEvent event) {
		SpringikoperEntity.init(event);
		KoperdinoEntity.init(event);
		EternalkoperkingEntity.init(event);
		LeviatanhaosuEntity.init(event);
		MiniMLeviatanyhaosuEntity.init(event);
		HaoticsharkEntity.init(event);
		SzeptaczciszyEntity.init(event);
		MrocznecmyEntity.init(event);
		XaltorgathEntity.init(event);
	}

	@SubscribeEvent
	public static void registerAttributes(EntityAttributeCreationEvent event) {
		event.put(SPRINGIKOPER.get(), SpringikoperEntity.createAttributes().build());
		event.put(KOPERDINO.get(), KoperdinoEntity.createAttributes().build());
		event.put(ETERNALKOPERKING.get(), EternalkoperkingEntity.createAttributes().build());
		event.put(LEVIATANHAOSU.get(), LeviatanhaosuEntity.createAttributes().build());
		event.put(MINI_M_LEVIATANYHAOSU.get(), MiniMLeviatanyhaosuEntity.createAttributes().build());
		event.put(HAOTICSHARK.get(), HaoticsharkEntity.createAttributes().build());
		event.put(SZEPTACZCISZY.get(), SzeptaczciszyEntity.createAttributes().build());
		event.put(MROCZNECMY.get(), MrocznecmyEntity.createAttributes().build());
		event.put(XALTORGATH.get(), XaltorgathEntity.createAttributes().build());
	}
}