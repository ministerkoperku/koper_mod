/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.kopermod.init;

import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.DeferredItem;
import net.neoforged.neoforge.registries.DeferredHolder;
import net.neoforged.neoforge.common.DeferredSpawnEggItem;
import net.neoforged.fml.event.lifecycle.FMLClientSetupEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.api.distmarker.OnlyIn;
import net.neoforged.api.distmarker.Dist;

import net.minecraft.world.level.block.Block;
import net.minecraft.world.item.Rarity;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.BlockItem;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.client.renderer.item.ItemProperties;

import net.mcreator.kopermod.item.WymiarhaosuItem;
import net.mcreator.kopermod.item.SpeederItem;
import net.mcreator.kopermod.item.Omega_koperkumSwordItem;
import net.mcreator.kopermod.item.Omega_koperkumShovelItem;
import net.mcreator.kopermod.item.Omega_koperkumPickaxeItem;
import net.mcreator.kopermod.item.Omega_koperkumItem;
import net.mcreator.kopermod.item.Omega_koperkumHoeItem;
import net.mcreator.kopermod.item.Omega_koperkumAxeItem;
import net.mcreator.kopermod.item.Omega_koperkumArmorItem;
import net.mcreator.kopermod.item.LongerlongswordItem;
import net.mcreator.kopermod.item.LeviatansscaleItem;
import net.mcreator.kopermod.item.LeviatansmeatItem;
import net.mcreator.kopermod.item.LeviatanscaleSwordItem;
import net.mcreator.kopermod.item.LeviatanscaleShovelItem;
import net.mcreator.kopermod.item.LeviatanscalePickaxeItem;
import net.mcreator.kopermod.item.LeviatanscaleHoeItem;
import net.mcreator.kopermod.item.LeviatanscaleAxeItem;
import net.mcreator.kopermod.item.LeviatanscaleArmorItem;
import net.mcreator.kopermod.item.KopertestArmorItem;
import net.mcreator.kopermod.item.KoperkumupgrageItem;
import net.mcreator.kopermod.item.Koperkumarmorv2Item;
import net.mcreator.kopermod.item.KoperkumarmorItem;
import net.mcreator.kopermod.item.KoperedwardenshieldBADItem;
import net.mcreator.kopermod.item.Kopered_wardenSwordItem;
import net.mcreator.kopermod.item.Kopered_wardenShovelItem;
import net.mcreator.kopermod.item.Kopered_wardenPickaxeItem;
import net.mcreator.kopermod.item.Kopered_wardenHoeItem;
import net.mcreator.kopermod.item.Kopered_wardenAxeItem;
import net.mcreator.kopermod.item.EternalItem;
import net.mcreator.kopermod.item.CoperkumrystalSwordItem;
import net.mcreator.kopermod.item.CoperkumrystalShovelItem;
import net.mcreator.kopermod.item.CoperkumrystalPickaxeItem;
import net.mcreator.kopermod.item.CoperkumrystalHoeItem;
import net.mcreator.kopermod.item.CoperkumrystalAxeItem;
import net.mcreator.kopermod.item.CoperkumrystalArmorItem;
import net.mcreator.kopermod.item.CoperkumcrystalItem;
import net.mcreator.kopermod.item.CoperkumDustItem;
import net.mcreator.kopermod.item.BloodItem;
import net.mcreator.kopermod.KoperModMod;

public class KoperModModItems {
	public static final DeferredRegister.Items REGISTRY = DeferredRegister.createItems(KoperModMod.MODID);
	public static final DeferredItem<Item> COPERKUM_DUST = REGISTRY.register("coperkum_dust", CoperkumDustItem::new);
	public static final DeferredItem<Item> COPERKUM_ORE = block(KoperModModBlocks.COPERKUM_ORE);
	public static final DeferredItem<Item> COPERKUM_BLOCK = block(KoperModModBlocks.COPERKUM_BLOCK);
	public static final DeferredItem<Item> COPERKUMCRYSTAL = REGISTRY.register("coperkumcrystal", CoperkumcrystalItem::new);
	public static final DeferredItem<Item> COPERKUMRYSTAL_PICKAXE = REGISTRY.register("coperkumrystal_pickaxe", CoperkumrystalPickaxeItem::new);
	public static final DeferredItem<Item> COPERKUMRYSTAL_AXE = REGISTRY.register("coperkumrystal_axe", CoperkumrystalAxeItem::new);
	public static final DeferredItem<Item> COPERKUMRYSTAL_SWORD = REGISTRY.register("coperkumrystal_sword", CoperkumrystalSwordItem::new);
	public static final DeferredItem<Item> COPERKUMRYSTAL_SHOVEL = REGISTRY.register("coperkumrystal_shovel", CoperkumrystalShovelItem::new);
	public static final DeferredItem<Item> COPERKUMRYSTAL_HOE = REGISTRY.register("coperkumrystal_hoe", CoperkumrystalHoeItem::new);
	public static final DeferredItem<Item> COPERKUMRYSTAL_ARMOR_HELMET = REGISTRY.register("coperkumrystal_armor_helmet", CoperkumrystalArmorItem.Helmet::new);
	public static final DeferredItem<Item> COPERKUMRYSTAL_ARMOR_CHESTPLATE = REGISTRY.register("coperkumrystal_armor_chestplate", CoperkumrystalArmorItem.Chestplate::new);
	public static final DeferredItem<Item> COPERKUMRYSTAL_ARMOR_LEGGINGS = REGISTRY.register("coperkumrystal_armor_leggings", CoperkumrystalArmorItem.Leggings::new);
	public static final DeferredItem<Item> COPERKUMRYSTAL_ARMOR_BOOTS = REGISTRY.register("coperkumrystal_armor_boots", CoperkumrystalArmorItem.Boots::new);
	public static final DeferredItem<Item> KOPERKUMUPGRAGE = REGISTRY.register("koperkumupgrage", KoperkumupgrageItem::new);
	public static final DeferredItem<Item> KOPERKUMARMORV_2_CHESTPLATE = REGISTRY.register("koperkumarmorv_2_chestplate", Koperkumarmorv2Item.Chestplate::new);
	public static final DeferredItem<Item> KOPERKUMARMORV_2_LEGGINGS = REGISTRY.register("koperkumarmorv_2_leggings", Koperkumarmorv2Item.Leggings::new);
	public static final DeferredItem<Item> KOPERKUMARMOR_CHESTPLATE = REGISTRY.register("koperkumarmor_chestplate", KoperkumarmorItem.Chestplate::new);
	public static final DeferredItem<Item> KOPERKUMARMOR_LEGGINGS = REGISTRY.register("koperkumarmor_leggings", KoperkumarmorItem.Leggings::new);
	public static final DeferredItem<Item> SPRINGIKOPER_SPAWN_EGG = REGISTRY.register("springikoper_spawn_egg", () -> new DeferredSpawnEggItem(KoperModModEntities.SPRINGIKOPER, -154, -16751104, new Item.Properties()));
	public static final DeferredItem<Item> KOPERTEST_ARMOR_HELMET = REGISTRY.register("kopertest_armor_helmet", KopertestArmorItem.Helmet::new);
	public static final DeferredItem<Item> KOPERTEST_ARMOR_CHESTPLATE = REGISTRY.register("kopertest_armor_chestplate", KopertestArmorItem.Chestplate::new);
	public static final DeferredItem<Item> KOPERTEST_ARMOR_LEGGINGS = REGISTRY.register("kopertest_armor_leggings", KopertestArmorItem.Leggings::new);
	public static final DeferredItem<Item> KOPERTEST_ARMOR_BOOTS = REGISTRY.register("kopertest_armor_boots", KopertestArmorItem.Boots::new);
	public static final DeferredItem<Item> KOPEREDWARDENSHIELD_BAD = REGISTRY.register("koperedwardenshield_bad", KoperedwardenshieldBADItem::new);
	public static final DeferredItem<Item> KOPERDINO_SPAWN_EGG = REGISTRY.register("koperdino_spawn_egg", () -> new DeferredSpawnEggItem(KoperModModEntities.KOPERDINO, -13434829, -13421824, new Item.Properties()));
	public static final DeferredItem<Item> LONGERLONGSWORD = REGISTRY.register("longerlongsword", LongerlongswordItem::new);
	public static final DeferredItem<Item> KOPERED_WARDEN_PICKAXE = REGISTRY.register("kopered_warden_pickaxe", Kopered_wardenPickaxeItem::new);
	public static final DeferredItem<Item> KOPERED_WARDEN_AXE = REGISTRY.register("kopered_warden_axe", Kopered_wardenAxeItem::new);
	public static final DeferredItem<Item> KOPERED_WARDEN_SWORD = REGISTRY.register("kopered_warden_sword", Kopered_wardenSwordItem::new);
	public static final DeferredItem<Item> KOPERED_WARDEN_SHOVEL = REGISTRY.register("kopered_warden_shovel", Kopered_wardenShovelItem::new);
	public static final DeferredItem<Item> KOPERED_WARDEN_HOE = REGISTRY.register("kopered_warden_hoe", Kopered_wardenHoeItem::new);
	public static final DeferredItem<Item> ETERNAL_HELMET = REGISTRY.register("eternal_helmet", EternalItem.Helmet::new);
	public static final DeferredItem<Item> ETERNAL_CHESTPLATE = REGISTRY.register("eternal_chestplate", EternalItem.Chestplate::new);
	public static final DeferredItem<Item> ETERNALKOPERKING_SPAWN_EGG = REGISTRY.register("eternalkoperking_spawn_egg", () -> new DeferredSpawnEggItem(KoperModModEntities.ETERNALKOPERKING, -5505024, -15853056, new Item.Properties()));
	public static final DeferredItem<Item> OMEGA_KOPERKUM = REGISTRY.register("omega_koperkum", Omega_koperkumItem::new);
	public static final DeferredItem<Item> OMEGA_KOPERKUM_BLOCK = block(KoperModModBlocks.OMEGA_KOPERKUM_BLOCK);
	public static final DeferredItem<Item> OMEGA_KOPERKUM_PICKAXE = REGISTRY.register("omega_koperkum_pickaxe", Omega_koperkumPickaxeItem::new);
	public static final DeferredItem<Item> OMEGA_KOPERKUM_AXE = REGISTRY.register("omega_koperkum_axe", Omega_koperkumAxeItem::new);
	public static final DeferredItem<Item> OMEGA_KOPERKUM_SWORD = REGISTRY.register("omega_koperkum_sword", Omega_koperkumSwordItem::new);
	public static final DeferredItem<Item> OMEGA_KOPERKUM_SHOVEL = REGISTRY.register("omega_koperkum_shovel", Omega_koperkumShovelItem::new);
	public static final DeferredItem<Item> OMEGA_KOPERKUM_HOE = REGISTRY.register("omega_koperkum_hoe", Omega_koperkumHoeItem::new);
	public static final DeferredItem<Item> OMEGA_KOPERKUM_ARMOR_HELMET = REGISTRY.register("omega_koperkum_armor_helmet", Omega_koperkumArmorItem.Helmet::new);
	public static final DeferredItem<Item> OMEGA_KOPERKUM_ARMOR_CHESTPLATE = REGISTRY.register("omega_koperkum_armor_chestplate", Omega_koperkumArmorItem.Chestplate::new);
	public static final DeferredItem<Item> OMEGA_KOPERKUM_ARMOR_LEGGINGS = REGISTRY.register("omega_koperkum_armor_leggings", Omega_koperkumArmorItem.Leggings::new);
	public static final DeferredItem<Item> OMEGA_KOPERKUM_ARMOR_BOOTS = REGISTRY.register("omega_koperkum_armor_boots", Omega_koperkumArmorItem.Boots::new);
	public static final DeferredItem<Item> LEVIATANHAOSU_SPAWN_EGG = REGISTRY.register("leviatanhaosu_spawn_egg", () -> new DeferredSpawnEggItem(KoperModModEntities.LEVIATANHAOSU, -13434829, -6750208, new Item.Properties()));
	public static final DeferredItem<Item> LEVIATANSMEAT = REGISTRY.register("leviatansmeat", LeviatansmeatItem::new);
	public static final DeferredItem<Item> MINI_M_LEVIATANYHAOSU_SPAWN_EGG = REGISTRY.register("mini_m_leviatanyhaosu_spawn_egg", () -> new DeferredSpawnEggItem(KoperModModEntities.MINI_M_LEVIATANYHAOSU, -12255136, -1572864, new Item.Properties()));
	public static final DeferredItem<Item> WYMIARHAOSU = REGISTRY.register("wymiarhaosu", WymiarhaosuItem::new);
	public static final DeferredItem<Item> LEVIATANSSCALE = REGISTRY.register("leviatansscale", LeviatansscaleItem::new);
	public static final DeferredItem<Item> LEVIATANSCALE_PICKAXE = REGISTRY.register("leviatanscale_pickaxe", LeviatanscalePickaxeItem::new);
	public static final DeferredItem<Item> LEVIATANSCALE_AXE = REGISTRY.register("leviatanscale_axe", LeviatanscaleAxeItem::new);
	public static final DeferredItem<Item> LEVIATANSCALE_SWORD = REGISTRY.register("leviatanscale_sword", LeviatanscaleSwordItem::new);
	public static final DeferredItem<Item> LEVIATANSCALE_SHOVEL = REGISTRY.register("leviatanscale_shovel", LeviatanscaleShovelItem::new);
	public static final DeferredItem<Item> LEVIATANSCALE_HOE = REGISTRY.register("leviatanscale_hoe", LeviatanscaleHoeItem::new);
	public static final DeferredItem<Item> LEVIATANSCALE_ARMOR_HELMET = REGISTRY.register("leviatanscale_armor_helmet", LeviatanscaleArmorItem.Helmet::new);
	public static final DeferredItem<Item> LEVIATANSCALE_ARMOR_CHESTPLATE = REGISTRY.register("leviatanscale_armor_chestplate", LeviatanscaleArmorItem.Chestplate::new);
	public static final DeferredItem<Item> LEVIATANSCALE_ARMOR_LEGGINGS = REGISTRY.register("leviatanscale_armor_leggings", LeviatanscaleArmorItem.Leggings::new);
	public static final DeferredItem<Item> LEVIATANSCALE_ARMOR_BOOTS = REGISTRY.register("leviatanscale_armor_boots", LeviatanscaleArmorItem.Boots::new);
	public static final DeferredItem<Item> BLOOD_BUCKET = REGISTRY.register("blood_bucket", BloodItem::new);
	public static final DeferredItem<Item> HAOTICSHARK_SPAWN_EGG = REGISTRY.register("haoticshark_spawn_egg", () -> new DeferredSpawnEggItem(KoperModModEntities.HAOTICSHARK, -13434880, -6750157, new Item.Properties()));
	public static final DeferredItem<Item> SZEPTACZCISZY_SPAWN_EGG = REGISTRY.register("szeptaczciszy_spawn_egg", () -> new DeferredSpawnEggItem(KoperModModEntities.SZEPTACZCISZY, -13421824, -6750208, new Item.Properties()));
	public static final DeferredItem<Item> MROCZNECMY_SPAWN_EGG = REGISTRY.register("mrocznecmy_spawn_egg", () -> new DeferredSpawnEggItem(KoperModModEntities.MROCZNECMY, -10092544, -13434880, new Item.Properties()));
	public static final DeferredItem<Item> XALTORGATH_SPAWN_EGG = REGISTRY.register("xaltorgath_spawn_egg", () -> new DeferredSpawnEggItem(KoperModModEntities.XALTORGATH, -13434880, -13434829, new Item.Properties()));
	public static final DeferredItem<Item> CORE = block(KoperModModBlocks.CORE, new Item.Properties().stacksTo(1).rarity(Rarity.EPIC));
	public static final DeferredItem<Item> SPEEDER = REGISTRY.register("speeder", SpeederItem::new);

	// Start of user code block custom items
	// End of user code block custom items
	private static DeferredItem<Item> block(DeferredHolder<Block, Block> block) {
		return block(block, new Item.Properties());
	}

	private static DeferredItem<Item> block(DeferredHolder<Block, Block> block, Item.Properties properties) {
		return REGISTRY.register(block.getId().getPath(), () -> new BlockItem(block.get(), properties));
	}

	@EventBusSubscriber(bus = EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
	public static class ItemsClientSideHandler {
		@SubscribeEvent
		@OnlyIn(Dist.CLIENT)
		public static void clientLoad(FMLClientSetupEvent event) {
			event.enqueueWork(() -> {
				ItemProperties.register(KOPEREDWARDENSHIELD_BAD.get(), ResourceLocation.parse("minecraft:blocking"), ItemProperties.getProperty(new ItemStack(Items.SHIELD), ResourceLocation.parse("minecraft:blocking")));
			});
		}
	}
}