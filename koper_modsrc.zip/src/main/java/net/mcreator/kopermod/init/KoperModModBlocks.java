/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.kopermod.init;

import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.DeferredBlock;

import net.minecraft.world.level.block.Block;

import net.mcreator.kopermod.block.WymiarhaosuPortalBlock;
import net.mcreator.kopermod.block.Omega_koperkumBlockBlock;
import net.mcreator.kopermod.block.CoreBlock;
import net.mcreator.kopermod.block.CoperkumOreBlock;
import net.mcreator.kopermod.block.CoperkumBlockBlock;
import net.mcreator.kopermod.block.BloodBlock;
import net.mcreator.kopermod.KoperModMod;

public class KoperModModBlocks {
	public static final DeferredRegister.Blocks REGISTRY = DeferredRegister.createBlocks(KoperModMod.MODID);
	public static final DeferredBlock<Block> COPERKUM_ORE = REGISTRY.register("coperkum_ore", CoperkumOreBlock::new);
	public static final DeferredBlock<Block> COPERKUM_BLOCK = REGISTRY.register("coperkum_block", CoperkumBlockBlock::new);
	public static final DeferredBlock<Block> OMEGA_KOPERKUM_BLOCK = REGISTRY.register("omega_koperkum_block", Omega_koperkumBlockBlock::new);
	public static final DeferredBlock<Block> WYMIARHAOSU_PORTAL = REGISTRY.register("wymiarhaosu_portal", WymiarhaosuPortalBlock::new);
	public static final DeferredBlock<Block> BLOOD = REGISTRY.register("blood", BloodBlock::new);
	public static final DeferredBlock<Block> CORE = REGISTRY.register("core", CoreBlock::new);
	// Start of user code block custom blocks
	// End of user code block custom blocks
}