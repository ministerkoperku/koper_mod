/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.kopermod.init;

import net.neoforged.neoforge.client.event.EntityRenderersEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.api.distmarker.Dist;

import net.mcreator.kopermod.client.renderer.XaltorgathRenderer;
import net.mcreator.kopermod.client.renderer.SzeptaczciszyRenderer;
import net.mcreator.kopermod.client.renderer.SpringikoperRenderer;
import net.mcreator.kopermod.client.renderer.MrocznecmyRenderer;
import net.mcreator.kopermod.client.renderer.MiniMLeviatanyhaosuRenderer;
import net.mcreator.kopermod.client.renderer.LeviatanhaosuRenderer;
import net.mcreator.kopermod.client.renderer.KoperdinoRenderer;
import net.mcreator.kopermod.client.renderer.HaoticsharkRenderer;
import net.mcreator.kopermod.client.renderer.EternalkoperkingRenderer;

@EventBusSubscriber(bus = EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
public class KoperModModEntityRenderers {
	@SubscribeEvent
	public static void registerEntityRenderers(EntityRenderersEvent.RegisterRenderers event) {
		event.registerEntityRenderer(KoperModModEntities.SPRINGIKOPER.get(), SpringikoperRenderer::new);
		event.registerEntityRenderer(KoperModModEntities.KOPERDINO.get(), KoperdinoRenderer::new);
		event.registerEntityRenderer(KoperModModEntities.ETERNALKOPERKING.get(), EternalkoperkingRenderer::new);
		event.registerEntityRenderer(KoperModModEntities.LEVIATANHAOSU.get(), LeviatanhaosuRenderer::new);
		event.registerEntityRenderer(KoperModModEntities.MINI_M_LEVIATANYHAOSU.get(), MiniMLeviatanyhaosuRenderer::new);
		event.registerEntityRenderer(KoperModModEntities.HAOTICSHARK.get(), HaoticsharkRenderer::new);
		event.registerEntityRenderer(KoperModModEntities.SZEPTACZCISZY.get(), SzeptaczciszyRenderer::new);
		event.registerEntityRenderer(KoperModModEntities.MROCZNECMY.get(), MrocznecmyRenderer::new);
		event.registerEntityRenderer(KoperModModEntities.XALTORGATH.get(), XaltorgathRenderer::new);
	}
}