/*
 * MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.kopermod.init;

import net.neoforged.neoforge.registries.NeoForgeRegistries;
import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.DeferredHolder;
import net.neoforged.neoforge.fluids.FluidType;

import net.mcreator.kopermod.fluid.types.BloodFluidType;
import net.mcreator.kopermod.KoperModMod;

public class KoperModModFluidTypes {
	public static final DeferredRegister<FluidType> REGISTRY = DeferredRegister.create(NeoForgeRegistries.FLUID_TYPES, KoperModMod.MODID);
	public static final DeferredHolder<FluidType, FluidType> BLOOD_TYPE = REGISTRY.register("blood", () -> new BloodFluidType());
}