/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.kopermod.init;

import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.event.BuildCreativeModeTabContentsEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.bus.api.SubscribeEvent;

import net.minecraft.world.item.CreativeModeTabs;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.core.registries.Registries;

import net.mcreator.kopermod.KoperModMod;

@EventBusSubscriber(bus = EventBusSubscriber.Bus.MOD)
public class KoperModModTabs {
	public static final DeferredRegister<CreativeModeTab> REGISTRY = DeferredRegister.create(Registries.CREATIVE_MODE_TAB, KoperModMod.MODID);

	@SubscribeEvent
	public static void buildTabContentsVanilla(BuildCreativeModeTabContentsEvent tabData) {
		if (tabData.getTabKey() == CreativeModeTabs.INGREDIENTS) {
			tabData.accept(KoperModModItems.COPERKUM_DUST.get());
			tabData.accept(KoperModModItems.COPERKUMCRYSTAL.get());
			tabData.accept(KoperModModItems.KOPERKUMUPGRAGE.get());
			tabData.accept(KoperModModItems.OMEGA_KOPERKUM.get());
			tabData.accept(KoperModModItems.LEVIATANSSCALE.get());
		} else if (tabData.getTabKey() == CreativeModeTabs.BUILDING_BLOCKS) {
			tabData.accept(KoperModModBlocks.COPERKUM_ORE.get().asItem());
			tabData.accept(KoperModModBlocks.COPERKUM_BLOCK.get().asItem());
			tabData.accept(KoperModModBlocks.OMEGA_KOPERKUM_BLOCK.get().asItem());
			tabData.accept(KoperModModBlocks.CORE.get().asItem());
		} else if (tabData.getTabKey() == CreativeModeTabs.TOOLS_AND_UTILITIES) {
			tabData.accept(KoperModModItems.COPERKUMRYSTAL_PICKAXE.get());
			tabData.accept(KoperModModItems.COPERKUMRYSTAL_AXE.get());
			tabData.accept(KoperModModItems.COPERKUMRYSTAL_SHOVEL.get());
			tabData.accept(KoperModModItems.COPERKUMRYSTAL_HOE.get());
			tabData.accept(KoperModModItems.KOPEREDWARDENSHIELD_BAD.get());
			tabData.accept(KoperModModItems.KOPERED_WARDEN_PICKAXE.get());
			tabData.accept(KoperModModItems.KOPERED_WARDEN_AXE.get());
			tabData.accept(KoperModModItems.KOPERED_WARDEN_SHOVEL.get());
			tabData.accept(KoperModModItems.KOPERED_WARDEN_HOE.get());
			tabData.accept(KoperModModItems.OMEGA_KOPERKUM_PICKAXE.get());
			tabData.accept(KoperModModItems.OMEGA_KOPERKUM_AXE.get());
			tabData.accept(KoperModModItems.OMEGA_KOPERKUM_SHOVEL.get());
			tabData.accept(KoperModModItems.OMEGA_KOPERKUM_HOE.get());
			tabData.accept(KoperModModItems.WYMIARHAOSU.get());
			tabData.accept(KoperModModItems.LEVIATANSCALE_PICKAXE.get());
			tabData.accept(KoperModModItems.LEVIATANSCALE_AXE.get());
			tabData.accept(KoperModModItems.LEVIATANSCALE_SHOVEL.get());
			tabData.accept(KoperModModItems.LEVIATANSCALE_HOE.get());
			tabData.accept(KoperModModItems.BLOOD_BUCKET.get());
		} else if (tabData.getTabKey() == CreativeModeTabs.COMBAT) {
			tabData.accept(KoperModModItems.COPERKUMRYSTAL_SWORD.get());
			tabData.accept(KoperModModItems.COPERKUMRYSTAL_ARMOR_HELMET.get());
			tabData.accept(KoperModModItems.COPERKUMRYSTAL_ARMOR_CHESTPLATE.get());
			tabData.accept(KoperModModItems.COPERKUMRYSTAL_ARMOR_LEGGINGS.get());
			tabData.accept(KoperModModItems.COPERKUMRYSTAL_ARMOR_BOOTS.get());
			tabData.accept(KoperModModItems.KOPERKUMARMORV_2_CHESTPLATE.get());
			tabData.accept(KoperModModItems.KOPERKUMARMORV_2_LEGGINGS.get());
			tabData.accept(KoperModModItems.KOPERKUMARMOR_CHESTPLATE.get());
			tabData.accept(KoperModModItems.KOPERKUMARMOR_LEGGINGS.get());
			tabData.accept(KoperModModItems.KOPERTEST_ARMOR_HELMET.get());
			tabData.accept(KoperModModItems.KOPERTEST_ARMOR_CHESTPLATE.get());
			tabData.accept(KoperModModItems.KOPERTEST_ARMOR_LEGGINGS.get());
			tabData.accept(KoperModModItems.KOPERTEST_ARMOR_BOOTS.get());
			tabData.accept(KoperModModItems.LONGERLONGSWORD.get());
			tabData.accept(KoperModModItems.KOPERED_WARDEN_SWORD.get());
			tabData.accept(KoperModModItems.ETERNAL_HELMET.get());
			tabData.accept(KoperModModItems.ETERNAL_CHESTPLATE.get());
			tabData.accept(KoperModModItems.OMEGA_KOPERKUM_SWORD.get());
			tabData.accept(KoperModModItems.OMEGA_KOPERKUM_ARMOR_HELMET.get());
			tabData.accept(KoperModModItems.OMEGA_KOPERKUM_ARMOR_CHESTPLATE.get());
			tabData.accept(KoperModModItems.OMEGA_KOPERKUM_ARMOR_LEGGINGS.get());
			tabData.accept(KoperModModItems.OMEGA_KOPERKUM_ARMOR_BOOTS.get());
			tabData.accept(KoperModModItems.LEVIATANSCALE_SWORD.get());
			tabData.accept(KoperModModItems.LEVIATANSCALE_ARMOR_HELMET.get());
			tabData.accept(KoperModModItems.LEVIATANSCALE_ARMOR_CHESTPLATE.get());
			tabData.accept(KoperModModItems.LEVIATANSCALE_ARMOR_LEGGINGS.get());
			tabData.accept(KoperModModItems.LEVIATANSCALE_ARMOR_BOOTS.get());
			tabData.accept(KoperModModItems.SPEEDER.get());
		} else if (tabData.getTabKey() == CreativeModeTabs.SPAWN_EGGS) {
			tabData.accept(KoperModModItems.SPRINGIKOPER_SPAWN_EGG.get());
			tabData.accept(KoperModModItems.KOPERDINO_SPAWN_EGG.get());
			tabData.accept(KoperModModItems.ETERNALKOPERKING_SPAWN_EGG.get());
			tabData.accept(KoperModModItems.LEVIATANHAOSU_SPAWN_EGG.get());
			tabData.accept(KoperModModItems.MINI_M_LEVIATANYHAOSU_SPAWN_EGG.get());
			tabData.accept(KoperModModItems.HAOTICSHARK_SPAWN_EGG.get());
			tabData.accept(KoperModModItems.SZEPTACZCISZY_SPAWN_EGG.get());
			tabData.accept(KoperModModItems.MROCZNECMY_SPAWN_EGG.get());
			tabData.accept(KoperModModItems.XALTORGATH_SPAWN_EGG.get());
		} else if (tabData.getTabKey() == CreativeModeTabs.FOOD_AND_DRINKS) {
			tabData.accept(KoperModModItems.LEVIATANSMEAT.get());
		}
	}
}