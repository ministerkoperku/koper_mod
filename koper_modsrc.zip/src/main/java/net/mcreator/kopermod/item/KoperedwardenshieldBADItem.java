package net.mcreator.kopermod.item;

import net.minecraft.world.item.crafting.Ingredient;
import net.minecraft.world.item.ShieldItem;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Item;

import net.mcreator.kopermod.init.KoperModModItems;

public class KoperedwardenshieldBADItem extends ShieldItem {
	public KoperedwardenshieldBADItem() {
		super(new Item.Properties().durability(10000).fireResistant());
	}

	@Override
	public boolean isValidRepairItem(ItemStack itemstack, ItemStack repairitem) {
		return Ingredient.of(new ItemStack(KoperModModItems.KOPERKUMUPGRAGE.get())).test(repairitem);
	}
}