package net.mcreator.kopermod.item;

import net.minecraft.world.item.Rarity;
import net.minecraft.world.item.Item;

public class CoperkumcrystalItem extends Item {
	public CoperkumcrystalItem() {
		super(new Item.Properties().stacksTo(72).fireResistant().rarity(Rarity.RARE));
	}
}