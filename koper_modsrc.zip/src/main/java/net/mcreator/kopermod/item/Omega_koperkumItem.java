package net.mcreator.kopermod.item;

import net.minecraft.world.item.Item;

public class Omega_koperkumItem extends Item {
	public Omega_koperkumItem() {
		super(new Item.Properties());
	}
}