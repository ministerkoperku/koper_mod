package net.mcreator.kopermod.item;

import net.minecraft.world.item.Rarity;
import net.minecraft.world.item.Item;

public class CoperkumDustItem extends Item {
	public CoperkumDustItem() {
		super(new Item.Properties().rarity(Rarity.RARE));
	}
}