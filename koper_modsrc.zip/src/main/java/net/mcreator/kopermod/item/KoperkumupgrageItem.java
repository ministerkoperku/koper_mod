package net.mcreator.kopermod.item;

import net.minecraft.world.item.Rarity;
import net.minecraft.world.item.Item;

public class KoperkumupgrageItem extends Item {
	public KoperkumupgrageItem() {
		super(new Item.Properties().stacksTo(12).rarity(Rarity.RARE));
	}
}