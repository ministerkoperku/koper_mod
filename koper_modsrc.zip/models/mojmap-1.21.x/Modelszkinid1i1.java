// Made with Blockbench 4.12.5
// Exported for Minecraft version 1.17 or later with Mojang mappings
// Paste this class into your mod and generate all required imports

public class Modelszkinid1i1<T extends Entity> extends EntityModel<T> {
	// This layer location should be baked with EntityRendererProvider.Context in
	// the entity renderer and passed into this model's constructor
	public static final ModelLayerLocation LAYER_LOCATION = new ModelLayerLocation(
			new ResourceLocation("modid", "szkinid1i1"), "main");
	private final ModelPart main;
	private final ModelPart Body;
	private final ModelPart RightArm;
	private final ModelPart LeftArm;
	private final ModelPart RightLeg;
	private final ModelPart LeftLeg;

	public Modelszkinid1i1(ModelPart root) {
		this.main = root.getChild("main");
		this.Body = this.main.getChild("Body");
		this.RightArm = this.main.getChild("RightArm");
		this.LeftArm = this.main.getChild("LeftArm");
		this.RightLeg = this.main.getChild("RightLeg");
		this.LeftLeg = this.main.getChild("LeftLeg");
	}

	public static LayerDefinition createBodyLayer() {
		MeshDefinition meshdefinition = new MeshDefinition();
		PartDefinition partdefinition = meshdefinition.getRoot();

		PartDefinition main = partdefinition.addOrReplaceChild("main", CubeListBuilder.create(),
				PartPose.offset(0.0F, 24.0F, 0.0F));

		PartDefinition Body = main.addOrReplaceChild("Body",
				CubeListBuilder.create().texOffs(26, 0)
						.addBox(-4.0F, 0.0F, 3.0F, 8.0F, 11.0F, 1.0F, new CubeDeformation(0.25F)).texOffs(0, 0)
						.addBox(-4.0F, 0.0F, -2.5F, 8.0F, 12.0F, 5.0F, new CubeDeformation(0.25F)).texOffs(32, 40)
						.addBox(-0.5F, 1.0F, -0.5F, 1.0F, 11.0F, 1.0F, new CubeDeformation(0.25F)).texOffs(32, 31)
						.addBox(-4.0F, 3.0F, 4.5F, 8.0F, 8.0F, 1.0F, new CubeDeformation(0.25F)).texOffs(36, 12)
						.addBox(-3.0F, 5.0F, 4.8F, 6.0F, 5.0F, 1.0F, new CubeDeformation(0.25F)),
				PartPose.offset(0.0F, -24.0F, 0.0F));

		PartDefinition BodyLayer_r1 = Body.addOrReplaceChild("BodyLayer_r1",
				CubeListBuilder.create().texOffs(36, 22)
						.addBox(-4.9F, -23.5F, -5.7F, 3.0F, 1.0F, 3.0F, new CubeDeformation(0.25F)).texOffs(36, 26)
						.addBox(-3.9F, -22.5F, -4.7F, 1.0F, 2.0F, 1.0F, new CubeDeformation(0.25F)).texOffs(26, 12)
						.addBox(-3.9F, -26.5F, -4.7F, 1.0F, 3.0F, 1.0F, new CubeDeformation(0.25F)).texOffs(30, 12)
						.addBox(2.9F, -26.5F, -4.7F, 1.0F, 3.0F, 1.0F, new CubeDeformation(0.25F)).texOffs(40, 26)
						.addBox(2.9F, -22.5F, -4.7F, 1.0F, 2.0F, 1.0F, new CubeDeformation(0.25F)).texOffs(36, 18)
						.addBox(1.9F, -23.5F, -5.7F, 3.0F, 1.0F, 3.0F, new CubeDeformation(0.25F)),
				PartPose.offsetAndRotation(0.0F, 24.0F, 0.0F, -0.4363F, 0.0F, 0.0F));

		PartDefinition RightArm = main.addOrReplaceChild("RightArm", CubeListBuilder.create().texOffs(16, 31)
				.addBox(-3.0F, -2.0F, -2.0F, 4.0F, 9.0F, 4.0F, new CubeDeformation(0.25F)),
				PartPose.offset(-5.0F, -22.0F, 0.0F));

		PartDefinition LeftArm = main.addOrReplaceChild("LeftArm", CubeListBuilder.create().texOffs(0, 31).addBox(-1.0F,
				-2.0F, -2.0F, 4.0F, 9.0F, 4.0F, new CubeDeformation(0.25F)), PartPose.offset(5.0F, -22.0F, 0.0F));

		PartDefinition RightLeg = main.addOrReplaceChild("RightLeg", CubeListBuilder.create().texOffs(0, 17)
				.addBox(-2.1F, 0.0F, -2.5F, 4.0F, 9.0F, 5.0F, new CubeDeformation(0.25F)),
				PartPose.offset(-1.9F, -12.0F, 0.0F));

		PartDefinition LeftLeg = main.addOrReplaceChild("LeftLeg", CubeListBuilder.create().texOffs(18, 17).addBox(
				-1.9F, 0.0F, -2.5F, 4.0F, 9.0F, 5.0F, new CubeDeformation(0.25F)), PartPose.offset(1.9F, -12.0F, 0.0F));

		return LayerDefinition.create(meshdefinition, 64, 64);
	}

	@Override
	public void renderToBuffer(PoseStack poseStack, VertexConsumer vertexConsumer, int packedLight, int packedOverlay,
			float red, float green, float blue, float alpha) {
		main.render(poseStack, vertexConsumer, packedLight, packedOverlay, red, green, blue, alpha);
	}

	public void setupAnim(T entity, float limbSwing, float limbSwingAmount, float ageInTicks, float netHeadYaw,
			float headPitch) {
	}
}