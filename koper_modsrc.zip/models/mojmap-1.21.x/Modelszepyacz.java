// Made with Blockbench 4.12.5
// Exported for Minecraft version 1.17 or later with Mojang mappings
// Paste this class into your mod and generate all required imports

public class Modelszepyacz<T extends Entity> extends EntityModel<T> {
	// This layer location should be baked with EntityRendererProvider.Context in
	// the entity renderer and passed into this model's constructor
	public static final ModelLayerLocation LAYER_LOCATION = new ModelLayerLocation(
			new ResourceLocation("modid", "szepyacz"), "main");
	private final ModelPart bone5;
	private final ModelPart bone;
	private final ModelPart bone6;
	private final ModelPart bone4;
	private final ModelPart bone2;
	private final ModelPart bone3;

	public Modelszepyacz(ModelPart root) {
		this.bone5 = root.getChild("bone5");
		this.bone = root.getChild("bone");
		this.bone6 = root.getChild("bone6");
		this.bone4 = root.getChild("bone4");
		this.bone2 = root.getChild("bone2");
		this.bone3 = root.getChild("bone3");
	}

	public static LayerDefinition createBodyLayer() {
		MeshDefinition meshdefinition = new MeshDefinition();
		PartDefinition partdefinition = meshdefinition.getRoot();

		PartDefinition bone5 = partdefinition.addOrReplaceChild("bone5",
				CubeListBuilder.create().texOffs(28, 0)
						.addBox(-1.0F, 0.0F, -1.0F, 2.0F, 8.0F, 2.0F, new CubeDeformation(0.2F)).texOffs(0, 33)
						.addBox(-1.0F, 8.0F, -1.0F, 2.0F, 7.0F, 2.0F, new CubeDeformation(0.0F)).texOffs(30, 29)
						.addBox(-1.0F, 15.0F, -3.0F, 2.0F, 1.0F, 4.0F, new CubeDeformation(0.0F)),
				PartPose.offset(4.0F, 8.0F, 0.0F));

		PartDefinition bone = partdefinition.addOrReplaceChild("bone",
				CubeListBuilder.create().texOffs(0, 25)
						.addBox(-4.0F, 1.0F, -2.0F, 8.0F, 5.0F, 3.0F, new CubeDeformation(0.1F)).texOffs(0, 0)
						.addBox(-5.0F, -7.0F, -2.5F, 10.0F, 8.0F, 4.0F, new CubeDeformation(0.0F)).texOffs(28, 10)
						.addBox(-3.0F, 1.0F, -2.4F, 6.0F, 1.0F, 1.0F, new CubeDeformation(0.1F)),
				PartPose.offset(0.0F, 2.7F, 0.5F));

		PartDefinition bone6 = partdefinition.addOrReplaceChild("bone6",
				CubeListBuilder.create().texOffs(0, 12)
						.addBox(-4.0F, -9.0F, -2.0F, 8.0F, 8.0F, 5.0F, new CubeDeformation(0.0F)).texOffs(22, 25)
						.addBox(-3.0F, -1.0F, -1.0F, 6.0F, 1.0F, 3.0F, new CubeDeformation(0.0F)).texOffs(8, 33)
						.addBox(-3.0F, -1.0F, -2.0F, 6.0F, 1.0F, 1.0F, new CubeDeformation(0.0F)).texOffs(34, 17)
						.addBox(-2.0F, 0.0F, -2.0F, 4.0F, 1.0F, 1.0F, new CubeDeformation(0.0F)),
				PartPose.offset(0.0F, -4.3F, -0.5F));

		PartDefinition bone4 = partdefinition.addOrReplaceChild("bone4",
				CubeListBuilder.create().texOffs(22, 29)
						.addBox(1.0F, -1.5F, -1.0F, 2.0F, 8.0F, 2.0F, new CubeDeformation(0.0F)).texOffs(34, 19)
						.addBox(0.0F, -1.5F, -1.0F, 1.0F, 2.0F, 2.0F, new CubeDeformation(0.0F)),
				PartPose.offset(5.0F, -2.8F, 0.0F));

		PartDefinition cube_r1 = bone4.addOrReplaceChild("cube_r1",
				CubeListBuilder.create().texOffs(34, 34).addBox(-0.2F, 1.6743F, -0.626F, 1.0F, 3.0F, 1.0F,
						new CubeDeformation(-0.1F)),
				PartPose.offsetAndRotation(2.9F, 19.8F, -2.4F, -0.1682F, 0.1396F, 0.6863F));

		PartDefinition cube_r2 = bone4.addOrReplaceChild("cube_r2",
				CubeListBuilder.create().texOffs(36, 0).addBox(-0.2F, -0.3257F, -0.626F, 1.0F, 3.0F, 1.0F,
						new CubeDeformation(-0.1F)),
				PartPose.offsetAndRotation(2.2F, 19.0F, -2.2F, -0.211F, 0.056F, 0.2559F));

		PartDefinition cube_r3 = bone4.addOrReplaceChild("cube_r3",
				CubeListBuilder.create().texOffs(30, 34).addBox(-0.2F, 1.6743F, -0.626F, 1.0F, 3.0F, 1.0F,
						new CubeDeformation(-0.1F)),
				PartPose.offsetAndRotation(2.9F, 19.5F, -3.4F, -0.1682F, 0.1396F, 0.6863F));

		PartDefinition cube_r4 = bone4.addOrReplaceChild("cube_r4",
				CubeListBuilder.create().texOffs(16, 35).addBox(-0.2F, -0.3257F, -0.626F, 1.0F, 3.0F, 1.0F,
						new CubeDeformation(-0.1F)),
				PartPose.offsetAndRotation(2.2F, 18.7F, -3.2F, -0.211F, 0.056F, 0.2559F));

		PartDefinition cube_r5 = bone4.addOrReplaceChild("cube_r5",
				CubeListBuilder.create().texOffs(8, 35).addBox(-0.4737F, -0.3733F, -0.7333F, 1.0F, 3.0F, 1.0F,
						new CubeDeformation(-0.13F)),
				PartPose.offsetAndRotation(-0.5F, 18.8F, -3.0F, -0.2174F, 0.0189F, 0.0852F));

		PartDefinition cube_r6 = bone4.addOrReplaceChild("cube_r6",
				CubeListBuilder.create().texOffs(12, 35).addBox(11.8987F, 2.8604F, -1.0F, 1.0F, 3.0F, 1.0F,
						new CubeDeformation(-0.1F)),
				PartPose.offsetAndRotation(-4.8F, 6.2F, 0.0F, -0.1487F, 0.1603F, 0.8171F));

		PartDefinition cube_r7 = bone4.addOrReplaceChild("cube_r7",
				CubeListBuilder.create().texOffs(34, 12).addBox(-2.2F, -3.1132F, -0.527F, 2.0F, 3.0F, 2.0F,
						new CubeDeformation(0.0F)),
				PartPose.offsetAndRotation(3.2F, 18.9F, -3.3F, -0.2182F, 0.0F, 0.0F));

		PartDefinition cube_r8 = bone4.addOrReplaceChild("cube_r8",
				CubeListBuilder.create().texOffs(26, 12).addBox(5.8F, 0.0F, -1.0F, 2.0F, 10.0F, 2.0F,
						new CubeDeformation(0.0F)),
				PartPose.offsetAndRotation(-4.8F, 6.2F, 0.0F, -0.2182F, 0.0F, 0.0F));

		PartDefinition bone2 = partdefinition.addOrReplaceChild("bone2",
				CubeListBuilder.create().texOffs(30, 29)
						.addBox(-1.0F, 15.0F, -3.0F, 2.0F, 1.0F, 4.0F, new CubeDeformation(0.0F)).texOffs(0, 33)
						.addBox(-1.0F, 8.0F, -1.0F, 2.0F, 7.0F, 2.0F, new CubeDeformation(0.0F)).texOffs(28, 0)
						.addBox(-1.0F, 0.0F, -1.0F, 2.0F, 8.0F, 2.0F, new CubeDeformation(0.2F)),
				PartPose.offset(-4.0F, 8.0F, 0.0F));

		PartDefinition bone3 = partdefinition.addOrReplaceChild("bone3",
				CubeListBuilder.create().texOffs(34, 19)
						.addBox(-1.0F, -1.3F, -1.0F, 1.0F, 2.0F, 2.0F, new CubeDeformation(0.0F)).texOffs(22, 29)
						.addBox(-3.0F, -1.3F, -1.0F, 2.0F, 8.0F, 2.0F, new CubeDeformation(0.0F)),
				PartPose.offset(-5.0F, -3.0F, 0.0F));

		PartDefinition cube_r9 = bone3.addOrReplaceChild("cube_r9",
				CubeListBuilder.create().texOffs(12, 35).addBox(11.2813F, 11.789F, 2.4898F, 1.0F, 3.0F, 1.0F,
						new CubeDeformation(-0.1F)),
				PartPose.offsetAndRotation(-2.2F, 1.375F, 4.0F, -3.023F, 0.1284F, 2.3202F));

		PartDefinition cube_r10 = bone3.addOrReplaceChild("cube_r10",
				CubeListBuilder.create().texOffs(8, 35).addBox(-1.5487F, 18.319F, 2.5547F, 1.0F, 3.0F, 1.0F,
						new CubeDeformation(-0.13F)),
				PartPose.offsetAndRotation(-2.2F, 1.375F, 4.0F, -2.9677F, 0.0151F, 3.0556F));

		PartDefinition cube_r11 = bone3.addOrReplaceChild("cube_r11", CubeListBuilder.create().texOffs(30, 34)
				.addBox(12.7404F, 16.0071F, 2.423F, 1.0F, 3.0F, 1.0F, new CubeDeformation(-0.1F)).texOffs(34, 34)
				.addBox(12.7896F, 16.0657F, 3.4642F, 1.0F, 3.0F, 1.0F, new CubeDeformation(-0.1F)),
				PartPose.offsetAndRotation(-2.2F, 1.375F, 4.0F, -3.0073F, 0.1119F, 2.451F));

		PartDefinition cube_r12 = bone3.addOrReplaceChild("cube_r12",
				CubeListBuilder.create().texOffs(16, 35)
						.addBox(4.5812F, 17.518F, 2.4451F, 1.0F, 3.0F, 1.0F, new CubeDeformation(-0.1F)).texOffs(36, 0)
						.addBox(4.601F, 17.5919F, 3.4863F, 1.0F, 3.0F, 1.0F, new CubeDeformation(-0.1F)),
				PartPose.offsetAndRotation(-2.2F, 1.375F, 4.0F, -2.9729F, 0.045F, 2.8836F));

		PartDefinition cube_r13 = bone3.addOrReplaceChild("cube_r13",
				CubeListBuilder.create().texOffs(34, 12).addBox(-1.2F, 15.5769F, 2.4898F, 2.0F, 3.0F, 2.0F,
						new CubeDeformation(0.0F)),
				PartPose.offsetAndRotation(-2.2F, 1.375F, 4.0F, -2.9671F, 0.0F, 3.1416F));

		PartDefinition cube_r14 = bone3.addOrReplaceChild("cube_r14",
				CubeListBuilder.create().texOffs(26, 12).addBox(-1.2F, 5.5769F, 2.4898F, 2.0F, 10.0F, 2.0F,
						new CubeDeformation(0.0F)),
				PartPose.offsetAndRotation(-1.8F, 0.2F, -2.2F, -0.2182F, 0.0F, 0.0F));

		return LayerDefinition.create(meshdefinition, 64, 64);
	}

	@Override
	public void renderToBuffer(PoseStack poseStack, VertexConsumer vertexConsumer, int packedLight, int packedOverlay,
			float red, float green, float blue, float alpha) {
		bone5.render(poseStack, vertexConsumer, packedLight, packedOverlay, red, green, blue, alpha);
		bone.render(poseStack, vertexConsumer, packedLight, packedOverlay, red, green, blue, alpha);
		bone6.render(poseStack, vertexConsumer, packedLight, packedOverlay, red, green, blue, alpha);
		bone4.render(poseStack, vertexConsumer, packedLight, packedOverlay, red, green, blue, alpha);
		bone2.render(poseStack, vertexConsumer, packedLight, packedOverlay, red, green, blue, alpha);
		bone3.render(poseStack, vertexConsumer, packedLight, packedOverlay, red, green, blue, alpha);
	}

	public void setupAnim(T entity, float limbSwing, float limbSwingAmount, float ageInTicks, float netHeadYaw,
			float headPitch) {
	}
}