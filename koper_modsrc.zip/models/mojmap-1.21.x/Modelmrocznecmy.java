// Made with Blockbench 4.12.5
// Exported for Minecraft version 1.17 or later with Mojang mappings
// Paste this class into your mod and generate all required imports

public class Modelmrocznecmy<T extends Entity> extends EntityModel<T> {
	// This layer location should be baked with EntityRendererProvider.Context in
	// the entity renderer and passed into this model's constructor
	public static final ModelLayerLocation LAYER_LOCATION = new ModelLayerLocation(
			new ResourceLocation("modid", "mrocznecmy"), "main");
	private final ModelPart bone5;
	private final ModelPart bone2;
	private final ModelPart bone3;
	private final ModelPart bone;
	private final ModelPart bone4;

	public Modelmrocznecmy(ModelPart root) {
		this.bone5 = root.getChild("bone5");
		this.bone2 = root.getChild("bone2");
		this.bone3 = root.getChild("bone3");
		this.bone = root.getChild("bone");
		this.bone4 = root.getChild("bone4");
	}

	public static LayerDefinition createBodyLayer() {
		MeshDefinition meshdefinition = new MeshDefinition();
		PartDefinition partdefinition = meshdefinition.getRoot();

		PartDefinition bone5 = partdefinition.addOrReplaceChild("bone5", CubeListBuilder.create(),
				PartPose.offset(-0.7F, 22.6F, -7.7F));

		PartDefinition cube_r1 = bone5.addOrReplaceChild("cube_r1",
				CubeListBuilder.create().texOffs(22, 20).addBox(0.996F, -0.5F, -9.3482F, 1.0F, 1.0F, 4.0F,
						new CubeDeformation(0.0F)),
				PartPose.offsetAndRotation(0.4F, 0.0F, -8.0F, -3.1416F, -1.5272F, 0.0F));

		PartDefinition cube_r2 = bone5.addOrReplaceChild("cube_r2",
				CubeListBuilder.create().texOffs(12, 20).addBox(4.0377F, -0.5F, -3.6915F, 1.0F, 1.0F, 4.0F,
						new CubeDeformation(0.0F)),
				PartPose.offsetAndRotation(0.4F, 0.0F, -8.0F, 0.0F, -0.9599F, 3.1416F));

		PartDefinition cube_r3 = bone5.addOrReplaceChild("cube_r3",
				CubeListBuilder.create().texOffs(0, 20).addBox(3.6F, -0.5F, 1.9282F, 1.0F, 1.0F, 5.0F,
						new CubeDeformation(0.0F)),
				PartPose.offsetAndRotation(0.4F, 0.0F, -8.0F, 0.0F, -0.5236F, 3.1416F));

		PartDefinition bone2 = partdefinition.addOrReplaceChild("bone2", CubeListBuilder.create(),
				PartPose.offset(0.4F, 22.6F, -7.7F));

		PartDefinition cube_r4 = bone2.addOrReplaceChild("cube_r4",
				CubeListBuilder.create().texOffs(22, 20).addBox(-0.141F, -0.5F, -3.2928F, 1.0F, 1.0F, 4.0F,
						new CubeDeformation(0.0F)),
				PartPose.offsetAndRotation(6.0F, 0.0F, -6.6F, 0.0F, -1.6144F, 0.0F));

		PartDefinition cube_r5 = bone2.addOrReplaceChild("cube_r5",
				CubeListBuilder.create().texOffs(12, 20).addBox(-0.1321F, -0.5F, -4.5359F, 1.0F, 1.0F, 4.0F,
						new CubeDeformation(0.0F)),
				PartPose.offsetAndRotation(1.7F, 0.0F, -4.1F, 0.0F, -0.9599F, 0.0F));

		PartDefinition cube_r6 = bone2
				.addOrReplaceChild("cube_r6",
						CubeListBuilder.create().texOffs(0, 20).addBox(-0.4F, -0.5F, -5.0F, 1.0F, 1.0F, 5.0F,
								new CubeDeformation(0.0F)),
						PartPose.offsetAndRotation(0.0F, 0.0F, 0.0F, 0.0F, -0.5236F, 0.0F));

		PartDefinition bone3 = partdefinition.addOrReplaceChild("bone3", CubeListBuilder.create().texOffs(0, 0).addBox(
				-1.0F, -2.0F, -8.0F, 2.0F, 2.0F, 16.0F, new CubeDeformation(0.0F)), PartPose.offset(0.0F, 24.0F, 0.0F));

		PartDefinition bone = partdefinition.addOrReplaceChild("bone", CubeListBuilder.create(),
				PartPose.offset(-1.0F, 22.0F, 0.0F));

		PartDefinition cube_r7 = bone.addOrReplaceChild("cube_r7",
				CubeListBuilder.create().texOffs(24, 27)
						.addBox(7.0F, 0.0F, 1.0F, 1.0F, 0.0F, 1.0F, new CubeDeformation(0.0F)).texOffs(16, 26)
						.addBox(4.0F, 0.0F, 1.0F, 2.0F, 0.0F, 1.0F, new CubeDeformation(0.0F)).texOffs(22, 26)
						.addBox(5.0F, 0.0F, 2.0F, 2.0F, 0.0F, 1.0F, new CubeDeformation(0.0F)).texOffs(12, 25)
						.addBox(0.0F, 0.0F, 4.0F, 4.0F, 0.0F, 1.0F, new CubeDeformation(0.0F)).texOffs(22, 18)
						.addBox(1.0F, 0.0F, 3.0F, 6.0F, 0.0F, 1.0F, new CubeDeformation(0.0F)).texOffs(0, 27)
						.addBox(2.0F, 0.0F, 2.0F, 2.0F, 0.0F, 1.0F, new CubeDeformation(0.0F)).texOffs(0, 26)
						.addBox(0.0F, 0.0F, 1.0F, 3.0F, 0.0F, 1.0F, new CubeDeformation(0.0F)).texOffs(0, 18)
						.addBox(0.0F, 0.0F, -1.0F, 9.0F, 0.0F, 2.0F, new CubeDeformation(0.0F)),
				PartPose.offsetAndRotation(0.0F, 0.0F, 0.0F, 0.0F, 0.0F, -3.1416F));

		PartDefinition cube_r8 = bone.addOrReplaceChild("cube_r8",
				CubeListBuilder.create().texOffs(0, 28)
						.addBox(7.0F, 0.0F, 1.0F, 1.0F, 0.0F, 1.0F, new CubeDeformation(0.0F)).texOffs(18, 27)
						.addBox(4.0F, 0.0F, 1.0F, 2.0F, 0.0F, 1.0F, new CubeDeformation(0.0F)).texOffs(12, 27)
						.addBox(5.0F, 0.0F, 2.0F, 2.0F, 0.0F, 1.0F, new CubeDeformation(0.0F)).texOffs(22, 25)
						.addBox(0.0F, 0.0F, 4.0F, 4.0F, 0.0F, 1.0F, new CubeDeformation(0.0F)).texOffs(22, 19)
						.addBox(1.0F, 0.0F, 3.0F, 6.0F, 0.0F, 1.0F, new CubeDeformation(0.0F)).texOffs(6, 27)
						.addBox(2.0F, 0.0F, 2.0F, 2.0F, 0.0F, 1.0F, new CubeDeformation(0.0F)).texOffs(8, 26)
						.addBox(0.0F, 0.0F, 1.0F, 3.0F, 0.0F, 1.0F, new CubeDeformation(0.0F)),
				PartPose.offsetAndRotation(0.0F, 0.0F, 0.0F, 3.1416F, 0.0F, -3.1416F));

		PartDefinition bone4 = partdefinition.addOrReplaceChild("bone4",
				CubeListBuilder.create().texOffs(12, 25)
						.addBox(0.0F, 0.0F, 4.0F, 4.0F, 0.0F, 1.0F, new CubeDeformation(0.0F)).texOffs(22, 18)
						.addBox(1.0F, 0.0F, 3.0F, 6.0F, 0.0F, 1.0F, new CubeDeformation(0.0F)).texOffs(0, 27)
						.addBox(2.0F, 0.0F, 2.0F, 2.0F, 0.0F, 1.0F, new CubeDeformation(0.0F)).texOffs(22, 26)
						.addBox(5.0F, 0.0F, 2.0F, 2.0F, 0.0F, 1.0F, new CubeDeformation(0.0F)).texOffs(16, 26)
						.addBox(4.0F, 0.0F, 1.0F, 2.0F, 0.0F, 1.0F, new CubeDeformation(0.0F)).texOffs(0, 26)
						.addBox(0.0F, 0.0F, 1.0F, 3.0F, 0.0F, 1.0F, new CubeDeformation(0.0F)).texOffs(0, 18)
						.addBox(0.0F, 0.0F, -1.0F, 9.0F, 0.0F, 2.0F, new CubeDeformation(0.0F)).texOffs(24, 27)
						.addBox(7.0F, 0.0F, 1.0F, 1.0F, 0.0F, 1.0F, new CubeDeformation(0.0F)),
				PartPose.offset(1.0F, 22.0F, 0.0F));

		PartDefinition cube_r9 = bone4.addOrReplaceChild("cube_r9",
				CubeListBuilder.create().texOffs(12, 27)
						.addBox(4.0F, 2.0F, 2.0F, 2.0F, 0.0F, 1.0F, new CubeDeformation(0.0F)).texOffs(22, 19)
						.addBox(0.0F, 2.0F, 3.0F, 6.0F, 0.0F, 1.0F, new CubeDeformation(0.0F)).texOffs(22, 25)
						.addBox(-1.0F, 2.0F, 4.0F, 4.0F, 0.0F, 1.0F, new CubeDeformation(0.0F)).texOffs(6, 27)
						.addBox(1.0F, 2.0F, 2.0F, 2.0F, 0.0F, 1.0F, new CubeDeformation(0.0F)).texOffs(18, 27)
						.addBox(3.0F, 2.0F, 1.0F, 2.0F, 0.0F, 1.0F, new CubeDeformation(0.0F)).texOffs(0, 28)
						.addBox(6.0F, 2.0F, 1.0F, 1.0F, 0.0F, 1.0F, new CubeDeformation(0.0F)).texOffs(8, 26)
						.addBox(-1.0F, 2.0F, 1.0F, 3.0F, 0.0F, 1.0F, new CubeDeformation(0.0F)),
				PartPose.offsetAndRotation(1.0F, 2.0F, 0.0F, 3.1416F, 0.0F, 0.0F));

		return LayerDefinition.create(meshdefinition, 64, 64);
	}

	@Override
	public void renderToBuffer(PoseStack poseStack, VertexConsumer vertexConsumer, int packedLight, int packedOverlay,
			float red, float green, float blue, float alpha) {
		bone5.render(poseStack, vertexConsumer, packedLight, packedOverlay, red, green, blue, alpha);
		bone2.render(poseStack, vertexConsumer, packedLight, packedOverlay, red, green, blue, alpha);
		bone3.render(poseStack, vertexConsumer, packedLight, packedOverlay, red, green, blue, alpha);
		bone.render(poseStack, vertexConsumer, packedLight, packedOverlay, red, green, blue, alpha);
		bone4.render(poseStack, vertexConsumer, packedLight, packedOverlay, red, green, blue, alpha);
	}

	public void setupAnim(T entity, float limbSwing, float limbSwingAmount, float ageInTicks, float netHeadYaw,
			float headPitch) {
	}
}