// Made with Blockbench 4.12.5
// Exported for Minecraft version 1.17 or later with Mojang mappings
// Paste this class into your mod and generate all required imports

public class Modelkoperkmojmaps2<T extends Entity> extends EntityModel<T> {
	// This layer location should be baked with EntityRendererProvider.Context in
	// the entity renderer and passed into this model's constructor
	public static final ModelLayerLocation LAYER_LOCATION = new ModelLayerLocation(
			new ResourceLocation("modid", "koperkmojmaps2"), "main");
	private final ModelPart hat;
	private final ModelPart head;
	private final ModelPart headcore;
	private final ModelPart chestplatemain;
	private final ModelPart chestplate;
	private final ModelPart chestplatecore;
	private final ModelPart leftarm;
	private final ModelPart rightarm;
	private final ModelPart legging;
	private final ModelPart leftleg;
	private final ModelPart rightleg;
	private final ModelPart boots;
	private final ModelPart leftboot;
	private final ModelPart rightboot;

	public Modelkoperkmojmaps2(ModelPart root) {
		this.hat = root.getChild("hat");
		this.head = this.hat.getChild("head");
		this.headcore = this.head.getChild("headcore");
		this.chestplatemain = root.getChild("chestplatemain");
		this.chestplate = this.chestplatemain.getChild("chestplate");
		this.chestplatecore = this.chestplate.getChild("chestplatecore");
		this.leftarm = this.chestplatemain.getChild("leftarm");
		this.rightarm = this.chestplatemain.getChild("rightarm");
		this.legging = root.getChild("legging");
		this.leftleg = this.legging.getChild("leftleg");
		this.rightleg = this.legging.getChild("rightleg");
		this.boots = root.getChild("boots");
		this.leftboot = this.boots.getChild("leftboot");
		this.rightboot = this.boots.getChild("rightboot");
	}

	public static LayerDefinition createBodyLayer() {
		MeshDefinition meshdefinition = new MeshDefinition();
		PartDefinition partdefinition = meshdefinition.getRoot();

		PartDefinition hat = partdefinition.addOrReplaceChild("hat", CubeListBuilder.create(),
				PartPose.offset(0.0F, 0.0F, 0.0F));

		PartDefinition head = hat.addOrReplaceChild("head",
				CubeListBuilder.create().texOffs(0, 0)
						.addBox(-4.0F, -8.1F, -4.0F, 8.0F, 0.0F, 8.0F, new CubeDeformation(0.0F)).texOffs(16, 44)
						.addBox(-0.4F, -14.1F, -1.6F, 4.0F, 1.0F, 4.0F, new CubeDeformation(0.0F)).texOffs(0, 45)
						.addBox(-3.6F, -14.1F, -1.6F, 4.0F, 1.0F, 4.0F, new CubeDeformation(0.0F)).texOffs(40, 8)
						.addBox(-4.0F, -8.1F, 4.0F, 8.0F, 6.0F, 0.0F, new CubeDeformation(0.0F)).texOffs(48, 6)
						.addBox(-3.0F, -2.1F, 4.0F, 6.0F, 1.0F, 0.0F, new CubeDeformation(0.0F)).texOffs(26, 55)
						.addBox(2.0F, -1.1F, 4.0F, 1.0F, 2.0F, 0.0F, new CubeDeformation(0.0F)).texOffs(30, 55)
						.addBox(-3.0F, -1.1F, 4.0F, 1.0F, 2.0F, 0.0F, new CubeDeformation(0.0F)).texOffs(44, 55)
						.addBox(1.0F, -0.1F, 4.0F, 1.0F, 1.0F, 0.0F, new CubeDeformation(0.0F)).texOffs(46, 55)
						.addBox(-2.0F, -0.1F, 4.0F, 1.0F, 1.0F, 0.0F, new CubeDeformation(0.0F)).texOffs(16, 24)
						.addBox(4.0F, -8.1F, -4.0F, 0.0F, 4.0F, 8.0F, new CubeDeformation(0.0F)).texOffs(48, 0)
						.addBox(4.0F, -4.1F, 0.0F, 0.0F, 2.0F, 4.0F, new CubeDeformation(0.0F)).texOffs(4, 51)
						.addBox(-4.0F, -4.1F, -4.0F, 0.0F, 4.0F, 1.0F, new CubeDeformation(0.0F)).texOffs(40, 18)
						.addBox(-4.0F, -0.1F, -4.0F, 8.0F, 0.0F, 1.0F, new CubeDeformation(0.0F)).texOffs(10, 51)
						.addBox(4.0F, -4.1F, -4.0F, 0.0F, 4.0F, 1.0F, new CubeDeformation(0.0F)).texOffs(32, 21)
						.addBox(-4.0F, -8.1F, -4.0F, 0.0F, 4.0F, 8.0F, new CubeDeformation(0.0F)).texOffs(40, 19)
						.addBox(-4.0F, -8.1F, -4.0F, 8.0F, 2.0F, 0.0F, new CubeDeformation(0.0F)).texOffs(0, 51)
						.addBox(-4.0F, -6.1F, -4.0F, 1.0F, 6.0F, 0.0F, new CubeDeformation(0.0F)).texOffs(48, 7)
						.addBox(-3.0F, -1.1F, -4.0F, 6.0F, 1.0F, 0.0F, new CubeDeformation(0.0F)).texOffs(38, 53)
						.addBox(-3.0F, -3.1F, -4.0F, 1.0F, 1.0F, 0.0F, new CubeDeformation(0.0F)).texOffs(2, 51)
						.addBox(3.0F, -6.1F, -4.0F, 1.0F, 6.0F, 0.0F, new CubeDeformation(0.0F)).texOffs(40, 55)
						.addBox(2.0F, -3.1F, -4.0F, 1.0F, 1.0F, 0.0F, new CubeDeformation(0.0F)).texOffs(52, 48)
						.addBox(-1.0F, -6.1F, -4.0F, 2.0F, 1.0F, 0.0F, new CubeDeformation(0.0F)).texOffs(48, 21)
						.addBox(-4.0F, -4.1F, 0.0F, 0.0F, 2.0F, 4.0F, new CubeDeformation(0.0F)).texOffs(52, 49)
						.addBox(-4.0F, -2.1F, 0.0F, 0.0F, 2.0F, 1.0F, new CubeDeformation(0.0F)).texOffs(50, 52)
						.addBox(4.0F, -2.1F, 0.0F, 0.0F, 2.0F, 1.0F, new CubeDeformation(0.0F)).texOffs(12, 51)
						.addBox(4.0F, -1.9F, -2.0F, 0.0F, 1.0F, 2.0F, new CubeDeformation(0.0F)).texOffs(16, 51)
						.addBox(-4.0F, -1.9F, -2.0F, 0.0F, 1.0F, 2.0F, new CubeDeformation(0.0F)),
				PartPose.offset(0.0F, 0.0F, 0.0F));

		PartDefinition cube_r1 = head.addOrReplaceChild("cube_r1",
				CubeListBuilder.create().texOffs(56, 3)
						.addBox(8.6F, -14.1F, 1.3F, 1.0F, 1.0F, 0.0F, new CubeDeformation(0.0F)).texOffs(56, 2)
						.addBox(10.6F, -14.1F, 1.3F, 1.0F, 1.0F, 0.0F, new CubeDeformation(0.0F)).texOffs(8, 50)
						.addBox(7.6F, -13.1F, 1.3F, 4.0F, 1.0F, 0.0F, new CubeDeformation(0.0F)).texOffs(0, 50)
						.addBox(8.6F, -12.1F, 1.3F, 4.0F, 1.0F, 0.0F, new CubeDeformation(0.0F)).texOffs(24, 52)
						.addBox(9.6F, -11.1F, 1.3F, 3.0F, 1.0F, 0.0F, new CubeDeformation(0.0F)).texOffs(24, 49)
						.addBox(8.6F, -10.1F, 1.3F, 4.0F, 1.0F, 0.0F, new CubeDeformation(0.0F)).texOffs(8, 55)
						.addBox(11.6F, -9.1F, 1.3F, 1.0F, 3.0F, 0.0F, new CubeDeformation(0.0F)).texOffs(6, 55)
						.addBox(8.6F, -7.1F, 1.3F, 1.0F, 3.0F, 0.0F, new CubeDeformation(0.0F)).texOffs(54, 54)
						.addBox(5.6F, -9.1F, 1.3F, 1.0F, 3.0F, 0.0F, new CubeDeformation(0.0F)).texOffs(48, 31)
						.addBox(6.6F, -9.1F, 1.3F, 5.0F, 2.0F, 0.0F, new CubeDeformation(0.0F)).texOffs(20, 52)
						.addBox(3.6F, -8.1F, 1.3F, 2.0F, 3.0F, 0.0F, new CubeDeformation(0.0F)),
				PartPose.offsetAndRotation(0.0F, 0.0F, 0.0F, -3.1416F, -0.5672F, 3.1416F));

		PartDefinition cube_r2 = head.addOrReplaceChild("cube_r2",
				CubeListBuilder.create().texOffs(56, 2)
						.addBox(11.6F, -14.1F, 0.3F, 1.0F, 1.0F, 0.0F, new CubeDeformation(0.0F)).texOffs(56, 3)
						.addBox(9.6F, -14.1F, 0.3F, 1.0F, 1.0F, 0.0F, new CubeDeformation(0.0F)).texOffs(8, 50)
						.addBox(8.6F, -13.1F, 0.3F, 4.0F, 1.0F, 0.0F, new CubeDeformation(0.0F)).texOffs(0, 50)
						.addBox(9.6F, -12.1F, 0.3F, 4.0F, 1.0F, 0.0F, new CubeDeformation(0.0F)).texOffs(24, 52)
						.addBox(10.6F, -11.1F, 0.3F, 3.0F, 1.0F, 0.0F, new CubeDeformation(0.0F)).texOffs(24, 49)
						.addBox(9.6F, -10.1F, 0.3F, 4.0F, 1.0F, 0.0F, new CubeDeformation(0.0F)).texOffs(8, 55)
						.addBox(12.6F, -9.1F, 0.3F, 1.0F, 3.0F, 0.0F, new CubeDeformation(0.0F)).texOffs(6, 55)
						.addBox(9.6F, -7.1F, 0.3F, 1.0F, 3.0F, 0.0F, new CubeDeformation(0.0F)).texOffs(48, 31)
						.addBox(7.6F, -9.1F, 0.3F, 5.0F, 2.0F, 0.0F, new CubeDeformation(0.0F)).texOffs(54, 54)
						.addBox(6.6F, -9.1F, 0.3F, 1.0F, 3.0F, 0.0F, new CubeDeformation(0.0F)).texOffs(20, 52)
						.addBox(4.6F, -8.1F, 0.3F, 2.0F, 3.0F, 0.0F, new CubeDeformation(0.0F)),
				PartPose.offsetAndRotation(0.6F, 0.0F, 1.9F, -3.1416F, 0.2182F, 3.1416F));

		PartDefinition cube_r3 = head.addOrReplaceChild("cube_r3",
				CubeListBuilder.create().texOffs(6, 55)
						.addBox(9.1F, -7.0F, 0.3F, 1.0F, 3.0F, 0.0F, new CubeDeformation(0.0F)).texOffs(8, 55)
						.addBox(12.1F, -9.0F, 0.3F, 1.0F, 3.0F, 0.0F, new CubeDeformation(0.0F)).texOffs(56, 2)
						.addBox(11.1F, -14.0F, 0.3F, 1.0F, 1.0F, 0.0F, new CubeDeformation(0.0F)).texOffs(56, 3)
						.addBox(9.1F, -14.0F, 0.3F, 1.0F, 1.0F, 0.0F, new CubeDeformation(0.0F)).texOffs(8, 50)
						.addBox(8.1F, -13.0F, 0.3F, 4.0F, 1.0F, 0.0F, new CubeDeformation(0.0F)).texOffs(0, 50)
						.addBox(9.1F, -12.0F, 0.3F, 4.0F, 1.0F, 0.0F, new CubeDeformation(0.0F)).texOffs(24, 49)
						.addBox(9.1F, -10.0F, 0.3F, 4.0F, 1.0F, 0.0F, new CubeDeformation(0.0F)).texOffs(24, 52)
						.addBox(10.1F, -11.0F, 0.3F, 3.0F, 1.0F, 0.0F, new CubeDeformation(0.0F)).texOffs(48, 31)
						.addBox(7.1F, -9.0F, 0.3F, 5.0F, 2.0F, 0.0F, new CubeDeformation(0.0F)).texOffs(54, 54)
						.addBox(6.1F, -9.0F, 0.3F, 1.0F, 3.0F, 0.0F, new CubeDeformation(0.0F)).texOffs(20, 52)
						.addBox(4.1F, -8.0F, 0.3F, 2.0F, 3.0F, 0.0F, new CubeDeformation(0.0F)),
				PartPose.offsetAndRotation(0.0F, 0.0F, 0.0F, 0.0F, -0.2182F, 0.0F));

		PartDefinition cube_r4 = head.addOrReplaceChild("cube_r4",
				CubeListBuilder.create().texOffs(20, 52)
						.addBox(2.5F, -8.0F, 2.7F, 2.0F, 3.0F, 0.0F, new CubeDeformation(0.0F)).texOffs(54, 54)
						.addBox(4.5F, -9.0F, 2.7F, 1.0F, 3.0F, 0.0F, new CubeDeformation(0.0F)).texOffs(48, 31)
						.addBox(5.5F, -9.0F, 2.7F, 5.0F, 2.0F, 0.0F, new CubeDeformation(0.0F)).texOffs(6, 55)
						.addBox(7.5F, -7.0F, 2.7F, 1.0F, 3.0F, 0.0F, new CubeDeformation(0.0F)).texOffs(8, 55)
						.addBox(10.5F, -9.0F, 2.7F, 1.0F, 3.0F, 0.0F, new CubeDeformation(0.0F)).texOffs(24, 49)
						.addBox(7.5F, -10.0F, 2.7F, 4.0F, 1.0F, 0.0F, new CubeDeformation(0.0F)).texOffs(24, 52)
						.addBox(8.5F, -11.0F, 2.7F, 3.0F, 1.0F, 0.0F, new CubeDeformation(0.0F)).texOffs(0, 50)
						.addBox(7.5F, -12.0F, 2.7F, 4.0F, 1.0F, 0.0F, new CubeDeformation(0.0F)).texOffs(8, 50)
						.addBox(6.5F, -13.0F, 2.7F, 4.0F, 1.0F, 0.0F, new CubeDeformation(0.0F)).texOffs(56, 2)
						.addBox(9.5F, -14.0F, 2.7F, 1.0F, 1.0F, 0.0F, new CubeDeformation(0.0F)).texOffs(56, 3)
						.addBox(7.5F, -14.0F, 2.7F, 1.0F, 1.0F, 0.0F, new CubeDeformation(0.0F)),
				PartPose.offsetAndRotation(0.0F, 0.0F, 0.0F, 0.0F, 0.5672F, 0.0F));

		PartDefinition cube_r5 = head.addOrReplaceChild("cube_r5",
				CubeListBuilder.create().texOffs(34, 55)
						.addBox(5.6F, -11.5F, 5.7F, 1.0F, 2.0F, 0.0F, new CubeDeformation(0.0F)).texOffs(34, 54)
						.addBox(4.6F, -9.5F, 5.7F, 2.0F, 1.0F, 0.0F, new CubeDeformation(0.0F)).texOffs(48, 52)
						.addBox(4.6F, -8.5F, 5.7F, 1.0F, 3.0F, 0.0F, new CubeDeformation(0.0F)),
				PartPose.offsetAndRotation(0.0F, 0.0F, 0.0F, 0.2533F, 0.067F, -0.2533F));

		PartDefinition cube_r6 = head.addOrReplaceChild("cube_r6",
				CubeListBuilder.create().texOffs(36, 55)
						.addBox(-6.6F, -11.2F, 4.9F, 1.0F, 2.0F, 0.0F, new CubeDeformation(0.0F)).texOffs(18, 55)
						.addBox(-6.6F, -9.2F, 4.9F, 2.0F, 1.0F, 0.0F, new CubeDeformation(0.0F)).texOffs(44, 52)
						.addBox(-5.6F, -8.2F, 4.9F, 1.0F, 3.0F, 0.0F, new CubeDeformation(0.0F)),
				PartPose.offsetAndRotation(0.0F, 0.0F, 0.0F, -2.8883F, 0.067F, 2.8883F));

		PartDefinition cube_r7 = head.addOrReplaceChild("cube_r7",
				CubeListBuilder.create().texOffs(38, 55)
						.addBox(5.6F, -11.2F, 4.9F, 1.0F, 2.0F, 0.0F, new CubeDeformation(0.0F)).texOffs(22, 55)
						.addBox(4.6F, -9.2F, 4.9F, 2.0F, 1.0F, 0.0F, new CubeDeformation(0.0F)).texOffs(52, 45)
						.addBox(4.6F, -8.2F, 4.9F, 1.0F, 3.0F, 0.0F, new CubeDeformation(0.0F)),
				PartPose.offsetAndRotation(0.0F, 0.0F, 0.0F, -2.8883F, -0.067F, -2.8883F));

		PartDefinition cube_r8 = head.addOrReplaceChild("cube_r8",
				CubeListBuilder.create().texOffs(32, 55)
						.addBox(-6.6F, -11.5F, 5.7F, 1.0F, 2.0F, 0.0F, new CubeDeformation(0.0F)).texOffs(38, 54)
						.addBox(-6.6F, -9.5F, 5.7F, 2.0F, 1.0F, 0.0F, new CubeDeformation(0.0F)).texOffs(46, 52)
						.addBox(-5.6F, -8.5F, 5.7F, 1.0F, 3.0F, 0.0F, new CubeDeformation(0.0F)),
				PartPose.offsetAndRotation(0.0F, 0.0F, 0.0F, 0.2533F, -0.067F, 0.2533F));

		PartDefinition headcore = head.addOrReplaceChild("headcore", CubeListBuilder.create().texOffs(48, 35).addBox(
				-1.0F, -11.5F, -1.0F, 2.0F, 2.0F, 2.0F, new CubeDeformation(0.0F)), PartPose.offset(0.0F, 0.0F, 0.0F));

		PartDefinition chestplatemain = partdefinition.addOrReplaceChild("chestplatemain", CubeListBuilder.create(),
				PartPose.offset(0.0F, 0.0F, 0.0F));

		PartDefinition chestplate = chestplatemain.addOrReplaceChild("chestplate", CubeListBuilder.create()
				.texOffs(0, 8).addBox(-4.0F, 0.1F, -2.0F, 8.0F, 12.0F, 4.0F, new CubeDeformation(0.25F)),
				PartPose.offset(0.0F, 0.0F, 0.0F));

		PartDefinition cube_r9 = chestplate.addOrReplaceChild("cube_r9",
				CubeListBuilder.create().texOffs(24, 54)
						.addBox(0.6F, 5.8F, -2.36F, 2.0F, 1.0F, 0.0F, new CubeDeformation(0.0F)).texOffs(6, 54)
						.addBox(0.6F, 2.2F, -2.36F, 2.0F, 1.0F, 0.0F, new CubeDeformation(0.0F)).texOffs(12, 54)
						.addBox(0.8F, 3.4F, -2.36F, 2.0F, 1.0F, 0.0F, new CubeDeformation(0.0F)).texOffs(16, 54)
						.addBox(0.8F, 4.6F, -2.36F, 2.0F, 1.0F, 0.0F, new CubeDeformation(0.0F)),
				PartPose.offsetAndRotation(0.0F, 0.0F, 0.0F, 0.0F, -0.0436F, 0.0F));

		PartDefinition cube_r10 = chestplate.addOrReplaceChild("cube_r10",
				CubeListBuilder.create().texOffs(52, 52)
						.addBox(-2.6F, 2.2F, -2.36F, 2.0F, 1.0F, 0.0F, new CubeDeformation(0.0F)).texOffs(24, 53)
						.addBox(-2.8F, 3.4F, -2.36F, 2.0F, 1.0F, 0.0F, new CubeDeformation(0.0F)).texOffs(34, 53)
						.addBox(-2.8F, 4.6F, -2.36F, 2.0F, 1.0F, 0.0F, new CubeDeformation(0.0F)).texOffs(52, 53)
						.addBox(-2.6F, 5.8F, -2.36F, 2.0F, 1.0F, 0.0F, new CubeDeformation(0.0F)),
				PartPose.offsetAndRotation(0.0F, 0.0F, 0.0F, 0.0F, 0.0436F, 0.0F));

		PartDefinition chestplatecore = chestplate.addOrReplaceChild("chestplatecore", CubeListBuilder.create()
				.texOffs(40, 52).addBox(-1.0F, -1.0F, -0.26F, 2.0F, 2.0F, 0.0F, new CubeDeformation(0.0F)),
				PartPose.offset(0.0F, 4.5F, -2.0F));

		PartDefinition leftarm = chestplatemain.addOrReplaceChild("leftarm", CubeListBuilder.create().texOffs(16, 36)
				.addBox(-3.0F, -2.5F, -2.0F, 4.0F, 4.0F, 4.0F, new CubeDeformation(0.1F)),
				PartPose.offset(-5.0F, 2.0F, 0.0F));

		PartDefinition rightarm = chestplatemain.addOrReplaceChild("rightarm", CubeListBuilder.create().texOffs(0, 37)
				.addBox(-1.0F, -2.5F, -2.0F, 4.0F, 4.0F, 4.0F, new CubeDeformation(0.1F)),
				PartPose.offset(5.0F, 2.0F, 0.0F));

		PartDefinition legging = partdefinition.addOrReplaceChild("legging",
				CubeListBuilder.create().texOffs(32, 41)
						.addBox(-4.0F, -2.8F, 1.1F, 8.0F, 3.0F, 1.0F, new CubeDeformation(0.1F)).texOffs(32, 45)
						.addBox(-4.0F, -2.8F, -2.0F, 1.0F, 3.0F, 4.0F, new CubeDeformation(0.1F)).texOffs(42, 45)
						.addBox(3.0F, -2.8F, -2.0F, 1.0F, 3.0F, 4.0F, new CubeDeformation(0.1F)),
				PartPose.offset(0.0F, 12.0F, 0.0F));

		PartDefinition cube_r11 = legging
				.addOrReplaceChild("cube_r11",
						CubeListBuilder.create().texOffs(32, 41).addBox(-4.0F, -2.8F, 1.1F, 8.0F, 3.0F, 1.0F,
								new CubeDeformation(0.1F)),
						PartPose.offsetAndRotation(0.0F, 0.0F, 0.0F, 0.0F, 3.1416F, 0.0F));

		PartDefinition leftleg = legging.addOrReplaceChild("leftleg", CubeListBuilder.create().texOffs(0, 24).addBox(
				-2.0F, 0.1F, -2.0F, 4.0F, 9.0F, 4.0F, new CubeDeformation(0.1F)), PartPose.offset(-1.9F, 0.0F, 0.0F));

		PartDefinition rightleg = legging.addOrReplaceChild("rightleg", CubeListBuilder.create().texOffs(24, 8).addBox(
				-2.0F, 0.1F, -2.0F, 4.0F, 9.0F, 4.0F, new CubeDeformation(0.1F)), PartPose.offset(1.9F, 0.0F, 0.0F));

		PartDefinition boots = partdefinition.addOrReplaceChild("boots", CubeListBuilder.create(),
				PartPose.offset(0.0F, 12.0F, 0.0F));

		PartDefinition leftboot = boots.addOrReplaceChild("leftboot", CubeListBuilder.create().texOffs(32, 33).addBox(
				-2.2F, 8.0F, -2.0F, 4.0F, 4.0F, 4.0F, new CubeDeformation(0.2F)), PartPose.offset(-1.9F, 0.0F, 0.0F));

		PartDefinition rightboot = boots.addOrReplaceChild("rightboot", CubeListBuilder.create().texOffs(32, 33).addBox(
				-2.0F, 8.0F, -2.0F, 4.0F, 4.0F, 4.0F, new CubeDeformation(0.2F)), PartPose.offset(1.9F, 0.0F, 0.0F));

		return LayerDefinition.create(meshdefinition, 64, 64);
	}

	@Override
	public void renderToBuffer(PoseStack poseStack, VertexConsumer vertexConsumer, int packedLight, int packedOverlay,
			float red, float green, float blue, float alpha) {
		hat.render(poseStack, vertexConsumer, packedLight, packedOverlay, red, green, blue, alpha);
		chestplatemain.render(poseStack, vertexConsumer, packedLight, packedOverlay, red, green, blue, alpha);
		legging.render(poseStack, vertexConsumer, packedLight, packedOverlay, red, green, blue, alpha);
		boots.render(poseStack, vertexConsumer, packedLight, packedOverlay, red, green, blue, alpha);
	}

	public void setupAnim(T entity, float limbSwing, float limbSwingAmount, float ageInTicks, float netHeadYaw,
			float headPitch) {
		this.chestplatecore.yRot = ageInTicks;
		this.headcore.xRot = ageInTicks;
	}
}