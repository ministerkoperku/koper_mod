// Made with Blockbench 4.12.5
// Exported for Minecraft version 1.17 or later with Mojang mappings
// Paste this class into your mod and generate all required imports

public class Modelkoper<T extends Entity> extends EntityModel<T> {
	// This layer location should be baked with EntityRendererProvider.Context in
	// the entity renderer and passed into this model's constructor
	public static final ModelLayerLocation LAYER_LOCATION = new ModelLayerLocation(
			new ResourceLocation("modid", "koper"), "main");
	private final ModelPart legs;
	private final ModelPart bone;
	private final ModelPart bone2;
	private final ModelPart bone25;
	private final ModelPart bone3;
	private final ModelPart bone4;
	private final ModelPart bone5;
	private final ModelPart bone6;
	private final ModelPart bone7;
	private final ModelPart bone8;
	private final ModelPart bone9;
	private final ModelPart bone10;
	private final ModelPart bone11;
	private final ModelPart onon;
	private final ModelPart bone13;
	private final ModelPart bone14;
	private final ModelPart bone15;
	private final ModelPart howa;
	private final ModelPart bone16;
	private final ModelPart bone17;
	private final ModelPart bone18;
	private final ModelPart bone19;
	private final ModelPart bone20;
	private final ModelPart bone21;
	private final ModelPart bone22;
	private final ModelPart bone23;
	private final ModelPart bone24;
	private final ModelPart bone26;
	private final ModelPart bone12;

	public Modelkoper(ModelPart root) {
		this.legs = root.getChild("legs");
		this.bone = this.legs.getChild("bone");
		this.bone2 = this.legs.getChild("bone2");
		this.bone25 = this.legs.getChild("bone25");
		this.bone3 = this.legs.getChild("bone3");
		this.bone4 = this.legs.getChild("bone4");
		this.bone5 = this.legs.getChild("bone5");
		this.bone6 = this.legs.getChild("bone6");
		this.bone7 = this.legs.getChild("bone7");
		this.bone8 = this.legs.getChild("bone8");
		this.bone9 = root.getChild("bone9");
		this.bone10 = root.getChild("bone10");
		this.bone11 = root.getChild("bone11");
		this.onon = root.getChild("onon");
		this.bone13 = this.onon.getChild("bone13");
		this.bone14 = this.onon.getChild("bone14");
		this.bone15 = this.bone14.getChild("bone15");
		this.howa = root.getChild("howa");
		this.bone16 = this.howa.getChild("bone16");
		this.bone17 = this.howa.getChild("bone17");
		this.bone18 = this.howa.getChild("bone18");
		this.bone19 = this.howa.getChild("bone19");
		this.bone20 = this.howa.getChild("bone20");
		this.bone21 = this.howa.getChild("bone21");
		this.bone22 = this.howa.getChild("bone22");
		this.bone23 = this.howa.getChild("bone23");
		this.bone24 = root.getChild("bone24");
		this.bone26 = this.bone24.getChild("bone26");
		this.bone12 = root.getChild("bone12");
	}

	public static LayerDefinition createBodyLayer() {
		MeshDefinition meshdefinition = new MeshDefinition();
		PartDefinition partdefinition = meshdefinition.getRoot();

		PartDefinition legs = partdefinition.addOrReplaceChild("legs", CubeListBuilder.create(),
				PartPose.offset(-7.0F, 24.0F, -21.0F));

		PartDefinition bone = legs.addOrReplaceChild("bone", CubeListBuilder.create(),
				PartPose.offset(13.0F, -41.0F, 37.0F));

		PartDefinition cube_r1 = bone.addOrReplaceChild("cube_r1",
				CubeListBuilder.create().texOffs(56, 144).addBox(-11.0F, -18.0F, -0.3F, 5.0F, 18.0F, 5.0F,
						new CubeDeformation(0.0F)),
				PartPose.offsetAndRotation(-9.0F, 9.1F, 6.4F, 2.6616F, 0.0F, 3.1416F));

		PartDefinition cube_r2 = bone.addOrReplaceChild("cube_r2",
				CubeListBuilder.create().texOffs(20, 145).addBox(-11.0F, -18.0F, -17.3F, 5.0F, 18.0F, 5.0F,
						new CubeDeformation(0.0F)),
				PartPose.offsetAndRotation(-9.0F, 26.5F, -10.7F, -3.1416F, 0.0F, 3.1416F));

		PartDefinition bone2 = legs.addOrReplaceChild("bone2", CubeListBuilder.create(),
				PartPose.offset(3.0F, -40.0F, 36.0F));

		PartDefinition cube_r3 = bone2.addOrReplaceChild("cube_r3",
				CubeListBuilder.create().texOffs(136, 148).addBox(0.0F, -18.0F, -17.3F, 5.0F, 18.0F, 5.0F,
						new CubeDeformation(0.0F)),
				PartPose.offsetAndRotation(1.0F, 25.5F, -9.7F, -3.1416F, 0.0F, 3.1416F));

		PartDefinition cube_r4 = bone2.addOrReplaceChild("cube_r4",
				CubeListBuilder.create().texOffs(136, 125).addBox(0.0F, -18.0F, -0.3F, 5.0F, 18.0F, 5.0F,
						new CubeDeformation(0.0F)),
				PartPose.offsetAndRotation(1.0F, 8.1F, 7.4F, 2.6616F, 0.0F, 3.1416F));

		PartDefinition bone25 = legs.addOrReplaceChild("bone25", CubeListBuilder.create(),
				PartPose.offset(4.0F, -42.5F, 12.3F));

		PartDefinition cube_r5 = bone25.addOrReplaceChild("cube_r5",
				CubeListBuilder.create().texOffs(116, 125).addBox(0.0F, -25.5893F, 21.4703F, 5.0F, 37.0F, 5.0F,
						new CubeDeformation(0.0F)),
				PartPose.offsetAndRotation(0.0F, 28.0F, 14.0F, -2.7053F, 0.0F, 3.1416F));

		PartDefinition bone3 = legs.addOrReplaceChild("bone3", CubeListBuilder.create(),
				PartPose.offset(0.0F, 0.0F, 0.0F));

		PartDefinition bone4 = legs.addOrReplaceChild("bone4", CubeListBuilder.create(),
				PartPose.offset(12.0F, -41.0F, 13.0F));

		PartDefinition cube_r6 = bone4.addOrReplaceChild("cube_r6",
				CubeListBuilder.create().texOffs(0, 127).addBox(-11.0F, -24.5893F, 21.4703F, 5.0F, 36.0F, 5.0F,
						new CubeDeformation(0.0F)),
				PartPose.offsetAndRotation(-8.0F, 26.5F, 13.3F, -2.7053F, 0.0F, 3.1416F));

		PartDefinition bone5 = legs.addOrReplaceChild("bone5", CubeListBuilder.create(),
				PartPose.offset(12.0F, -16.5F, 40.3F));

		PartDefinition cube_r7 = bone5.addOrReplaceChild("cube_r7",
				CubeListBuilder.create().texOffs(96, 149).addBox(-11.0F, -3.5F, -17.3F, 5.0F, 18.0F, 5.0F,
						new CubeDeformation(0.0F)),
				PartPose.offsetAndRotation(-8.0F, 2.0F, -14.0F, -3.1416F, 0.0F, 3.1416F));

		PartDefinition bone6 = legs.addOrReplaceChild("bone6", CubeListBuilder.create(),
				PartPose.offset(1.0F, -16.5F, 41.3F));

		PartDefinition cube_r8 = bone6.addOrReplaceChild("cube_r8",
				CubeListBuilder.create().texOffs(76, 149).addBox(0.0F, -3.5F, -17.3F, 5.0F, 18.0F, 5.0F,
						new CubeDeformation(0.0F)),
				PartPose.offsetAndRotation(3.0F, 2.0F, -15.0F, -3.1416F, 0.0F, 3.1416F));

		PartDefinition bone7 = legs.addOrReplaceChild("bone7", CubeListBuilder.create(),
				PartPose.offset(2.0F, -14.5F, 0.3F));

		PartDefinition cube_r9 = bone7.addOrReplaceChild("cube_r9",
				CubeListBuilder.create().texOffs(156, 160).addBox(0.0F, -1.5F, 23.7F, 5.0F, 16.0F, 5.0F,
						new CubeDeformation(0.0F)),
				PartPose.offsetAndRotation(2.0F, 0.0F, 26.0F, -3.1416F, 0.0F, 3.1416F));

		PartDefinition bone8 = legs.addOrReplaceChild("bone8", CubeListBuilder.create(),
				PartPose.offset(13.0F, -14.5F, -1.7F));

		PartDefinition cube_r10 = bone8.addOrReplaceChild("cube_r10",
				CubeListBuilder.create().texOffs(156, 139).addBox(-11.0F, -1.5F, 23.7F, 5.0F, 16.0F, 5.0F,
						new CubeDeformation(0.0F)),
				PartPose.offsetAndRotation(-9.0F, 0.0F, 28.0F, -3.1416F, 0.0F, 3.1416F));

		PartDefinition bone9 = partdefinition.addOrReplaceChild("bone9", CubeListBuilder.create(),
				PartPose.offset(0.0F, -9.0F, 0.0F));

		PartDefinition bone10 = partdefinition.addOrReplaceChild("bone10", CubeListBuilder.create(),
				PartPose.offset(-11.5F, -19.4F, 4.0F));

		PartDefinition bone11 = partdefinition.addOrReplaceChild("bone11", CubeListBuilder.create(),
				PartPose.offset(-15.3F, -23.3F, 4.0F));

		PartDefinition onon = partdefinition.addOrReplaceChild("onon", CubeListBuilder.create(),
				PartPose.offset(0.0F, -14.0F, 24.0F));

		PartDefinition bone13 = onon.addOrReplaceChild("bone13", CubeListBuilder.create(),
				PartPose.offset(0.0F, 0.0F, 0.0F));

		PartDefinition cube_r11 = bone13
				.addOrReplaceChild("cube_r11",
						CubeListBuilder.create().texOffs(90, 34).addBox(-1.0F, -1.0F, -7.0F, 2.0F, 2.0F, 18.0F,
								new CubeDeformation(0.0F)),
						PartPose.offsetAndRotation(0.0F, 0.0F, 0.0F, -0.4363F, 0.0F, 0.0F));

		PartDefinition bone14 = onon.addOrReplaceChild("bone14", CubeListBuilder.create(),
				PartPose.offset(2.0F, 6.2F, 18.0F));

		PartDefinition cube_r12 = bone14.addOrReplaceChild("cube_r12",
				CubeListBuilder.create().texOffs(136, 72).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 2.0F, 13.0F,
						new CubeDeformation(0.0F)),
				PartPose.offsetAndRotation(-2.0147F, -1.1F, -7.7899F, -0.829F, 0.0F, 0.0F));

		PartDefinition bone15 = bone14.addOrReplaceChild("bone15", CubeListBuilder.create(),
				PartPose.offset(-2.0147F, 0.3F, 1.7101F));

		PartDefinition cube_r13 = bone15.addOrReplaceChild("cube_r13",
				CubeListBuilder.create().texOffs(136, 56).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 2.0F, 14.0F,
						new CubeDeformation(0.0F)),
				PartPose.offsetAndRotation(0.0F, 7.9F, -1.4F, -1.2654F, 0.0F, 0.0F));

		PartDefinition howa = partdefinition.addOrReplaceChild("howa", CubeListBuilder.create(),
				PartPose.offset(0.0F, 0.2F, 42.1F));

		PartDefinition bone16 = howa.addOrReplaceChild("bone16", CubeListBuilder.create(),
				PartPose.offset(0.0F, -18.3F, -62.4F));

		PartDefinition cube_r14 = bone16
				.addOrReplaceChild("cube_r14",
						CubeListBuilder.create().texOffs(88, 176).addBox(-2.0F, -5.3346F, -1.297F, 4.0F, 5.0F, 2.0F,
								new CubeDeformation(0.0F)),
						PartPose.offsetAndRotation(0.0F, 0.0F, 0.0F, 1.8326F, 0.0F, 0.0F));

		PartDefinition bone17 = howa.addOrReplaceChild("bone17", CubeListBuilder.create(),
				PartPose.offset(0.0F, -19.3F, -55.4F));

		PartDefinition cube_r15 = bone17
				.addOrReplaceChild("cube_r15",
						CubeListBuilder.create().texOffs(40, 145).addBox(-2.0F, -8.3346F, -2.297F, 4.0F, 7.0F, 4.0F,
								new CubeDeformation(0.0F)),
						PartPose.offsetAndRotation(0.0F, 0.0F, 0.0F, 1.5708F, 0.0F, 0.0F));

		PartDefinition bone18 = howa.addOrReplaceChild("bone18", CubeListBuilder.create(),
				PartPose.offset(0.0F, -20.3F, -63.4F));

		PartDefinition cube_r16 = bone18.addOrReplaceChild("cube_r16",
				CubeListBuilder.create().texOffs(76, 176).addBox(-2.0F, -12.3346F, -0.297F, 4.0F, 5.0F, 2.0F,
						new CubeDeformation(0.0F)),
				PartPose.offsetAndRotation(0.0F, 0.299F, 8.0567F, 1.5708F, 0.0F, 0.0F));

		PartDefinition bone19 = howa.addOrReplaceChild("bone19", CubeListBuilder.create(),
				PartPose.offset(-0.4F, -18.6F, -65.4F));

		PartDefinition cube_r17 = bone19
				.addOrReplaceChild("cube_r17",
						CubeListBuilder.create().texOffs(134, 175).addBox(2.0F, -2.3346F, 1.703F, 3.0F, 1.0F, 4.0F,
								new CubeDeformation(0.0F)),
						PartPose.offsetAndRotation(0.0F, 0.0F, 0.0F, 1.5708F, 0.0F, 0.0F));

		PartDefinition bone20 = howa.addOrReplaceChild("bone20", CubeListBuilder.create(),
				PartPose.offset(0.4F, -18.6F, -65.4F));

		PartDefinition cube_r18 = bone20
				.addOrReplaceChild("cube_r18",
						CubeListBuilder.create().texOffs(76, 144).addBox(-5.0F, -2.3346F, 1.703F, 3.0F, 1.0F, 4.0F,
								new CubeDeformation(0.0F)),
						PartPose.offsetAndRotation(0.0F, 0.0F, 0.0F, 1.5708F, 0.0F, 0.0F));

		PartDefinition bone21 = howa.addOrReplaceChild("bone21", CubeListBuilder.create(),
				PartPose.offset(-2.5F, -23.6F, -65.4F));

		PartDefinition cube_r19 = bone21.addOrReplaceChild("cube_r19",
				CubeListBuilder.create().texOffs(20, 127).addBox(-4.0F, -0.5803F, -12.2836F, 1.0F, 1.0F, 17.0F,
						new CubeDeformation(0.0F)),
				PartPose.offsetAndRotation(3.0F, 0.0F, 10.0F, -0.0436F, 0.0F, 0.0F));

		PartDefinition bone22 = howa.addOrReplaceChild("bone22", CubeListBuilder.create(),
				PartPose.offset(3.5F, -23.6F, -67.4F));

		PartDefinition cube_r20 = bone22.addOrReplaceChild("cube_r20",
				CubeListBuilder.create().texOffs(56, 127).addBox(2.0F, -0.5803F, -12.2836F, 1.0F, 1.0F, 16.0F,
						new CubeDeformation(0.0F)),
				PartPose.offsetAndRotation(-3.0F, 0.0F, 12.0F, -0.0436F, 0.0F, 0.0F));

		PartDefinition bone23 = howa.addOrReplaceChild("bone23", CubeListBuilder.create(),
				PartPose.offset(0.0F, -10.2F, -49.1F));

		PartDefinition cube_r21 = bone23
				.addOrReplaceChild("cube_r21",
						CubeListBuilder.create().texOffs(156, 34).addBox(-3.0F, -13.0F, -3.0F, 6.0F, 13.0F, 6.0F,
								new CubeDeformation(0.0F)),
						PartPose.offsetAndRotation(0.0F, 0.0F, 0.0F, 0.829F, 0.0F, 0.0F));

		PartDefinition bone24 = partdefinition.addOrReplaceChild("bone24", CubeListBuilder.create(),
				PartPose.offset(0.0F, -23.0F, -11.0F));

		PartDefinition cube_r22 = bone24.addOrReplaceChild("cube_r22",
				CubeListBuilder.create().texOffs(152, 171)
						.addBox(1.0F, -12.0F, 4.0F, 1.0F, 3.0F, 1.0F, new CubeDeformation(0.0F)).texOffs(36, 168)
						.addBox(-4.0F, -12.0F, 4.0F, 1.0F, 3.0F, 1.0F, new CubeDeformation(0.0F)).texOffs(52, 160)
						.addBox(-4.0F, -12.0F, 6.0F, 1.0F, 3.0F, 1.0F, new CubeDeformation(0.0F)).texOffs(52, 156)
						.addBox(1.0F, -12.0F, 6.0F, 1.0F, 3.0F, 1.0F, new CubeDeformation(0.0F)).texOffs(112, 172)
						.addBox(-4.0F, -11.0F, 7.0F, 1.0F, 1.0F, 1.0F, new CubeDeformation(0.0F)).texOffs(36, 174)
						.addBox(-4.0F, -11.0F, 5.0F, 1.0F, 1.0F, 1.0F, new CubeDeformation(0.0F)).texOffs(112, 174)
						.addBox(-4.0F, -11.0F, 3.0F, 1.0F, 1.0F, 1.0F, new CubeDeformation(0.0F)).texOffs(36, 172)
						.addBox(1.0F, -11.0F, 7.0F, 1.0F, 1.0F, 1.0F, new CubeDeformation(0.0F)).texOffs(52, 164)
						.addBox(1.0F, -11.0F, 5.0F, 1.0F, 1.0F, 1.0F, new CubeDeformation(0.0F)).texOffs(126, 54)
						.addBox(1.0F, -11.0F, 3.0F, 1.0F, 1.0F, 1.0F, new CubeDeformation(0.0F)).texOffs(18, 168)
						.addBox(-1.5F, -13.0F, 3.0F, 1.0F, 1.0F, 8.0F, new CubeDeformation(0.0F)).texOffs(0, 183)
						.addBox(-3.5F, -13.0F, 4.0F, 2.0F, 1.0F, 1.0F, new CubeDeformation(0.0F)).texOffs(6, 183)
						.addBox(-0.5F, -13.0F, 4.0F, 2.0F, 1.0F, 1.0F, new CubeDeformation(0.0F)).texOffs(142, 182)
						.addBox(-3.5F, -13.0F, 6.0F, 2.0F, 1.0F, 1.0F, new CubeDeformation(0.0F)).texOffs(70, 182)
						.addBox(-0.5F, -13.0F, 6.0F, 2.0F, 1.0F, 1.0F, new CubeDeformation(0.0F)).texOffs(118, 182)
						.addBox(-0.5F, -13.0F, 8.0F, 2.0F, 1.0F, 2.0F, new CubeDeformation(0.0F)).texOffs(110, 182)
						.addBox(-3.5F, -13.0F, 8.0F, 2.0F, 1.0F, 2.0F, new CubeDeformation(0.0F)).texOffs(116, 167)
						.addBox(-4.0F, -13.0F, 3.0F, 1.0F, 1.0F, 8.0F, new CubeDeformation(0.0F)),
				PartPose.offsetAndRotation(1.0F, 13.0F, 4.0F, 0.829F, 0.0F, 0.0F));

		PartDefinition cube_r23 = bone24.addOrReplaceChild("cube_r23",
				CubeListBuilder.create().texOffs(168, 62).addBox(1.0F, -1.6054F, -0.2578F, 1.0F, 1.0F, 8.0F,
						new CubeDeformation(0.0F)),
				PartPose.offsetAndRotation(1.0F, 2.9F, -2.2F, 0.8295F, 0.0295F, 0.0322F));

		PartDefinition cube_r24 = bone24.addOrReplaceChild("cube_r24",
				CubeListBuilder.create().texOffs(0, 168).addBox(1.0F, -1.6054F, -0.2578F, 1.0F, 1.0F, 8.0F,
						new CubeDeformation(0.0F)),
				PartPose.offsetAndRotation(1.0F, 2.9F, -2.2F, 0.8599F, 0.2332F, 0.2622F));

		PartDefinition cube_r25 = bone24.addOrReplaceChild("cube_r25",
				CubeListBuilder.create().texOffs(126, 182)
						.addBox(-4.0F, -13.0F, 10.0F, 3.0F, 1.0F, 1.0F, new CubeDeformation(0.0F)).texOffs(134, 182)
						.addBox(0.0F, -13.0F, 10.0F, 3.0F, 1.0F, 1.0F, new CubeDeformation(0.0F)),
				PartPose.offsetAndRotation(0.5F, 15.8F, -4.4F, 0.5672F, 0.0F, 0.0F));

		PartDefinition cube_r26 = bone24.addOrReplaceChild("cube_r26",
				CubeListBuilder.create().texOffs(168, 53).addBox(-0.5F, -0.7454F, -0.0123F, 1.0F, 1.0F, 8.0F,
						new CubeDeformation(0.0F)),
				PartPose.offsetAndRotation(-2.5F, 2.5F, -3.0F, 0.8883F, -0.3172F, -0.3665F));

		PartDefinition bone26 = bone24.addOrReplaceChild("bone26", CubeListBuilder.create(),
				PartPose.offset(0.5F, 15.8F, -4.4F));

		PartDefinition cube_r27 = bone26
				.addOrReplaceChild("cube_r27",
						CubeListBuilder.create().texOffs(156, 125).addBox(-1.0F, -13.0F, 3.0F, 1.0F, 1.0F, 13.0F,
								new CubeDeformation(0.0F)),
						PartPose.offsetAndRotation(0.0F, 0.0F, 0.0F, 0.5672F, 0.0F, 0.0F));

		PartDefinition bone12 = partdefinition.addOrReplaceChild("bone12",
				CubeListBuilder.create().texOffs(0, 62)
						.addBox(-4.0F, 7.5F, -15.3F, 8.0F, 2.0F, 27.0F, new CubeDeformation(0.0F)).texOffs(162, 0)
						.addBox(-3.0F, 7.5F, 11.7F, 6.0F, 2.0F, 8.0F, new CubeDeformation(0.0F)).texOffs(0, 0)
						.addBox(-12.5F, -3.5F, -15.3F, 25.0F, 3.0F, 27.0F, new CubeDeformation(0.0F)).texOffs(70, 62)
						.addBox(-2.5F, -11.9F, -15.3F, 5.0F, 1.0F, 28.0F, new CubeDeformation(0.0F)).texOffs(176, 165)
						.addBox(-3.0F, -11.5F, 11.7F, 6.0F, 1.0F, 1.0F, new CubeDeformation(0.0F)).texOffs(90, 127)
						.addBox(-6.0F, -10.7F, 11.7F, 12.0F, 21.0F, 1.0F, new CubeDeformation(0.0F)).texOffs(174, 108)
						.addBox(5.5F, -3.5F, 11.7F, 7.0F, 3.0F, 1.0F, new CubeDeformation(0.0F)).texOffs(176, 167)
						.addBox(5.5F, -4.5F, 11.7F, 6.0F, 1.0F, 1.0F, new CubeDeformation(0.0F)).texOffs(154, 87)
						.addBox(5.5F, -5.5F, 11.7F, 5.0F, 1.0F, 1.0F, new CubeDeformation(0.0F)).texOffs(124, 176)
						.addBox(5.9F, -6.5F, 11.7F, 4.0F, 1.0F, 1.0F, new CubeDeformation(0.0F)).texOffs(0, 179)
						.addBox(-3.0F, -11.2F, -15.3F, 6.0F, 1.0F, 1.0F, new CubeDeformation(0.0F)).texOffs(174, 116)
						.addBox(-12.5F, -3.5F, -15.3F, 7.0F, 3.0F, 1.0F, new CubeDeformation(0.0F)).texOffs(124, 178)
						.addBox(5.3F, -7.5F, 11.7F, 4.0F, 1.0F, 1.0F, new CubeDeformation(0.0F)).texOffs(178, 181)
						.addBox(4.9F, -8.5F, 11.7F, 4.0F, 1.0F, 1.0F, new CubeDeformation(0.0F)).texOffs(182, 10)
						.addBox(4.1F, -9.5F, 11.7F, 4.0F, 1.0F, 1.0F, new CubeDeformation(0.0F)).texOffs(182, 12)
						.addBox(4.0F, -10.1F, 11.7F, 4.0F, 1.0F, 1.0F, new CubeDeformation(0.0F)).texOffs(174, 112)
						.addBox(-12.5F, -3.5F, 11.7F, 7.0F, 3.0F, 1.0F, new CubeDeformation(0.0F)).texOffs(174, 120)
						.addBox(5.5F, -3.5F, -15.3F, 7.0F, 3.0F, 1.0F, new CubeDeformation(0.0F)).texOffs(176, 177)
						.addBox(5.5F, -4.5F, -15.3F, 6.0F, 1.0F, 1.0F, new CubeDeformation(0.0F)).texOffs(28, 177)
						.addBox(5.5F, -5.5F, -15.3F, 5.0F, 1.0F, 1.0F, new CubeDeformation(0.0F)).texOffs(30, 181)
						.addBox(5.9F, -6.5F, -15.3F, 4.0F, 1.0F, 1.0F, new CubeDeformation(0.0F)).texOffs(152, 181)
						.addBox(5.3F, -7.5F, -15.3F, 4.0F, 1.0F, 1.0F, new CubeDeformation(0.0F)).texOffs(182, 26)
						.addBox(4.9F, -8.5F, -15.3F, 4.0F, 1.0F, 1.0F, new CubeDeformation(0.0F)).texOffs(60, 182)
						.addBox(4.1F, -9.5F, -15.3F, 4.0F, 1.0F, 1.0F, new CubeDeformation(0.0F)).texOffs(100, 182)
						.addBox(4.0F, -10.1F, -15.3F, 4.0F, 1.0F, 1.0F, new CubeDeformation(0.0F)).texOffs(162, 10)
						.addBox(1.0F, -2.5F, 11.7F, 2.0F, 10.0F, 8.0F, new CubeDeformation(0.0F)).texOffs(166, 72)
						.addBox(-3.0F, -2.5F, 11.7F, 2.0F, 10.0F, 8.0F, new CubeDeformation(0.0F)).texOffs(40, 167)
						.addBox(-1.0F, -2.5F, 11.7F, 2.0F, 10.0F, 8.0F, new CubeDeformation(0.0F)).texOffs(130, 34)
						.addBox(-6.0F, -10.7F, -15.3F, 12.0F, 21.0F, 1.0F, new CubeDeformation(0.0F)).texOffs(0, 30)
						.addBox(-9.0F, -0.5F, -15.3F, 18.0F, 5.0F, 27.0F, new CubeDeformation(0.0F)),
				PartPose.offset(0.0F, -16.5F, 5.3F));

		PartDefinition cube_r28 = bone12.addOrReplaceChild("cube_r28",
				CubeListBuilder.create().texOffs(182, 20)
						.addBox(-3.9F, -3.6F, 0.0F, 4.0F, 1.0F, 1.0F, new CubeDeformation(0.0F)).texOffs(182, 24)
						.addBox(-3.1F, -2.6F, 0.0F, 4.0F, 1.0F, 1.0F, new CubeDeformation(0.0F)).texOffs(14, 177)
						.addBox(-2.5F, 1.4F, 0.0F, 6.0F, 1.0F, 1.0F, new CubeDeformation(0.0F)).texOffs(156, 53)
						.addBox(-2.5F, 0.4F, 0.0F, 5.0F, 1.0F, 1.0F, new CubeDeformation(0.0F)).texOffs(20, 181)
						.addBox(-2.1F, -0.6F, 0.0F, 4.0F, 1.0F, 1.0F, new CubeDeformation(0.0F)).texOffs(10, 181)
						.addBox(-2.7F, -1.6F, 0.0F, 4.0F, 1.0F, 1.0F, new CubeDeformation(0.0F)).texOffs(182, 22)
						.addBox(-4.0F, -4.2F, 0.0F, 4.0F, 1.0F, 1.0F, new CubeDeformation(0.0F)),
				PartPose.offsetAndRotation(-8.0F, -5.9F, -14.3F, 0.0F, 3.1416F, 0.0F));

		PartDefinition cube_r29 = bone12.addOrReplaceChild("cube_r29",
				CubeListBuilder.create().texOffs(138, 180)
						.addBox(-6.6723F, -0.6936F, 12.5F, 6.0F, 1.0F, 1.0F, new CubeDeformation(0.0F)).texOffs(60, 180)
						.addBox(-6.6723F, -0.6936F, 39.5F, 6.0F, 1.0F, 1.0F, new CubeDeformation(0.0F)),
				PartPose.offsetAndRotation(-9.9F, 4.1F, -27.8F, 0.0F, 0.0F, 3.0107F));

		PartDefinition cube_r30 = bone12.addOrReplaceChild("cube_r30",
				CubeListBuilder.create().texOffs(124, 180)
						.addBox(-6.6723F, -0.6936F, 12.5F, 6.0F, 1.0F, 1.0F, new CubeDeformation(0.0F)).texOffs(14, 179)
						.addBox(-6.6723F, -0.6936F, 39.5F, 6.0F, 1.0F, 1.0F, new CubeDeformation(0.0F)),
				PartPose.offsetAndRotation(-9.9F, 5.1F, -27.8F, 0.0F, 0.0F, 1.9635F));

		PartDefinition cube_r31 = bone12.addOrReplaceChild("cube_r31", CubeListBuilder.create().texOffs(180, 46)
				.addBox(-6.6723F, -0.6936F, -11.5F, 6.0F, 1.0F, 1.0F, new CubeDeformation(0.0F)).texOffs(180, 48)
				.addBox(-6.6723F, -0.6936F, -13.5F, 6.0F, 1.0F, 1.0F, new CubeDeformation(0.0F)).texOffs(180, 44)
				.addBox(-6.6723F, -0.6936F, -9.5F, 6.0F, 1.0F, 1.0F, new CubeDeformation(0.0F)).texOffs(180, 42)
				.addBox(-6.6723F, -0.6936F, -7.5F, 6.0F, 1.0F, 1.0F, new CubeDeformation(0.0F)).texOffs(180, 40)
				.addBox(-6.6723F, -0.6936F, -5.5F, 6.0F, 1.0F, 1.0F, new CubeDeformation(0.0F)).texOffs(180, 38)
				.addBox(-6.6723F, -0.6936F, -3.5F, 6.0F, 1.0F, 1.0F, new CubeDeformation(0.0F)).texOffs(180, 36)
				.addBox(-6.6723F, -0.6936F, -1.5F, 6.0F, 1.0F, 1.0F, new CubeDeformation(0.0F)).texOffs(180, 34)
				.addBox(-6.6723F, -0.6936F, 0.5F, 6.0F, 1.0F, 1.0F, new CubeDeformation(0.0F)).texOffs(180, 32)
				.addBox(-6.6723F, -0.6936F, 2.5F, 6.0F, 1.0F, 1.0F, new CubeDeformation(0.0F)).texOffs(176, 163)
				.addBox(-6.6723F, -0.6936F, 4.5F, 6.0F, 1.0F, 1.0F, new CubeDeformation(0.0F)).texOffs(180, 30)
				.addBox(-6.6723F, -0.6936F, 6.5F, 6.0F, 1.0F, 1.0F, new CubeDeformation(0.0F)).texOffs(180, 28)
				.addBox(-6.6723F, -0.6936F, 8.5F, 6.0F, 1.0F, 1.0F, new CubeDeformation(0.0F)).texOffs(176, 179)
				.addBox(-6.6723F, -0.6936F, 10.5F, 6.0F, 1.0F, 1.0F, new CubeDeformation(0.0F)),
				PartPose.offsetAndRotation(-9.9F, 5.1F, -1.8F, 0.0F, 0.0F, 1.2654F));

		PartDefinition cube_r32 = bone12.addOrReplaceChild("cube_r32",
				CubeListBuilder.create().texOffs(90, 54)
						.addBox(-7.0F, 0.0F, -0.5F, 8.0F, 1.0F, 1.0F, new CubeDeformation(0.0F)).texOffs(134, 171)
						.addBox(-7.0F, 0.0F, 15.5F, 8.0F, 1.0F, 1.0F, new CubeDeformation(0.0F)).texOffs(162, 32)
						.addBox(-7.0F, 0.0F, 17.5F, 8.0F, 1.0F, 1.0F, new CubeDeformation(0.0F)).texOffs(162, 30)
						.addBox(-7.0F, 0.0F, 19.5F, 8.0F, 1.0F, 1.0F, new CubeDeformation(0.0F)).texOffs(162, 28)
						.addBox(-7.0F, 0.0F, 21.5F, 8.0F, 1.0F, 1.0F, new CubeDeformation(0.0F)).texOffs(136, 89)
						.addBox(-7.0F, 0.0F, 23.5F, 8.0F, 1.0F, 1.0F, new CubeDeformation(0.0F)).texOffs(136, 87)
						.addBox(-7.0F, 0.0F, 25.5F, 8.0F, 1.0F, 1.0F, new CubeDeformation(0.0F)).texOffs(108, 60)
						.addBox(-7.0F, 0.0F, 7.5F, 8.0F, 1.0F, 1.0F, new CubeDeformation(0.0F)).texOffs(108, 58)
						.addBox(-7.0F, 0.0F, 9.5F, 8.0F, 1.0F, 1.0F, new CubeDeformation(0.0F)).texOffs(108, 56)
						.addBox(-7.0F, 0.0F, 11.5F, 8.0F, 1.0F, 1.0F, new CubeDeformation(0.0F)).texOffs(108, 54)
						.addBox(-7.0F, 0.0F, 13.5F, 8.0F, 1.0F, 1.0F, new CubeDeformation(0.0F)).texOffs(90, 60)
						.addBox(-7.0F, 0.0F, 3.5F, 8.0F, 1.0F, 1.0F, new CubeDeformation(0.0F)).texOffs(90, 58)
						.addBox(-7.0F, 0.0F, 5.5F, 8.0F, 1.0F, 1.0F, new CubeDeformation(0.0F)).texOffs(90, 56)
						.addBox(-7.0F, 0.0F, 1.5F, 8.0F, 1.0F, 1.0F, new CubeDeformation(0.0F)),
				PartPose.offsetAndRotation(-4.0F, 7.5F, -14.8F, 0.0F, 0.0F, 0.5672F));

		PartDefinition cube_r33 = bone12.addOrReplaceChild("cube_r33",
				CubeListBuilder.create().texOffs(112, 176)
						.addBox(3.0F, -6.0F, -5.0F, 2.0F, 2.0F, 4.0F, new CubeDeformation(0.0F)).texOffs(100, 176)
						.addBox(-1.0F, -6.0F, -5.0F, 2.0F, 2.0F, 4.0F, new CubeDeformation(0.0F)).texOffs(170, 181)
						.addBox(1.0F, -10.0F, -1.0F, 2.0F, 2.0F, 2.0F, new CubeDeformation(0.0F)).texOffs(162, 181)
						.addBox(1.0F, -6.0F, -1.0F, 2.0F, 2.0F, 2.0F, new CubeDeformation(0.0F)).texOffs(148, 175)
						.addBox(1.0F, -3.0F, -1.0F, 2.0F, 2.0F, 2.0F, new CubeDeformation(0.0F)).texOffs(68, 167)
						.addBox(-1.0F, -11.0F, -1.0F, 2.0F, 11.0F, 2.0F, new CubeDeformation(0.0F)).texOffs(60, 167)
						.addBox(3.0F, -11.0F, -1.0F, 2.0F, 11.0F, 2.0F, new CubeDeformation(0.0F)),
				PartPose.offsetAndRotation(-2.0F, -1.7F, 18.9F, 0.6981F, 0.0F, 0.0F));

		PartDefinition cube_r34 = bone12.addOrReplaceChild("cube_r34",
				CubeListBuilder.create().texOffs(126, 56)
						.addBox(-1.0F, -2.0F, 2.0F, 2.0F, 4.0F, 2.0F, new CubeDeformation(0.0F)).texOffs(40, 156)
						.addBox(-1.0F, -3.0F, -2.0F, 2.0F, 6.0F, 4.0F, new CubeDeformation(0.0F)),
				PartPose.offsetAndRotation(0.0F, 2.5F, 18.7F, -0.4363F, 0.0F, 0.0F));

		PartDefinition cube_r35 = bone12.addOrReplaceChild("cube_r35",
				CubeListBuilder.create().texOffs(0, 177)
						.addBox(-0.626F, -0.3929F, -0.5F, 6.0F, 1.0F, 1.0F, new CubeDeformation(0.0F)).texOffs(176, 171)
						.addBox(-0.626F, -0.3929F, 26.5F, 6.0F, 1.0F, 1.0F, new CubeDeformation(0.0F)),
				PartPose.offsetAndRotation(10.0F, 3.8F, -14.8F, 0.0F, 0.0F, -1.9635F));

		PartDefinition cube_r36 = bone12.addOrReplaceChild("cube_r36",
				CubeListBuilder.create().texOffs(176, 175)
						.addBox(-0.626F, -0.3929F, -0.5F, 6.0F, 1.0F, 1.0F, new CubeDeformation(0.0F)).texOffs(176, 173)
						.addBox(-0.626F, -0.3929F, 26.5F, 6.0F, 1.0F, 1.0F, new CubeDeformation(0.0F)),
				PartPose.offsetAndRotation(10.0F, 3.8F, -14.8F, 0.0F, 0.0F, -3.0107F));

		PartDefinition cube_r37 = bone12.addOrReplaceChild("cube_r37",
				CubeListBuilder.create().texOffs(180, 50).addBox(-5.7185F, -0.3929F, -0.5F, 6.0F, 1.0F, 1.0F,
						new CubeDeformation(0.0F)),
				PartPose.offsetAndRotation(-9.9F, 4.1F, 11.2F, 0.0F, 0.0F, 1.2654F));

		PartDefinition cube_r38 = bone12.addOrReplaceChild("cube_r38",
				CubeListBuilder.create().texOffs(176, 169)
						.addBox(-2.5F, 1.4F, 0.0F, 6.0F, 1.0F, 1.0F, new CubeDeformation(0.0F)).texOffs(154, 89)
						.addBox(-2.5F, 0.4F, 0.0F, 5.0F, 1.0F, 1.0F, new CubeDeformation(0.0F)).texOffs(0, 181)
						.addBox(-2.1F, -0.6F, 0.0F, 4.0F, 1.0F, 1.0F, new CubeDeformation(0.0F)).texOffs(28, 179)
						.addBox(-2.7F, -1.6F, 0.0F, 4.0F, 1.0F, 1.0F, new CubeDeformation(0.0F)).texOffs(182, 18)
						.addBox(-3.1F, -2.6F, 0.0F, 4.0F, 1.0F, 1.0F, new CubeDeformation(0.0F)).texOffs(182, 16)
						.addBox(-3.9F, -3.6F, 0.0F, 4.0F, 1.0F, 1.0F, new CubeDeformation(0.0F)).texOffs(182, 14)
						.addBox(-4.0F, -4.2F, 0.0F, 4.0F, 1.0F, 1.0F, new CubeDeformation(0.0F)),
				PartPose.offsetAndRotation(-8.0F, -5.9F, 12.7F, 0.0F, 3.1416F, 0.0F));

		PartDefinition cube_r39 = bone12.addOrReplaceChild("cube_r39",
				CubeListBuilder.create().texOffs(58, 91).addBox(3.5F, -4.4F, -15.0F, 1.0F, 8.0F, 28.0F,
						new CubeDeformation(0.0F)),
				PartPose.offsetAndRotation(6.6F, -4.1F, -0.3F, 0.0F, 0.0F, -0.5672F));

		PartDefinition cube_r40 = bone12.addOrReplaceChild("cube_r40",
				CubeListBuilder.create().texOffs(116, 91).addBox(0.1377F, -6.3016F, -14.0F, 1.0F, 6.0F, 28.0F,
						new CubeDeformation(0.0F)),
				PartPose.offsetAndRotation(7.9F, -9.0F, -1.3F, 0.0F, 0.0F, -1.2654F));

		PartDefinition cube_r41 = bone12.addOrReplaceChild("cube_r41",
				CubeListBuilder.create().texOffs(104, 0).addBox(-1.0F, -14.0F, -14.0F, 1.0F, 6.0F, 28.0F,
						new CubeDeformation(0.0F)),
				PartPose.offsetAndRotation(-15.3F, -6.8F, -1.3F, 0.0F, 0.0F, 1.2654F));

		PartDefinition cube_r42 = bone12.addOrReplaceChild("cube_r42",
				CubeListBuilder.create().texOffs(0, 91).addBox(-1.0F, -8.0F, -14.0F, 1.0F, 8.0F, 28.0F,
						new CubeDeformation(0.0F)),
				PartPose.offsetAndRotation(-11.5F, -2.9F, -1.3F, 0.0F, 0.0F, 0.5672F));

		PartDefinition cube_r43 = bone12.addOrReplaceChild("cube_r43", CubeListBuilder.create().texOffs(176, 161)
				.addBox(0.3277F, -0.6936F, -13.5F, 6.0F, 1.0F, 1.0F, new CubeDeformation(0.0F)).texOffs(176, 159)
				.addBox(0.3277F, -0.6936F, -11.5F, 6.0F, 1.0F, 1.0F, new CubeDeformation(0.0F)).texOffs(176, 157)
				.addBox(0.3277F, -0.6936F, -9.5F, 6.0F, 1.0F, 1.0F, new CubeDeformation(0.0F)).texOffs(176, 155)
				.addBox(0.3277F, -0.6936F, -7.5F, 6.0F, 1.0F, 1.0F, new CubeDeformation(0.0F)).texOffs(176, 153)
				.addBox(0.3277F, -0.6936F, -5.5F, 6.0F, 1.0F, 1.0F, new CubeDeformation(0.0F)).texOffs(176, 151)
				.addBox(0.3277F, -0.6936F, -3.5F, 6.0F, 1.0F, 1.0F, new CubeDeformation(0.0F)).texOffs(176, 149)
				.addBox(0.3277F, -0.6936F, -1.5F, 6.0F, 1.0F, 1.0F, new CubeDeformation(0.0F)).texOffs(176, 147)
				.addBox(0.3277F, -0.6936F, 0.5F, 6.0F, 1.0F, 1.0F, new CubeDeformation(0.0F)).texOffs(176, 145)
				.addBox(0.3277F, -0.6936F, 2.5F, 6.0F, 1.0F, 1.0F, new CubeDeformation(0.0F)).texOffs(90, 30)
				.addBox(0.3277F, -0.6936F, 4.5F, 6.0F, 1.0F, 1.0F, new CubeDeformation(0.0F)).texOffs(176, 143)
				.addBox(0.3277F, -0.6936F, 6.5F, 6.0F, 1.0F, 1.0F, new CubeDeformation(0.0F)).texOffs(176, 141)
				.addBox(0.3277F, -0.6936F, 8.5F, 6.0F, 1.0F, 1.0F, new CubeDeformation(0.0F)).texOffs(176, 139)
				.addBox(0.3277F, -0.6936F, 10.5F, 6.0F, 1.0F, 1.0F, new CubeDeformation(0.0F)).texOffs(90, 32)
				.addBox(0.3277F, -0.6936F, 12.5F, 6.0F, 1.0F, 1.0F, new CubeDeformation(0.0F)),
				PartPose.offsetAndRotation(10.0F, 4.8F, -1.8F, 0.0F, 0.0F, -1.2654F));

		PartDefinition cube_r44 = bone12.addOrReplaceChild("cube_r44",
				CubeListBuilder.create().texOffs(174, 106)
						.addBox(-1.0F, 0.0F, -0.5F, 8.0F, 1.0F, 1.0F, new CubeDeformation(0.0F)).texOffs(174, 104)
						.addBox(-1.0F, 0.0F, 1.5F, 8.0F, 1.0F, 1.0F, new CubeDeformation(0.0F)).texOffs(174, 102)
						.addBox(-1.0F, 0.0F, -4.5F, 8.0F, 1.0F, 1.0F, new CubeDeformation(0.0F)).texOffs(174, 100)
						.addBox(-1.0F, 0.0F, -6.5F, 8.0F, 1.0F, 1.0F, new CubeDeformation(0.0F)).texOffs(174, 98)
						.addBox(-1.0F, 0.0F, -8.5F, 8.0F, 1.0F, 1.0F, new CubeDeformation(0.0F)).texOffs(174, 96)
						.addBox(-1.0F, 0.0F, -2.5F, 8.0F, 1.0F, 1.0F, new CubeDeformation(0.0F)).texOffs(174, 94)
						.addBox(-1.0F, 0.0F, -16.5F, 8.0F, 1.0F, 1.0F, new CubeDeformation(0.0F)).texOffs(94, 174)
						.addBox(-1.0F, 0.0F, -14.5F, 8.0F, 1.0F, 1.0F, new CubeDeformation(0.0F)).texOffs(174, 92)
						.addBox(-1.0F, 0.0F, -12.5F, 8.0F, 1.0F, 1.0F, new CubeDeformation(0.0F)).texOffs(174, 90)
						.addBox(-1.0F, 0.0F, -10.5F, 8.0F, 1.0F, 1.0F, new CubeDeformation(0.0F)).texOffs(76, 174)
						.addBox(-1.0F, 0.0F, -20.5F, 8.0F, 1.0F, 1.0F, new CubeDeformation(0.0F)).texOffs(134, 173)
						.addBox(-1.0F, 0.0F, -18.5F, 8.0F, 1.0F, 1.0F, new CubeDeformation(0.0F)).texOffs(94, 172)
						.addBox(-1.0F, 0.0F, -22.5F, 8.0F, 1.0F, 1.0F, new CubeDeformation(0.0F)).texOffs(76, 172)
						.addBox(-1.0F, 0.0F, -24.5F, 8.0F, 1.0F, 1.0F, new CubeDeformation(0.0F)),
				PartPose.offsetAndRotation(4.0F, 7.5F, 9.2F, 0.0F, 0.0F, -0.5672F));

		return LayerDefinition.create(meshdefinition, 256, 256);
	}

	@Override
	public void renderToBuffer(PoseStack poseStack, VertexConsumer vertexConsumer, int packedLight, int packedOverlay,
			float red, float green, float blue, float alpha) {
		legs.render(poseStack, vertexConsumer, packedLight, packedOverlay, red, green, blue, alpha);
		bone9.render(poseStack, vertexConsumer, packedLight, packedOverlay, red, green, blue, alpha);
		bone10.render(poseStack, vertexConsumer, packedLight, packedOverlay, red, green, blue, alpha);
		bone11.render(poseStack, vertexConsumer, packedLight, packedOverlay, red, green, blue, alpha);
		onon.render(poseStack, vertexConsumer, packedLight, packedOverlay, red, green, blue, alpha);
		howa.render(poseStack, vertexConsumer, packedLight, packedOverlay, red, green, blue, alpha);
		bone24.render(poseStack, vertexConsumer, packedLight, packedOverlay, red, green, blue, alpha);
		bone12.render(poseStack, vertexConsumer, packedLight, packedOverlay, red, green, blue, alpha);
	}

	public void setupAnim(T entity, float limbSwing, float limbSwingAmount, float ageInTicks, float netHeadYaw,
			float headPitch) {
	}
}