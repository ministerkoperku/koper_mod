// Made with Blockbench 4.12.5
// Exported for Minecraft version 1.17 or later with Mojang mappings
// Paste this class into your mod and generate all required imports

public class Modelleviatan_haosu<T extends Entity> extends EntityModel<T> {
	// This layer location should be baked with EntityRendererProvider.Context in
	// the entity renderer and passed into this model's constructor
	public static final ModelLayerLocation LAYER_LOCATION = new ModelLayerLocation(
			new ResourceLocation("modid", "leviatan_haosu"), "main");
	private final ModelPart bone25;
	private final ModelPart nogi;
	private final ModelPart bone2;
	private final ModelPart bone24;
	private final ModelPart bone4;
	private final ModelPart bone21;
	private final ModelPart bone3;
	private final ModelPart bone23;
	private final ModelPart bone;
	private final ModelPart bone22;
	private final ModelPart bone5;
	private final ModelPart bone12;
	private final ModelPart bone7;
	private final ModelPart bone17;
	private final ModelPart bone18;
	private final ModelPart bone19;
	private final ModelPart bone11;
	private final ModelPart bone10;
	private final ModelPart bone9;
	private final ModelPart bone8;
	private final ModelPart bone20;
	private final ModelPart bone6;
	private final ModelPart bone13;
	private final ModelPart bone14;
	private final ModelPart bone15;
	private final ModelPart bone16;

	public Modelleviatan_haosu(ModelPart root) {
		this.bone25 = root.getChild("bone25");
		this.nogi = this.bone25.getChild("nogi");
		this.bone2 = this.nogi.getChild("bone2");
		this.bone24 = this.bone2.getChild("bone24");
		this.bone4 = this.nogi.getChild("bone4");
		this.bone21 = this.bone4.getChild("bone21");
		this.bone3 = this.nogi.getChild("bone3");
		this.bone23 = this.bone3.getChild("bone23");
		this.bone = this.nogi.getChild("bone");
		this.bone22 = this.bone.getChild("bone22");
		this.bone5 = this.bone25.getChild("bone5");
		this.bone12 = this.bone25.getChild("bone12");
		this.bone7 = this.bone12.getChild("bone7");
		this.bone17 = this.bone12.getChild("bone17");
		this.bone18 = this.bone17.getChild("bone18");
		this.bone19 = this.bone18.getChild("bone19");
		this.bone11 = this.bone19.getChild("bone11");
		this.bone10 = this.bone19.getChild("bone10");
		this.bone9 = this.bone19.getChild("bone9");
		this.bone8 = this.bone18.getChild("bone8");
		this.bone20 = this.bone25.getChild("bone20");
		this.bone6 = this.bone20.getChild("bone6");
		this.bone13 = this.bone20.getChild("bone13");
		this.bone14 = this.bone13.getChild("bone14");
		this.bone15 = this.bone13.getChild("bone15");
		this.bone16 = this.bone15.getChild("bone16");
	}

	public static LayerDefinition createBodyLayer() {
		MeshDefinition meshdefinition = new MeshDefinition();
		PartDefinition partdefinition = meshdefinition.getRoot();

		PartDefinition bone25 = partdefinition.addOrReplaceChild("bone25", CubeListBuilder.create(),
				PartPose.offset(0.0F, 10.7F, 2.5F));

		PartDefinition nogi = bone25.addOrReplaceChild("nogi", CubeListBuilder.create(),
				PartPose.offset(-3.0F, 6.2F, 8.9F));

		PartDefinition bone2 = nogi.addOrReplaceChild("bone2",
				CubeListBuilder.create().texOffs(0, 62)
						.addBox(-1.0F, -0.119F, -1.5642F, 2.0F, 5.0F, 3.0F, new CubeDeformation(0.001F)).texOffs(26, 71)
						.addBox(-1.0F, 11.0F, 0.6F, 2.0F, 1.0F, 2.0F, new CubeDeformation(0.01F)),
				PartPose.offset(8.0F, -6.9F, -2.0F));

		PartDefinition cube_r1 = bone2.addOrReplaceChild("cube_r1",
				CubeListBuilder.create().texOffs(34, 66).addBox(7.0F, -4.0F, -1.0F, 2.0F, 4.0F, 2.0F,
						new CubeDeformation(0.001F)),
				PartPose.offsetAndRotation(-8.0F, 11.2F, 1.6F, -0.0873F, 0.0F, 0.0F));

		PartDefinition cube_r2 = bone2.addOrReplaceChild("cube_r2",
				CubeListBuilder.create().texOffs(38, 50).addBox(7.0F, -2.019F, -3.5642F, 2.0F, 3.0F, 5.0F,
						new CubeDeformation(0.0F)),
				PartPose.offsetAndRotation(-8.0F, 6.3F, 1.7F, -0.2618F, 0.0F, 0.0F));

		PartDefinition bone24 = bone2.addOrReplaceChild("bone24", CubeListBuilder.create().texOffs(60, 44).addBox(-1.0F,
				-2.0F, -3.0F, 2.0F, 2.0F, 4.0F, new CubeDeformation(0.01F)), PartPose.offset(0.0F, 14.0F, 1.6F));

		PartDefinition bone4 = nogi.addOrReplaceChild("bone4", CubeListBuilder.create().texOffs(8, 71).addBox(-1.0F,
				10.4F, -6.2F, 2.0F, 1.0F, 2.0F, new CubeDeformation(0.01F)), PartPose.offset(-2.0F, -6.3F, -13.2F));

		PartDefinition cube_r3 = bone4.addOrReplaceChild("cube_r3",
				CubeListBuilder.create().texOffs(46, 62).addBox(-1.0F, -7.0F, -1.0F, 2.0F, 7.0F, 2.0F,
						new CubeDeformation(0.0F)),
				PartPose.offsetAndRotation(0.0F, 11.0F, -5.3F, -0.5236F, 0.0F, 0.0F));

		PartDefinition cube_r4 = bone4.addOrReplaceChild("cube_r4",
				CubeListBuilder.create().texOffs(18, 64).addBox(10.0F, -4.8646F, -0.6909F, 2.0F, 6.0F, 2.0F,
						new CubeDeformation(0.2F)),
				PartPose.offsetAndRotation(-11.0F, 4.0F, -2.0F, -0.3054F, 0.0F, 0.0F));

		PartDefinition bone21 = bone4.addOrReplaceChild("bone21", CubeListBuilder.create().texOffs(60, 38).addBox(-1.0F,
				-2.0F, -3.0F, 2.0F, 2.0F, 4.0F, new CubeDeformation(0.01F)), PartPose.offset(0.0F, 13.4F, -5.2F));

		PartDefinition bone3 = nogi.addOrReplaceChild("bone3",
				CubeListBuilder.create().texOffs(0, 62)
						.addBox(-2.0F, -0.319F, -1.9642F, 2.0F, 5.0F, 3.0F, new CubeDeformation(0.001F)).texOffs(26, 71)
						.addBox(-2.0F, 10.8F, 0.2F, 2.0F, 1.0F, 2.0F, new CubeDeformation(0.01F)),
				PartPose.offset(-1.0F, -6.7F, -1.6F));

		PartDefinition cube_r5 = bone3.addOrReplaceChild("cube_r5",
				CubeListBuilder.create().texOffs(34, 66).addBox(7.0F, -4.0F, -1.0F, 2.0F, 4.0F, 2.0F,
						new CubeDeformation(0.001F)),
				PartPose.offsetAndRotation(-9.0F, 11.0F, 1.2F, -0.0873F, 0.0F, 0.0F));

		PartDefinition cube_r6 = bone3.addOrReplaceChild("cube_r6",
				CubeListBuilder.create().texOffs(38, 50).addBox(7.0F, -2.019F, -3.5642F, 2.0F, 3.0F, 5.0F,
						new CubeDeformation(0.0F)),
				PartPose.offsetAndRotation(-9.0F, 6.1F, 1.3F, -0.2618F, 0.0F, 0.0F));

		PartDefinition bone23 = bone3.addOrReplaceChild("bone23", CubeListBuilder.create().texOffs(60, 44).addBox(-1.0F,
				0.0F, -3.0F, 2.0F, 2.0F, 4.0F, new CubeDeformation(0.01F)), PartPose.offset(-1.0F, 11.8F, 1.2F));

		PartDefinition bone = nogi.addOrReplaceChild("bone", CubeListBuilder.create().texOffs(8, 71).addBox(-1.0F,
				10.4F, -4.2F, 2.0F, 1.0F, 2.0F, new CubeDeformation(0.01F)), PartPose.offset(8.0F, -6.3F, -15.2F));

		PartDefinition cube_r7 = bone.addOrReplaceChild("cube_r7",
				CubeListBuilder.create().texOffs(46, 62).addBox(-1.0F, -7.0F, -1.0F, 2.0F, 7.0F, 2.0F,
						new CubeDeformation(0.0F)),
				PartPose.offsetAndRotation(0.0F, 11.0F, -3.3F, -0.5236F, 0.0F, 0.0F));

		PartDefinition cube_r8 = bone.addOrReplaceChild("cube_r8",
				CubeListBuilder.create().texOffs(18, 64).addBox(10.0F, -4.8646F, -0.6909F, 2.0F, 6.0F, 2.0F,
						new CubeDeformation(0.2F)),
				PartPose.offsetAndRotation(-11.0F, 4.0F, 0.0F, -0.3054F, 0.0F, 0.0F));

		PartDefinition bone22 = bone.addOrReplaceChild("bone22", CubeListBuilder.create().texOffs(60, 38).addBox(-1.0F,
				-2.0F, -3.0F, 2.0F, 2.0F, 4.0F, new CubeDeformation(0.01F)), PartPose.offset(0.0F, 13.4F, -3.2F));

		PartDefinition bone5 = bone25.addOrReplaceChild("bone5",
				CubeListBuilder.create().texOffs(0, 0)
						.addBox(-4.0F, -6.0F, -7.0F, 8.0F, 8.0F, 17.0F, new CubeDeformation(0.0F)).texOffs(64, 56)
						.addBox(-0.6F, -9.0F, -3.0F, 1.0F, 3.0F, 3.0F, new CubeDeformation(0.0F)).texOffs(72, 22)
						.addBox(-0.6F, -10.0F, -1.0F, 1.0F, 1.0F, 2.0F, new CubeDeformation(0.0F)).texOffs(64, 29)
						.addBox(-0.6F, -8.6F, 1.0F, 1.0F, 4.0F, 3.0F, new CubeDeformation(-0.2F)).texOffs(72, 25)
						.addBox(-0.6F, -9.2F, 2.7F, 1.0F, 1.0F, 2.0F, new CubeDeformation(-0.2F)),
				PartPose.offset(0.0F, 1.8F, -0.5F));

		PartDefinition cube_r9 = bone5.addOrReplaceChild("cube_r9",
				CubeListBuilder.create().texOffs(46, 58).addBox(-1.0F, -9.0F, -1.0F, 1.0F, 2.0F, 2.0F,
						new CubeDeformation(-0.4F)),
				PartPose.offsetAndRotation(0.4F, -1.0F, 10.4F, 0.0873F, 0.0F, 0.0F));

		PartDefinition cube_r10 = bone5.addOrReplaceChild("cube_r10",
				CubeListBuilder.create().texOffs(26, 64).addBox(-1.0F, -8.0F, -3.0F, 1.0F, 4.0F, 3.0F,
						new CubeDeformation(-0.4F)),
				PartPose.offsetAndRotation(0.4F, -0.9F, 10.6F, 0.0873F, 0.0F, 0.0F));

		PartDefinition bone12 = bone25.addOrReplaceChild("bone12", CubeListBuilder.create(),
				PartPose.offset(0.0F, 0.0F, 9.0F));

		PartDefinition bone7 = bone12.addOrReplaceChild("bone7", CubeListBuilder.create(),
				PartPose.offset(0.0F, -0.6F, -0.6F));

		PartDefinition cube_r11 = bone7
				.addOrReplaceChild("cube_r11",
						CubeListBuilder.create().texOffs(42, 71).addBox(-1.0F, -9.0F, -1.0F, 1.0F, 1.0F, 2.0F,
								new CubeDeformation(-0.2F)),
						PartPose.offsetAndRotation(0.4F, 3.1F, 5.8F, 0.0873F, 0.0F, 0.0F));

		PartDefinition cube_r12 = bone7
				.addOrReplaceChild("cube_r12",
						CubeListBuilder.create().texOffs(64, 22).addBox(-1.0F, -8.0F, -3.0F, 1.0F, 4.0F, 3.0F,
								new CubeDeformation(-0.2F)),
						PartPose.offsetAndRotation(0.4F, 2.6F, 6.1F, 0.0873F, 0.0F, 0.0F));

		PartDefinition cube_r13 = bone7.addOrReplaceChild("cube_r13",
				CubeListBuilder.create().texOffs(34, 38).addBox(-3.0F, -3.3F, 0.0F, 6.0F, 5.0F, 7.0F,
						new CubeDeformation(0.001F)),
				PartPose.offsetAndRotation(0.0F, 0.0F, 0.0F, -0.2618F, 0.0F, 0.0F));

		PartDefinition bone17 = bone12.addOrReplaceChild("bone17", CubeListBuilder.create(),
				PartPose.offset(0.0F, 0.0F, 0.0F));

		PartDefinition bone18 = bone17.addOrReplaceChild("bone18", CubeListBuilder.create(),
				PartPose.offset(0.0F, 0.0F, 0.0F));

		PartDefinition bone19 = bone18.addOrReplaceChild("bone19", CubeListBuilder.create(),
				PartPose.offset(0.0F, 0.1F, 11.4F));

		PartDefinition bone11 = bone19.addOrReplaceChild("bone11", CubeListBuilder.create(),
				PartPose.offset(0.0F, -2.0F, 6.0F));

		PartDefinition cube_r14 = bone11.addOrReplaceChild("cube_r14",
				CubeListBuilder.create().texOffs(68, 70).addBox(-1.0F, 0.3368F, 6.4796F, 2.0F, 1.0F, 2.0F,
						new CubeDeformation(-0.001F)),
				PartPose.offsetAndRotation(0.0F, 1.9F, -6.4F, 0.4363F, 0.0F, 0.0F));

		PartDefinition bone10 = bone19.addOrReplaceChild("bone10", CubeListBuilder.create(),
				PartPose.offset(0.5F, -0.3F, 3.6F));

		PartDefinition cube_r15 = bone10.addOrReplaceChild("cube_r15",
				CubeListBuilder.create().texOffs(64, 18).addBox(-2.0F, 0.3368F, 3.4796F, 3.0F, 1.0F, 3.0F,
						new CubeDeformation(-0.001F)),
				PartPose.offsetAndRotation(0.0F, 0.2F, -4.0F, 0.4363F, 0.0F, 0.0F));

		PartDefinition bone9 = bone19.addOrReplaceChild("bone9", CubeListBuilder.create(),
				PartPose.offset(0.5F, 0.4F, 0.1F));

		PartDefinition cube_r16 = bone9
				.addOrReplaceChild("cube_r16",
						CubeListBuilder.create().texOffs(50, 18).addBox(-2.0F, -0.6632F, -0.5204F, 3.0F, 2.0F, 4.0F,
								new CubeDeformation(0.0F)),
						PartPose.offsetAndRotation(0.0F, 0.0F, 0.0F, 0.4363F, 0.0F, 0.0F));

		PartDefinition bone8 = bone18.addOrReplaceChild("bone8", CubeListBuilder.create(),
				PartPose.offset(0.5F, 0.7F, 7.2F));

		PartDefinition cube_r17 = bone8.addOrReplaceChild("cube_r17",
				CubeListBuilder.create().texOffs(24, 43).addBox(-1.0F, -8.0F, -3.0F, 1.0F, 4.0F, 3.0F,
						new CubeDeformation(-0.8F)),
				PartPose.offsetAndRotation(-0.1F, 4.5F, 6.0F, 0.0873F, 0.0F, 0.0F));

		PartDefinition cube_r18 = bone8.addOrReplaceChild("cube_r18",
				CubeListBuilder.create().texOffs(54, 70).addBox(-1.0F, -10.0F, -1.0F, 1.0F, 2.0F, 3.0F,
						new CubeDeformation(-0.8F)),
				PartPose.offsetAndRotation(-0.1F, 6.3F, 4.6F, 0.0873F, 0.0F, 0.0F));

		PartDefinition cube_r19 = bone8.addOrReplaceChild("cube_r19",
				CubeListBuilder.create().texOffs(0, 70).addBox(-1.0F, -10.0F, -1.0F, 1.0F, 2.0F, 3.0F,
						new CubeDeformation(-0.5F)),
				PartPose.offsetAndRotation(-0.1F, 4.5F, 2.2F, 0.0873F, 0.0F, 0.0F));

		PartDefinition cube_r20 = bone8.addOrReplaceChild("cube_r20",
				CubeListBuilder.create().texOffs(54, 62).addBox(-1.0F, -9.0F, -3.0F, 1.0F, 5.0F, 3.0F,
						new CubeDeformation(-0.5F)),
				PartPose.offsetAndRotation(-0.1F, 4.1F, 3.3F, 0.0873F, 0.0F, 0.0F));

		PartDefinition cube_r21 = bone8
				.addOrReplaceChild("cube_r21",
						CubeListBuilder.create().texOffs(50, 8).addBox(-3.0F, -2.3508F, -1.4016F, 5.0F, 4.0F, 6.0F,
								new CubeDeformation(0.0F)),
						PartPose.offsetAndRotation(0.0F, 0.0F, 0.0F, -0.1309F, 0.0F, 0.0F));

		PartDefinition bone20 = bone25.addOrReplaceChild("bone20", CubeListBuilder.create(),
				PartPose.offset(0.5F, 0.8F, -5.2F));

		PartDefinition bone6 = bone20.addOrReplaceChild("bone6", CubeListBuilder.create(),
				PartPose.offset(0.0F, 0.0F, 0.0F));

		PartDefinition cube_r22 = bone6.addOrReplaceChild("cube_r22",
				CubeListBuilder.create().texOffs(38, 72).addBox(-1.0F, -9.0F, -6.0F, 1.0F, 1.0F, 1.0F,
						new CubeDeformation(0.0F)),
				PartPose.offsetAndRotation(0.0F, -0.9F, -1.0F, -0.829F, 0.0F, 0.0F));

		PartDefinition cube_r23 = bone6.addOrReplaceChild("cube_r23",
				CubeListBuilder.create().texOffs(52, 50)
						.addBox(-1.0F, -4.0F, -9.0F, 1.0F, 1.0F, 5.0F, new CubeDeformation(0.0F)).texOffs(16, 72)
						.addBox(-1.0F, -5.0F, -9.0F, 1.0F, 1.0F, 2.0F, new CubeDeformation(0.0F)).texOffs(62, 70)
						.addBox(-1.0F, -8.0F, -7.0F, 1.0F, 4.0F, 2.0F, new CubeDeformation(0.0F)),
				PartPose.offsetAndRotation(0.0F, -0.6F, -0.6F, -0.829F, 0.0F, 0.0F));

		PartDefinition cube_r24 = bone6
				.addOrReplaceChild("cube_r24",
						CubeListBuilder.create().texOffs(0, 25).addBox(-3.0F, -3.0F, -12.0F, 5.0F, 6.0F, 12.0F,
								new CubeDeformation(0.0F)),
						PartPose.offsetAndRotation(0.0F, 0.0F, 0.0F, -0.829F, 0.0F, 0.0F));

		PartDefinition bone13 = bone20.addOrReplaceChild("bone13",
				CubeListBuilder.create().texOffs(22, 72)
						.addBox(-4.0F, -3.0F, -7.0F, 1.0F, 1.0F, 1.0F, new CubeDeformation(0.0F)).texOffs(72, 50)
						.addBox(-0.4F, -3.0F, -11.0F, 1.0F, 1.0F, 1.0F, new CubeDeformation(0.0F)).texOffs(72, 34)
						.addBox(2.0F, -3.0F, -7.0F, 1.0F, 1.0F, 1.0F, new CubeDeformation(0.0F)).texOffs(42, 66)
						.addBox(2.0F, -3.0F, -9.4F, 1.0F, 1.0F, 1.0F, new CubeDeformation(0.0F)).texOffs(68, 36)
						.addBox(-4.0F, -3.0F, -9.4F, 1.0F, 1.0F, 1.0F, new CubeDeformation(0.0F)).texOffs(34, 25)
						.addBox(-4.0F, -8.0F, -11.0F, 7.0F, 5.0F, 8.0F, new CubeDeformation(0.0F)).texOffs(72, 36)
						.addBox(-2.8F, -3.0F, -11.0F, 1.0F, 1.0F, 1.0F, new CubeDeformation(0.0F)).texOffs(72, 42)
						.addBox(-4.0F, -3.0F, -11.0F, 1.0F, 1.0F, 1.0F, new CubeDeformation(0.0F)).texOffs(72, 44)
						.addBox(2.0F, -3.0F, -11.0F, 1.0F, 1.0F, 1.0F, new CubeDeformation(0.0F)).texOffs(72, 46)
						.addBox(-1.7F, -3.0F, -11.0F, 1.0F, 1.0F, 1.0F, new CubeDeformation(0.0F)).texOffs(72, 48)
						.addBox(0.7F, -3.0F, -11.0F, 1.0F, 1.0F, 1.0F, new CubeDeformation(0.0F)).texOffs(0, 43)
						.addBox(-4.0F, -8.0F, -5.0F, 7.0F, 8.0F, 5.0F, new CubeDeformation(0.001F)),
				PartPose.offset(0.0F, -6.3F, -5.1F));

		PartDefinition bone14 = bone13.addOrReplaceChild("bone14", CubeListBuilder.create(),
				PartPose.offset(0.0F, -0.1F, -4.2F));

		PartDefinition cube_r25 = bone14.addOrReplaceChild("cube_r25",
				CubeListBuilder.create().texOffs(64, 36)
						.addBox(-4.0F, -2.0F, -3.5F, 1.0F, 1.0F, 1.0F, new CubeDeformation(0.0F)).texOffs(18, 62)
						.addBox(-10.0F, -2.0F, -3.5F, 1.0F, 1.0F, 1.0F, new CubeDeformation(0.0F)),
				PartPose.offsetAndRotation(6.0F, 0.6F, -2.4F, 0.2182F, 0.0F, 0.0F));

		PartDefinition cube_r26 = bone14.addOrReplaceChild("cube_r26",
				CubeListBuilder.create().texOffs(72, 32)
						.addBox(-4.0F, -2.0F, -3.5F, 1.0F, 1.0F, 1.0F, new CubeDeformation(0.0F)).texOffs(72, 30)
						.addBox(-10.0F, -2.0F, -3.5F, 1.0F, 1.0F, 1.0F, new CubeDeformation(0.0F)),
				PartPose.offsetAndRotation(6.0F, 0.1F, -0.2F, 0.2182F, 0.0F, 0.0F));

		PartDefinition cube_r27 = bone14.addOrReplaceChild("cube_r27",
				CubeListBuilder.create().texOffs(34, 72)
						.addBox(-4.0F, -2.0F, -1.5F, 1.0F, 1.0F, 1.0F, new CubeDeformation(0.0F)).texOffs(42, 68)
						.addBox(-5.3F, -2.0F, -6.5F, 1.0F, 1.0F, 1.0F, new CubeDeformation(0.0F)).texOffs(72, 40)
						.addBox(-6.4F, -2.0F, -6.5F, 1.0F, 1.0F, 1.0F, new CubeDeformation(0.0F)).texOffs(72, 38)
						.addBox(-7.6F, -2.0F, -6.5F, 1.0F, 1.0F, 1.0F, new CubeDeformation(0.0F)).texOffs(70, 68)
						.addBox(-8.7F, -2.0F, -6.5F, 1.0F, 1.0F, 1.0F, new CubeDeformation(0.0F)).texOffs(72, 28)
						.addBox(-10.0F, -2.0F, -1.5F, 1.0F, 1.0F, 1.0F, new CubeDeformation(0.0F)).texOffs(50, 0)
						.addBox(-10.0F, -1.0F, -6.5F, 7.0F, 1.0F, 7.0F, new CubeDeformation(0.0F)),
				PartPose.offsetAndRotation(6.0F, 0.0F, 0.0F, 0.2182F, 0.0F, 0.0F));

		PartDefinition bone15 = bone13.addOrReplaceChild("bone15", CubeListBuilder.create(),
				PartPose.offset(-0.5F, -7.0F, 0.0F));

		PartDefinition cube_r28 = bone15.addOrReplaceChild("cube_r28",
				CubeListBuilder.create().texOffs(48, 71)
						.addBox(-5.0F, -2.0F, 4.0F, 1.0F, 1.0F, 2.0F, new CubeDeformation(0.001F)).texOffs(72, 14)
						.addBox(-4.9F, -2.0F, -1.0F, 2.0F, 2.0F, 1.0F, new CubeDeformation(0.001F)).texOffs(0, 56)
						.addBox(-5.2F, -2.0F, 0.0F, 2.0F, 2.0F, 4.0F, new CubeDeformation(0.001F)),
				PartPose.offsetAndRotation(1.2F, 0.0F, 0.0F, 0.1745F, 0.0F, 0.0F));

		PartDefinition bone16 = bone15.addOrReplaceChild("bone16", CubeListBuilder.create(),
				PartPose.offset(2.0F, 0.0F, 0.0F));

		PartDefinition cube_r29 = bone16.addOrReplaceChild("cube_r29",
				CubeListBuilder.create().texOffs(72, 14)
						.addBox(1.0F, -2.0F, -1.0F, 2.0F, 2.0F, 1.0F, new CubeDeformation(0.001F)).texOffs(0, 56)
						.addBox(1.3F, -2.0F, 0.0F, 2.0F, 2.0F, 4.0F, new CubeDeformation(0.001F)).texOffs(48, 71)
						.addBox(1.5F, -2.0F, 4.0F, 1.0F, 1.0F, 2.0F, new CubeDeformation(0.001F)),
				PartPose.offsetAndRotation(-1.2F, 0.0F, 0.0F, 0.1745F, 0.0F, 0.0F));

		return LayerDefinition.create(meshdefinition, 128, 128);
	}

	@Override
	public void renderToBuffer(PoseStack poseStack, VertexConsumer vertexConsumer, int packedLight, int packedOverlay,
			float red, float green, float blue, float alpha) {
		bone25.render(poseStack, vertexConsumer, packedLight, packedOverlay, red, green, blue, alpha);
	}

	public void setupAnim(T entity, float limbSwing, float limbSwingAmount, float ageInTicks, float netHeadYaw,
			float headPitch) {
	}
}