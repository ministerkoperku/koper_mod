// Made with Blockbench 4.12.5
// Exported for Minecraft version 1.17 or later with Mojang mappings
// Paste this class into your mod and generate all required imports

public class Modelszkinid1i<T extends Entity> extends EntityModel<T> {
	// This layer location should be baked with EntityRendererProvider.Context in
	// the entity renderer and passed into this model's constructor
	public static final ModelLayerLocation LAYER_LOCATION = new ModelLayerLocation(
			new ResourceLocation("modid", "szkinid1i"), "main");
	private final ModelPart main;
	private final ModelPart Body;
	private final ModelPart RightArm;
	private final ModelPart LeftArm;
	private final ModelPart RightLeg;
	private final ModelPart LeftLeg;
	private final ModelPart Rightfoot;
	private final ModelPart Leftfoot;

	public Modelszkinid1i(ModelPart root) {
		this.main = root.getChild("main");
		this.Body = this.main.getChild("Body");
		this.RightArm = this.main.getChild("RightArm");
		this.LeftArm = this.main.getChild("LeftArm");
		this.RightLeg = this.main.getChild("RightLeg");
		this.LeftLeg = this.main.getChild("LeftLeg");
		this.Rightfoot = this.main.getChild("Rightfoot");
		this.Leftfoot = this.main.getChild("Leftfoot");
	}

	public static LayerDefinition createBodyLayer() {
		MeshDefinition meshdefinition = new MeshDefinition();
		PartDefinition partdefinition = meshdefinition.getRoot();

		PartDefinition main = partdefinition.addOrReplaceChild("main", CubeListBuilder.create(),
				PartPose.offset(0.0F, 24.0F, 0.0F));

		PartDefinition Body = main.addOrReplaceChild("Body",
				CubeListBuilder.create().texOffs(0, 0)
						.addBox(-4.0F, 0.0F, 2.5F, 8.0F, 11.0F, 1.0F, new CubeDeformation(0.25F)).texOffs(0, 12)
						.addBox(-4.0F, 0.0F, -2.0F, 8.0F, 2.0F, 4.0F, new CubeDeformation(0.25F)).texOffs(0, 39)
						.addBox(-0.5F, 1.0F, -0.5F, 1.0F, 11.0F, 1.0F, new CubeDeformation(0.25F)).texOffs(0, 18)
						.addBox(-4.0F, 3.0F, 4.0F, 8.0F, 8.0F, 1.0F, new CubeDeformation(0.25F)),
				PartPose.offset(0.0F, -24.0F, 0.0F));

		PartDefinition BodyLayer_r1 = Body.addOrReplaceChild("BodyLayer_r1",
				CubeListBuilder.create().texOffs(16, 45)
						.addBox(4.0F, -15.5F, -3.3F, 1.0F, 4.0F, 1.0F, new CubeDeformation(0.25F)).texOffs(26, 42)
						.addBox(4.0F, -15.5F, -2.0F, 1.0F, 1.0F, 2.0F, new CubeDeformation(0.25F)).texOffs(36, 42)
						.addBox(4.0F, -15.5F, 0.0F, 1.0F, 4.0F, 1.0F, new CubeDeformation(0.25F)),
				PartPose.offsetAndRotation(0.0F, 24.0F, 0.0F, -0.0869F, -0.0076F, -0.0869F));

		PartDefinition BodyLayer_r2 = Body.addOrReplaceChild("BodyLayer_r2",
				CubeListBuilder.create().texOffs(16, 42).addBox(0.7F, -20.1F, -2.6F, 1.0F, 1.0F, 2.0F,
						new CubeDeformation(0.25F)),
				PartPose.offsetAndRotation(0.0F, 24.0F, 0.0F, -0.0869F, 0.0076F, 0.0869F));

		PartDefinition BodyLayer_r3 = Body.addOrReplaceChild("BodyLayer_r3",
				CubeListBuilder.create().texOffs(18, 8).addBox(-1.7F, -20.1F, -2.6F, 1.0F, 1.0F, 2.0F,
						new CubeDeformation(0.25F)),
				PartPose.offsetAndRotation(0.0F, 24.0F, 0.0F, -0.0869F, -0.0076F, -0.0869F));

		PartDefinition BodyLayer_r4 = Body.addOrReplaceChild("BodyLayer_r4",
				CubeListBuilder.create().texOffs(40, 42)
						.addBox(-5.0F, -15.5F, -2.0F, 1.0F, 1.0F, 2.0F, new CubeDeformation(0.25F)).texOffs(22, 42)
						.addBox(-5.0F, -15.5F, -3.3F, 1.0F, 4.0F, 1.0F, new CubeDeformation(0.25F)).texOffs(32, 42)
						.addBox(-5.0F, -15.5F, 0.0F, 1.0F, 4.0F, 1.0F, new CubeDeformation(0.25F)),
				PartPose.offsetAndRotation(0.0F, 24.0F, 0.0F, -0.0869F, 0.0076F, 0.0869F));

		PartDefinition BodyLayer_r5 = Body.addOrReplaceChild("BodyLayer_r5",
				CubeListBuilder.create().texOffs(48, 40)
						.addBox(4.0F, -18.5F, -0.6F, 1.0F, 3.0F, 1.0F, new CubeDeformation(0.25F)).texOffs(48, 48)
						.addBox(4.0F, -18.5F, 2.7F, 1.0F, 3.0F, 1.0F, new CubeDeformation(0.25F)),
				PartPose.offsetAndRotation(0.0F, 24.0F, 0.0F, 0.0869F, 0.0076F, -0.0869F));

		PartDefinition BodyLayer_r6 = Body.addOrReplaceChild("BodyLayer_r6",
				CubeListBuilder.create().texOffs(48, 44)
						.addBox(-5.0F, -18.5F, -0.6F, 1.0F, 3.0F, 1.0F, new CubeDeformation(0.25F)).texOffs(50, 5)
						.addBox(-5.0F, -18.5F, 2.7F, 1.0F, 3.0F, 1.0F, new CubeDeformation(0.25F)),
				PartPose.offsetAndRotation(0.0F, 24.0F, 0.0F, 0.0869F, -0.0076F, 0.0869F));

		PartDefinition BodyLayer_r7 = Body.addOrReplaceChild("BodyLayer_r7",
				CubeListBuilder.create().texOffs(16, 40)
						.addBox(-2.5F, -22.3F, -0.7F, 5.0F, 1.0F, 1.0F, new CubeDeformation(0.25F)).texOffs(24, 15)
						.addBox(-2.5F, -21.7F, -3.9F, 5.0F, 1.0F, 1.0F, new CubeDeformation(0.25F)).texOffs(36, 30)
						.addBox(-2.5F, -15.8F, -3.3F, 5.0F, 1.0F, 1.0F, new CubeDeformation(0.25F)).texOffs(4, 39)
						.addBox(-2.5F, -15.8F, 0.0F, 5.0F, 1.0F, 1.0F, new CubeDeformation(0.25F)),
				PartPose.offsetAndRotation(0.0F, 24.0F, 0.0F, -0.0873F, 0.0F, 0.0F));

		PartDefinition BodyLayer_r8 = Body.addOrReplaceChild("BodyLayer_r8",
				CubeListBuilder.create().texOffs(36, 28)
						.addBox(-2.5F, -19.8F, 2.8F, 5.0F, 1.0F, 1.0F, new CubeDeformation(0.25F)).texOffs(36, 5)
						.addBox(-2.5F, -19.1F, -0.6F, 5.0F, 1.0F, 1.0F, new CubeDeformation(0.25F)),
				PartPose.offsetAndRotation(0.0F, 24.0F, 0.0F, 0.0873F, 0.0F, 0.0F));

		PartDefinition BodyLayer_r9 = Body.addOrReplaceChild("BodyLayer_r9",
				CubeListBuilder.create().texOffs(24, 50)
						.addBox(-1.7F, -21.9F, -3.9F, 1.0F, 3.0F, 1.0F, new CubeDeformation(0.25F)).texOffs(50, 9)
						.addBox(-1.7F, -22.5F, -0.7F, 1.0F, 3.0F, 1.0F, new CubeDeformation(0.25F)),
				PartPose.offsetAndRotation(0.0F, 24.0F, 0.0F, -0.0876F, 0.0076F, -0.0869F));

		PartDefinition BodyLayer_r10 = Body.addOrReplaceChild("BodyLayer_r10",
				CubeListBuilder.create().texOffs(50, 30)
						.addBox(0.7F, -21.9F, -3.9F, 1.0F, 3.0F, 1.0F, new CubeDeformation(0.25F)).texOffs(16, 50)
						.addBox(0.7F, -22.5F, -0.7F, 1.0F, 3.0F, 1.0F, new CubeDeformation(0.25F)),
				PartPose.offsetAndRotation(0.0F, 24.0F, 0.0F, -0.0876F, -0.0076F, 0.0869F));

		PartDefinition BodyLayer_r11 = Body.addOrReplaceChild("BodyLayer_r11",
				CubeListBuilder.create().texOffs(36, 24)
						.addBox(-5.0F, -23.5F, -6.2F, 3.0F, 1.0F, 3.0F, new CubeDeformation(0.25F)).texOffs(46, 12)
						.addBox(-4.0F, -22.5F, -5.2F, 1.0F, 2.0F, 1.0F, new CubeDeformation(0.25F)).texOffs(42, 13)
						.addBox(-4.0F, -24.5F, -5.2F, 1.0F, 1.0F, 1.0F, new CubeDeformation(0.25F)).texOffs(50, 13)
						.addBox(3.0F, -24.5F, -5.2F, 1.0F, 1.0F, 1.0F, new CubeDeformation(0.25F)).texOffs(50, 34)
						.addBox(3.0F, -22.5F, -5.2F, 1.0F, 2.0F, 1.0F, new CubeDeformation(0.25F)).texOffs(36, 20)
						.addBox(2.0F, -23.5F, -6.2F, 3.0F, 1.0F, 3.0F, new CubeDeformation(0.25F)),
				PartPose.offsetAndRotation(0.0F, 24.0F, 0.0F, -0.4363F, 0.0F, 0.0F));

		PartDefinition RightArm = main.addOrReplaceChild("RightArm",
				CubeListBuilder.create().texOffs(36, 0)
						.addBox(-3.0F, 6.0F, -2.0F, 4.0F, 1.0F, 4.0F, new CubeDeformation(0.25F)).texOffs(26, 45)
						.addBox(-3.0F, 1.5F, -2.0F, 1.0F, 4.0F, 1.0F, new CubeDeformation(0.25F)).texOffs(40, 45)
						.addBox(-3.0F, 1.5F, 1.0F, 1.0F, 4.0F, 1.0F, new CubeDeformation(0.25F)).texOffs(46, 7)
						.addBox(0.0F, 1.5F, -2.0F, 1.0F, 4.0F, 1.0F, new CubeDeformation(0.25F)).texOffs(44, 45)
						.addBox(0.0F, 1.5F, 1.0F, 1.0F, 4.0F, 1.0F, new CubeDeformation(0.25F)).texOffs(34, 33)
						.addBox(-3.0F, -2.0F, -2.0F, 4.0F, 3.0F, 4.0F, new CubeDeformation(0.25F)),
				PartPose.offset(-5.0F, -22.0F, 0.0F));

		PartDefinition LeftArm = main.addOrReplaceChild("LeftArm",
				CubeListBuilder.create().texOffs(18, 33)
						.addBox(-1.0F, -2.0F, -2.0F, 4.0F, 3.0F, 4.0F, new CubeDeformation(0.25F)).texOffs(36, 15)
						.addBox(-1.0F, 7.0F, -2.0F, 4.0F, 1.0F, 4.0F, new CubeDeformation(0.25F)).texOffs(4, 41)
						.addBox(-1.0F, 1.5F, -2.0F, 1.0F, 5.0F, 1.0F, new CubeDeformation(0.25F)).texOffs(8, 41)
						.addBox(-1.0F, 1.5F, 1.0F, 1.0F, 5.0F, 1.0F, new CubeDeformation(0.25F)).texOffs(42, 7)
						.addBox(2.0F, 1.5F, -2.0F, 1.0F, 5.0F, 1.0F, new CubeDeformation(0.25F)).texOffs(12, 41)
						.addBox(2.0F, 1.5F, 1.0F, 1.0F, 5.0F, 1.0F, new CubeDeformation(0.25F)),
				PartPose.offset(5.0F, -22.0F, 0.0F));

		PartDefinition RightLeg = main.addOrReplaceChild("RightLeg",
				CubeListBuilder.create().texOffs(48, 25)
						.addBox(0.9F, 3.5F, 1.5F, 1.0F, 4.0F, 1.0F, new CubeDeformation(0.25F)).texOffs(48, 20)
						.addBox(0.9F, 3.5F, -2.5F, 1.0F, 4.0F, 1.0F, new CubeDeformation(0.25F)).texOffs(34, 47)
						.addBox(-2.1F, 3.5F, -2.5F, 1.0F, 4.0F, 1.0F, new CubeDeformation(0.25F)).texOffs(0, 27)
						.addBox(-2.1F, 8.0F, -2.5F, 4.0F, 1.0F, 5.0F, new CubeDeformation(0.25F)).texOffs(30, 47)
						.addBox(-2.1F, 3.5F, 1.5F, 1.0F, 4.0F, 1.0F, new CubeDeformation(0.25F)).texOffs(18, 0)
						.addBox(-2.1F, 0.0F, -2.5F, 4.0F, 3.0F, 5.0F, new CubeDeformation(0.25F)),
				PartPose.offset(-1.9F, -12.0F, 0.0F));

		PartDefinition LeftLeg = main.addOrReplaceChild("LeftLeg",
				CubeListBuilder.create().texOffs(18, 18)
						.addBox(-1.9F, 0.0F, -2.5F, 4.0F, 3.0F, 5.0F, new CubeDeformation(0.25F)).texOffs(4, 47)
						.addBox(1.1F, 3.5F, -2.5F, 1.0F, 4.0F, 1.0F, new CubeDeformation(0.25F)).texOffs(0, 33)
						.addBox(-1.9F, 8.0F, -2.5F, 4.0F, 1.0F, 5.0F, new CubeDeformation(0.25F)).texOffs(8, 47)
						.addBox(1.1F, 3.5F, 1.5F, 1.0F, 4.0F, 1.0F, new CubeDeformation(0.25F)).texOffs(20, 47)
						.addBox(-1.9F, 3.5F, -2.5F, 1.0F, 4.0F, 1.0F, new CubeDeformation(0.25F)).texOffs(12, 47)
						.addBox(-1.9F, 3.5F, 1.5F, 1.0F, 4.0F, 1.0F, new CubeDeformation(0.25F)),
				PartPose.offset(1.9F, -12.0F, 0.0F));

		PartDefinition Rightfoot = main.addOrReplaceChild("Rightfoot",
				CubeListBuilder.create().texOffs(24, 8)
						.addBox(-6.1F, 10.0F, -2.5F, 4.0F, 2.0F, 5.0F, new CubeDeformation(0.25F)).texOffs(38, 40)
						.addBox(-6.1F, 11.0F, -4.0F, 4.0F, 1.0F, 1.0F, new CubeDeformation(0.25F)),
				PartPose.offset(2.1F, -12.0F, 0.0F));

		PartDefinition Leftfoot = main.addOrReplaceChild("Leftfoot",
				CubeListBuilder.create().texOffs(28, 40)
						.addBox(1.9F, 11.0F, -4.0F, 4.0F, 1.0F, 1.0F, new CubeDeformation(0.25F)).texOffs(18, 26)
						.addBox(1.9F, 10.0F, -2.5F, 4.0F, 2.0F, 5.0F, new CubeDeformation(0.25F)),
				PartPose.offset(-1.9F, -12.0F, 0.0F));

		return LayerDefinition.create(meshdefinition, 64, 64);
	}

	@Override
	public void renderToBuffer(PoseStack poseStack, VertexConsumer vertexConsumer, int packedLight, int packedOverlay,
			float red, float green, float blue, float alpha) {
		main.render(poseStack, vertexConsumer, packedLight, packedOverlay, red, green, blue, alpha);
	}

	public void setupAnim(T entity, float limbSwing, float limbSwingAmount, float ageInTicks, float netHeadYaw,
			float headPitch) {
	}
}